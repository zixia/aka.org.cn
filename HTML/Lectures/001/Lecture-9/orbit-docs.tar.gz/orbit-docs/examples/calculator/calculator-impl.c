#include "calculator.h"


/*** App-specific servant structures ***/
typedef struct {
   POA_Calculator servant;
   PortableServer_POA poa;

} impl_POA_Calculator;

/*** Implementation stub prototypes ***/
static void impl_Calculator__destroy(impl_POA_Calculator * servant,
                                     CORBA_Environment * ev);

CORBA_double impl_Calculator_add(impl_POA_Calculator * servant,
                    CORBA_double number1,
                    CORBA_double number2,
                    CORBA_Environment * ev);

CORBA_double impl_Calculator_sub(impl_POA_Calculator * servant,
                    CORBA_double number1,
                    CORBA_double number2,
                    CORBA_Environment * ev);

/*** epv structures ***/
static PortableServer_ServantBase__epv impl_Calculator_base_epv =
{
   NULL,                        /* _private data */
   (gpointer) & impl_Calculator__destroy,       /* finalize routine */
   NULL,                        /* default_POA routine */
};
static POA_Calculator__epv impl_Calculator_epv =
{
   NULL,                        /* _private */
   (gpointer) & impl_Calculator_add,

   (gpointer) & impl_Calculator_sub,

};

/*** vepv structures ***/
static POA_Calculator__vepv impl_Calculator_vepv =
{
   &impl_Calculator_base_epv,
   &impl_Calculator_epv,
};

/*** Stub implementations ***/
static Calculator 
impl_Calculator__create(PortableServer_POA poa, CORBA_Environment * ev)
{
   Calculator retval;
   impl_POA_Calculator *newservant;
   PortableServer_ObjectId *objid;

   newservant = g_new0(impl_POA_Calculator, 1);
   newservant->servant.vepv = &impl_Calculator_vepv;
   newservant->poa = poa;
   POA_Calculator__init((PortableServer_Servant) newservant, ev);
   objid = PortableServer_POA_activate_object(poa, newservant, ev);
   CORBA_free(objid);
   retval = PortableServer_POA_servant_to_reference(poa, newservant, ev);

   return retval;
}

/* You shouldn't call this routine directly without first deactivating the servant... */
static void
impl_Calculator__destroy(impl_POA_Calculator * servant, CORBA_Environment * ev)
{

   POA_Calculator__fini((PortableServer_Servant) servant, ev);
   g_free(servant);
}

CORBA_double
impl_Calculator_add(impl_POA_Calculator * servant,
                    CORBA_double number1,
                    CORBA_double number2,
                    CORBA_Environment * ev)
{
   CORBA_double retval;

   return retval;
}

CORBA_double
impl_Calculator_sub(impl_POA_Calculator * servant,
                    CORBA_double number1,
                    CORBA_double number2,
                    CORBA_Environment * ev)
{
   CORBA_double retval;

   return retval;
}
