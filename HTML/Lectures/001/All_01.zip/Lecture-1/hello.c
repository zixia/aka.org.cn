#include <stdio.h>
#include <stdlib.h>

int main (int argc, char **argv)
{
    printf ("Hello world!\n");
    printf ("Hello world again!\n");

    return 0;
}

