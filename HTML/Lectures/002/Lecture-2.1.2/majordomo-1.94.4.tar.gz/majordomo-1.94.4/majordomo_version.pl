# $Header: /sources/cvsrepos/majordomo/majordomo_version.pl,v 1.26 1997/08/27 15:56:36 cwilson Exp $

$majordomo_version = "1.94.4";
1;

