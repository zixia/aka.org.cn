use TuringBot::www2bbs;


my $netbig=new TuringBot::www2bbs('url'=>'http://news.netbig.com/news07/','getlist'=>\&getlist,'getdetail'=>\&getdetail,'Mode'=>1);
print "\n" while($netbig->getpage);
sub getlist
{
        my ($self,$html,$url,$result)=@_;
        my $goodie=[];
        @$goodie=grep(($_->{'content'}=~m{/image/n61}),@$result);
        my $abs=$goodie->[0]->{'table_absolute'};
        @$goodie=grep(($_->{'href'}=~m{com/news07/1019} && $_->{'table_absolute'}==$abs+2),@$result);
        grep(print($_->{'table_absolute'},$_->{'href'},"\n"),@$goodie);
        return $goodie;
}
sub autoreturn			#�����Զ�����
{
	my($input,$len)=@_;
	$len||=74;
	my $first="";
	my $returned="";
	$input=~s{\t}{ }g;
	my $half=int($len/4*3);
	while($input)
	{
		if($input=~m{^([^\n\r]{0,$len}[\n])}si)
		{
			$first=$1;
			$input=$';
			$returned.=$first;
			next;
		}
		if($input=~m{^([^\n\r]{$half,$len}[\s\-\.\,])}si)
		{
			$first=$1;
			$input=$';
			$first.="\n";
			$returned.=$first;
		}
		else
		{
			if ( length($input) <= $len ) 
			{ 
				$returned.=$input;
				last;
			} 
			if (substr($input, 0, $len) =~ /^([\000-\177]|[\200-\377][\200-\377])*([\000-\177]|[\200-\377][\200-\377])$/ ) 
			{ 
				$first=substr($input, 0, $len);
				$input=substr($input,$len);
				$first.="\n";
				$returned.=$first;
			} 
			else
			{
				$first=substr($input, 0, $len-1);
				$input=substr($input,$len-1);
				$first.="\n";
				$returned.=$first;
			}
		}
	}
	return $returned;
}

sub getdetail
{
        my ($self,$html,$elem,$result)=@_;
        my $content='';
        $html=~s{\&nbsp\;}{ }sg;
        $content=$1 if $html=~m{<p align="left"><SPAN style="FONT-SIZE: 14px">(.*?)�������Ը���}si;
        return 'NO' if !$content;
        $content=~s{<IMG SRC="(/news07/1019/[^"]*)"[^>]*>}{    ���ͼƬhttp://news.netbig.com$1\n}sgi;
        $content=~s{<BR>}{\n}sgi;
        $content=~s{<[^>]*>}{}sg;
        $content=&autoreturn($content,71);
        print $content;
        return {'title'=>$elem->{'content'},'href'=>$elem->{'href'},'content'=>$content};
}
