use TuringBot::SMTH;

use TuringBot::www2bbs;
my $netbig=new TuringBot::www2bbs('url'=>'http://news.netbig.com/news07/','getlist'=>\&getlist,'getdetail'=>\&getdetail,'Mode'=>1);
sub getlist
{
        my ($self,$html,$url,$result)=@_;
        my $goodie=[];
        @$goodie=grep(($_->{'content'}=~m{/image/n61}),@$result);
        my $abs=$goodie->[0]->{'table_absolute'};
        @$goodie=grep(($_->{'href'}=~m{com/news07/1019} && $_->{'table_absolute'}==$abs+2),@$result);
        grep(print($_->{'table_absolute'},$_->{'href'},"\n"),@$goodie);
        return $goodie;
}

sub getdetail
{
        my ($self,$html,$elem,$result)=@_;
        my $content='';
        $html=~s{\&nbsp\;}{ }sg;
        $content=$1 if $html=~m{<p align="left"><SPAN style="FONT-SIZE: 14px">(.*?)�������Ը���}si;
        return 'NO' if !$content;
        $content=~s{<IMG SRC="(/news07/1019/[^"]*)"[^>]*>}{    ���ͼƬhttp://news.netbig.com$1\n}sgi;
        $content=~s{<BR>}{\n}sgi;
        $content=~s{<[^>]*>}{}sg;
        print $content;
        return {'title'=>$elem->{'content'},'href'=>$elem->{'href'},'content'=>$content};
}

#my $bbs=new TuringBot::SMTH('forcelogin'=>1,'host'=>'smth.org','proxy'=>'202.205.10.160','proxy_wait'=>'login','proxy_cmd'=>"bbs\n");
my $bbs=new TuringBot::SMTH('forcelogin'=>1,'host'=>'smth.org','signature'=>"--\n������ͼ��������ύ.\n����һ��OSS��Ŀ.\n�������Perl��.\n����Ȥ������nullgate��ϵ.");
$def=$bbs;
$def->login("pseudo","trashfir");
#$bbs->go2board('News');
#$bbs->post('TuringBot',"���Զ���\n--\n����ǩ����");
#$netbig->getpage for(1...34);
#$bbs->multipost('                                                 [ת������]',$netbig);
#$bbs->go2main();
$bbs->MessageLoop();
#print $bbs->{'strbuf'};
#print "Let's go!\n";
#$bbs->waitline("bbs");
#$bbs->type("bbs\n");
#exit;
#$bbs->waitline("new");
#$bbs->regexc("bbs");
#$bbs->regexc("abcs",'d','WC',1,99999);
#$bbs->regexc("defs",'d','WC',-1,777);
#$bbs->regexc("ghis",'d','WC',1,3333);

#print $bbs->{'strbuf'};
