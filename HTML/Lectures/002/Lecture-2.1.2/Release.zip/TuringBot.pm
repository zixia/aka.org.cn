package TuringBot;
require Exporter;
@ISA = qw(Exporter);
use strict;
use vars qw(@EXPORT);
@EXPORT = qw(autoreturn);            # symbols to export by default
use Telnet;
use strict;
use Carp;
sub new
{
	my $class=shift;
	my %Config=@_ if @_;
	my $self={};
	%$self=%Config if %Config;
	$self->{'SYSTEM_BUFFER'}=[];
	$self->{'buffer'}=[];
	$self->{'timer'}=[];
	$self->{'strbuf'}='';
	$self->{'SYTEM_BLOCK'}='';
	$self->{'status'}={};
	$self->{'exception'}=[];
	$self->{'request'}=[];
	$self->{'timeout'}||=60;
	print "Require a host!" if !$self->{'host'};
	$self->{'port'}||=23;
	$self->{'display'}||=1;		#�Ƿ���ʾ
	$self->{'delay'}||=1;		#��ʱ���ã�ÿ�����������ʱ
	#��Ҫ���������Errmode=>\&JobLost
	if($self->{'proxy'})
	{
		if(ref $self->{'proxy'} eq 'CODE')
		{
			$self->{'sock'}=&{$self->{'proxy'}}(%Config);
		}
		else
		{
			$self->{'sock'} = new Net::Telnet (Timeout => $self->{'timeout'},Host=>$self->{'proxy'},Port=>$self->{'port'},Output_record_separator=>'');
			if($self->{'proxy_wait'})
			{
				bless $self,$class;
				$self->waitline($self->{'proxy_wait'});
				$self->type($self->{'proxy_cmd'}) if $self->{'proxy_cmd'};
				return $self;
			}
		}
	}
	else
	{
		$self->{'sock'} = new Net::Telnet (Timeout => $self->{'timeout'},Host=>$self->{'host'},Port=>$self->{'port'},Output_record_separator=>'');
	}
	sleep $self->{'delay'};
	bless $self,$class;
	return $self;
	
}

#��BBS���ַ���
sub type
{
	my($self,$input)=@_;
	confess 'MUST HAVE AN OBJECT FIRST' if ref $self!~m{TuringBot};
	$self->{'sock'}->print($input);
	$self->{'typed'}=1;
	sleep $self->{'delay'};
	return;
}

sub typelines			#���ڷ�������
{
	my($self,$input)=@_;
	confess 'MUST HAVE AN OBJECT FIRST' if ref $self!~m{TuringBot};
	$input=&autoreturn($input);
	my @lines=split("\n",$input);
	my $line="";
	foreach $line(@lines)
	{
		$self->{'typed'}=1;
		$self->{'sock'}->print($line,"\n");
		#sleep $self->{'delay'};
		$self->waitline(quotemeta($line)) if length($line)>20;
	}
	sleep $self->{'delay'};
	return;
}

sub autoreturn			#�����Զ�����
{
	my($input,$len)=@_;
	$len||=74;
	my $first="";
	my $returned="";
	$input=~s{\t}{ }g;
	my $half=int($len/4*3);
	my $i=0;
	while($input)
	{
		$i++;
		print '.' if $i%100==1;
		if($input=~m{^([^\n\r]{0,$len}[\n])}si)
		{
			$first=$1;
			$input=$';
			$returned.=$first;
			next;
		}
		if($input=~m{^([^\n\r]{$half,$len}[\s\-\.\,])}si)
		{
			$first=$1;
			$input=$';
			$first.="\n";
			$returned.=$first;
		}
		else
		{
			if ( length($input) <= $len ) 
			{ 
				$returned.=$input;
				last;
			} 
			if (substr($input, 0, $len) =~ /^([\000-\177]|[\200-\377][\200-\377])*([\000-\177]|[\200-\377][\200-\377])$/ ) 
			{ 
				$first=substr($input, 0, $len);
				$input=substr($input,$len);
				$first.="\n";
				$returned.=$first;
			} 
			else
			{
				$first=substr($input, 0, $len-1);
				$input=substr($input,$len-1);
				$first.="\n";
				$returned.=$first;
			}
		}
	}
	return $returned;
}


#\e\[1\;1H\e\[44m\e\[36m
#��BBS����һ��
sub getline
{
	my $self=shift;
	confess 'MUST HAVE AN OBJECT FIRST' if ref $self!~m{TuringBot};
	my $temp='';
	if(scalar @{$self->{'SYSTEM_BUFFER'}} == 0)
	{
		#�������
		if($self->{'SYTEM_BLOCK'} && defined($temp=$self->exception($self->{'SYTEM_BLOCK'})))
		{
			$self->{'SYTEM_BLOCK'}='';
			push @{$self->{'buffer'}},$temp;
			$self->{'strbuf'}.=$temp;
			$self->{'lastline'}=$temp;
			return $temp;
		}
		if($self->{'status'}->{'last_exception'} eq 'DISPATCH')
		{
			$self->{'status'}->{'last_exception'}='';
			$self->{'SYTEM_BLOCK'}='';
			push @{$self->{'buffer'}},'';
			$self->{'lastline'}='';
			$self->{'lastline_cleared'}='';
			return;
		}
		#sleep $self->{'delay'};
		$self->{'SYTEM_BLOCK'}.=$self->{'sock'}->get;
		$self->{'SYTEM_BLOCK'}=~s{\007\007\e\[1\;1H}{�ݤ��}sg;		#Exception
		$self->{'SYTEM_BLOCK'}=~s{(\n|\e\[[\w;]*H)}{$1�����}sg;
		$self->{'SYTEM_BLOCK'}=~s{�ݤ��}{\007\007\e\[1\;1H}sg;		#Exception
		@{$self->{'SYSTEM_BUFFER'}}=split(/�����/,$self->{'SYTEM_BLOCK'});
		if(@{$self->{'SYSTEM_BUFFER'}} > 1)
		{
			$self->{'SYTEM_BLOCK'}=pop @{$self->{'SYSTEM_BUFFER'}};
		}
		else
		{
			$self->{'SYTEM_BLOCK'}='';
		}
	}
	my $line=shift @{$self->{'SYSTEM_BUFFER'}};
	#print $temp;
	#�������
	if($temp=$self->exception($line))
	{
		push @{$self->{'buffer'}},$temp;
		$self->{'strbuf'}.=$temp;
		$self->{'lastline'}=$temp;
		return $temp;
	}
	if($self->{'status'}->{'last_exception'} eq 'DISPATCH')
	{
		$self->{'status'}->{'last_exception'}='';
		push @{$self->{'buffer'}},'';
		$self->{'lastline'}='';
		$self->{'lastline_cleared'}='';
		return;
	}
	push @{$self->{'buffer'}},$line;
	$self->{'strbuf'}.=$line;
	$self->{'lastline'}=$line;
	return $line;
}

#��ջ���
sub flush
{
	my $self=shift;
	confess 'MUST HAVE AN OBJECT FIRST' if ref $self!~m{TuringBot};
	$self->{'strbuf'}='';
	@{$self->{'buffer'}}=();
	return;
}

#���⴦��
sub exception
{
	my $self=shift;
	confess 'MUST HAVE AN OBJECT FIRST' if ref $self!~m{TuringBot};
	confess 'USAGE: exception LINE' if !@_;
	my $line=shift;
	my $line_cleared=$line;
	$line_cleared=~s{\e\[[\d;,]*\H}{\n}sg;
	$line_cleared=~s{\e\[[\d;,]*\w}{}sg;
	my ($i,$j)=(0,0);
	$self->{'lastline'}=$line;
	$self->{'lastline_cleared'}=$line_cleared;
	for($i=0;$i<scalar(@{$self->{'exception'}});$i++)
	{
		if($self->{'exception'}->[$i]->[0]=~m{\(\?\#ANSI\)})	#KEEP ANSI ESC SEQ
		{
			if($line=~m{$self->{'exception'}->[$i]->[0]})#regexp
			{
				if(ref $self->{'exception'}->[$i]->[1])#handler
				{
					#print "@{$self->{'exception'}->[$i]}";
					
					my $result=&{$self->{'exception'}->[$i]->[1]}($self,$i,$line);
					if($self->{'exception'}->[$i]->[3]>0)#type
					{
						$self->{'exception'}->[$i]->[3]--;
						$self->{'status'}->{'last_exception'}=$self->{'exception'}->[$i]->[2];#id
						@{$self->{'exception'}}=grep($_->[3],@{$self->{'exception'}});#delete
						return $result;
					}
					else
					{
						$self->{'status'}->{'last_exception'}=$self->{'exception'}->[$i]->[2];#id
						#print "RESULT $result\n";
						return $result;
					}
				}
				elsif( $self->{'exception'}->[$i]->[1] eq 'FWD')
				{
					if($self->{'exception'}->[$i]->[3]>0)#type
					{
						$self->{'exception'}->[$i]->[3]--;
						$self->{'status'}->{'last_exception'}=$self->{'exception'}->[$i]->[2];#id
						@{$self->{'exception'}}=grep($_->[3],@{$self->{'exception'}});#delete
						return $line;
					}
					else
					{
						$self->{'status'}->{'last_exception'}=$self->{'exception'}->[$i]->[2];#id
						return $line;
					}
				}
				else	#to add other default handler
				{
					if($self->{'exception'}->[$i]->[3]>0)#type
					{
						$self->{'exception'}->[$i]->[3]--;
						$self->{'status'}->{'last_exception'}=$self->{'exception'}->[$i]->[2];#id
						@{$self->{'exception'}}=grep($_->[3],@{$self->{'exception'}});#delete
						return undef;
					}
					else
					{
						$self->{'status'}->{'last_exception'}=$self->{'exception'}->[$i]->[2];#id
						return undef;
					}
				}
			}
		}
		else
		{
			if($line_cleared=~m{$self->{'exception'}->[$i]->[0]})#regexp
			{
				if(ref $self->{'exception'}->[$i]->[1])#handler
				{
					my $result=&{$self->{'exception'}->[$i]->[1]}($self,$i,$line);
					if($self->{'exception'}->[$i]->[3]>0)#type
					{
						$self->{'exception'}->[$i]->[3]--;
						$self->{'status'}->{'last_exception'}=$self->{'exception'}->[$i]->[2];#id
						@{$self->{'exception'}}=grep($_->[3],@{$self->{'exception'}});#delete
						return $result;
					}
					else
					{
						$self->{'status'}->{'last_exception'}=$self->{'exception'}->[$i]->[2];#id
						return $result;
					}
				}
				elsif( $self->{'exception'}->[$i]->[1] eq 'FWD')
				{
					if($self->{'exception'}->[$i]->[3]>0)#type
					{
						$self->{'exception'}->[$i]->[3]--;
						$self->{'status'}->{'last_exception'}=$self->{'exception'}->[$i]->[2];#id
						@{$self->{'exception'}}=grep($_->[3],@{$self->{'exception'}});#delete
						return $line;
					}
					else
					{
						$self->{'status'}->{'last_exception'}=$self->{'exception'}->[$i]->[2];#id
						return $line;
					}
				}
				else	#to add other default handler
				{
					if($self->{'exception'}->[$i]->[3]>0)#type
					{
						$self->{'exception'}->[$i]->[3]--;
						$self->{'status'}->{'last_exception'}=$self->{'exception'}->[$i]->[2];#id
						@{$self->{'exception'}}=grep($_->[3],@{$self->{'exception'}});#delete
						return undef;
					}
					else
					{
						$self->{'status'}->{'last_exception'}=$self->{'exception'}->[$i]->[2];#id
						return undef;
					}
				}
			}
		}
	}
	return undef;
}

#ȡ��ע��
sub unregexc
{
	my $self=shift;
	confess 'MUST HAVE AN OBJECT FIRST' if ref $self!~m{TuringBot};
	confess 'USAGE: unregexc ID' if !@_;
	my $id=shift;
	@{$self->{'exception'}}=grep($_->[2] ne $id,@{$self->{'exception'}});
	#print 'DEBUG EXC=',scalar @{$self->{'exception'}},"\n";
}

#ȡ��ע��
sub unregexcs
{
	my $self=shift;
	confess 'MUST HAVE AN OBJECT FIRST' if ref $self!~m{TuringBot};
	confess 'USAGE: regexc IDRE' if !@_;
	my $id=shift;
	@{$self->{'exception'}}=grep($_->[2]!~m{$id},@{$self->{'exception'}});
	#print 'DEBUG EXC=',scalar @{$self->{'exception'}},"\n";
}

#ע����Ϣ
sub regexc
{
	my $self=shift;
	confess 'MUST HAVE AN OBJECT FIRST' if ref $self!~m{TuringBot};
	#init
	confess 'USAGE: regexc TRIGER[,HANDLER ... ]' if !@_;
	my @exception=@_;
	$exception[1]||='FWD';
	$exception[2]||='DEFAULT';
	$exception[3]||=1;
	$exception[4]||=1;
	push @{$self->{'exception'}},\@exception;
	#sort
	my ($i,$j)=(0,0);
	for($i=0;$i<scalar(@{$self->{'exception'}});$i++)
	{
		for($j=0;$j<$i;$j++)
		{
			if($self->{'exception'}->[$i]->[4]>$self->{'exception'}->[$j]->[4])
			{
				my @temp;
				@temp=splice(@{$self->{'exception'}},$j);
				push (@{$self->{'exception'}},splice(@temp,$i-$j,1));
				push @{$self->{'exception'}},@temp;
				last;
			}
		}
	}
	#print 'DEBUG EXC=',scalar @{$self->{'exception'}},"\n";
}

sub timeup
{
	my $self=shift;
	confess 'MUST HAVE AN OBJECT FIRST' if ref $self!~m{TuringBot};
	my $now=time;
	my @timeup=grep($_->[1]+$_->[3]<=$now,@{$self->{'timer'}});
	grep($_->[3]=&{$_->[2]}($self,$_->[0]),@timeup);
	@{$self->{'timer'}}=grep($_->[1]+$_->[3]>$now,@{$self->{'timer'}});
	$self->deadline;
}

sub deadline	#��ȡ�������ʱ��
{
	my $self=shift;
	confess 'MUST HAVE AN OBJECT FIRST' if ref $self!~m{TuringBot};
	my @deadline=map($_->[1]+$_->[3],@{$self->{'timer'}});
	@deadline=sort @deadline;
	$self->{'deadline'}=$deadline[0];
	return $deadline[0];
}

sub setimer
{
	my $self=shift;
	confess 'MUST HAVE AN OBJECT FIRST' if ref $self!~m{TuringBot};
	#init
	confess 'USAGE: setimer TimerID,Time,Handler' if @_<3;
	my @timer=@_;
	$timer[3]=time;
	my @result=grep($_->[0] eq $timer[0],@{$self->{'timer'}});
	confess 'TimerID duplicate' if @result>1;
	if(@result)
	{
		#update
		$result[0]->[1]=$timer[1];
		$result[0]->[2]=$timer[2];
		$result[0]->[3]=$timer[3];
		$self->deadline;
		return 0;
	}
	else
	{
		#new
		push @{$self->{'timer'}},\@timer;
		$self->deadline;
		return 1;
	}
}

sub cancel
{
	my $self=shift;
	confess 'MUST HAVE AN OBJECT FIRST' if ref $self!~m{TuringBot};
	#init
	confess 'USAGE: cancel TimerID' if !@_;
	@{$self->{'timer'}}=grep($_->[0] ne $_[0],@{$self->{'timer'}});
	$self->deadline;
	return;
}

sub delay
{
	my $self=shift;
	confess 'MUST HAVE AN OBJECT FIRST' if ref $self!~m{TuringBot};
	#init
	confess 'USAGE: delay TimerID' if !@_;
	my @result=grep($_->[0] eq $_[0],@{$self->{'timer'}});
	confess 'TimerID duplicate' if @result>1;
	$result[0]->[3]=time;
	$self->deadline;
	return;
}
#�ȴ�һ��
sub waitline
{
	my $self=shift;
	confess 'MUST HAVE AN OBJECT FIRST' if ref $self!~m{TuringBot};
	my $regexp=shift;
	$self->{'status'}->{'last_exception'}='';
	$self->regexc($regexp,'FWD','_WAIT_LINE_',1,1000);
	my $line='';
	while($self->{'status'}->{'last_exception'} ne '_WAIT_LINE_')
	{
		#print "GET\n";
		$line=$self->getline();
		print $self->{'lastline_cleared'};
	}
	return $self->{'lastline'};
}

#Ӧ����������ĺ���
sub guess
{
	my $self=shift;
	confess 'MUST HAVE AN OBJECT FIRST' if ref $self!~m{TuringBot};
	confess 'USAGE: regexc REG_LIST' if !@_;
	my $i=0;
	for($i=0;$i<scalar(@_);$i++)
	{
		$self->regexc($_[$i],'FWD','_GUESS='.$i,1,1000+$i);
	}
	my $line='';
	while($self->{'status'}->{'last_exception'}!~m{_GUESS})
	{
		#print "GET\n";
		$line=$self->getline();
		print $self->{'lastline_cleared'};
	}
	$self->unregexcs('^_GUESS');
	$self->{'status'}->{'last_exception'}=~s{_GUESS=}{};
	return $self->{'status'}->{'last_exception'};
}

sub MessageLoop
{
	my $self=shift;
	confess 'MUST HAVE AN OBJECT FIRST' if ref $self!~m{TuringBot};
	$self->{'ready'}=1;
	while(1)
	{
		if($self->{'deadline'}<time)
		{
			$self->timeup;
		}
		$self->getline();
		print $self->{'lastline_cleared'};
		#ֻ�е�״̬���ڿ���ʱ������������
		#�������������$self->{'ready'}Ϊ0
		if($self->{'ready'} && @{$self->{'request'}})
		{
			my($request,$func)=();
			while($request=shift @{$self->{'request'}})
			{
				#print $func;
				$func=pop @$request;
				&$func($self,@$request);
			}
		}
		#Ӧ������һЩ�򵥵�transaction
		last if $self->{'status'}->{'end'};
	}
}


sub DESTROY
{
	my $self=shift;
	undef $self->{'sock'};
}

1;
