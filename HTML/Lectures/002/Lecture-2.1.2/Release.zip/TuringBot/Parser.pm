package TuringBot::Parser;
require HTML::Parser;
@ISA=qw(HTML::Parser);
$VERSION = sprintf("%d.%02d", q$Revision: 0.5 $ =~ /(\d+)\.(\d+)/);

use strict;

sub new
{
	my $class = shift;
	my %config = @_;
	my $self = $class->SUPER::new;
	$self->{'config'}=\%config;
	#������
    	$self->{'href'}="";			
	#��֪�ĵ�����ǩ
	$self->{'ignore'}={'img'=>1,'input'=>1,'br'=>1,'hr'=>1,'form'=>1};
    	#������
	$self->{'img_count'}=0;			#ͼƬ���
	$self->{'table_depth'}=0;		#�������
	$self->{'table_absolute'}=0;		#������Լ���
	$self->{'table_relative'}=0;		#������Լ���
	$self->{'tr_count'}=0;			#����
	$self->{'td_count'}=0;			#����
	#������ջ
	@{$self->{'tr'}}=();			#��ʼ��
	@{$self->{'td'}}=();			#��ʼ��
	@{$self->{'tags'}}=();			#��ʼ��
	@{$self->{'result'}}=();		#��ʼ��
	$self->{'config'}->{'basehref'}=~s/\?.*//;
	$self->{'config'}->{'basehref'}=~s{([^/.]*):80/}{$1/};
	if($self->{'config'}->{'basehref'}!~m{[^/]/[^/]*$}is)
	{
    		$self->{'config'}->{'basehref'}.="/";
    	}
    	else
    	{
		$self->{'config'}->{'basehref'}=~s{/[^/]*$}{/}is if ($self->{'config'}->{'basehref'});
    	}
    	$self->{'config'}->{'roothref'}=$1 if ($self->{'config'}->{'basehref'}=~m{^([^/]*://[^/]*)});
    	return $self;
}

sub strip
{
	my ($self,$html,%config) = @_ ;
	$self->{'config'}=\%config;
	#������
    	$self->{'href'}="";			
	#��֪�ĵ�����ǩ
    	#������
	$self->{'img_count'}=0;			#ͼƬ���
	$self->{'table_depth'}=0;		#�������
	$self->{'table_absolute'}=0;		#������Լ���
	$self->{'table_relative'}=0;		#������Լ���
	$self->{'tr_count'}=0;			#����
	$self->{'td_count'}=0;			#����
	#������ջ
	@{$self->{'tr'}}=();			#��ʼ��
	@{$self->{'td'}}=();			#��ʼ��
	@{$self->{'tags'}}=();			#��ʼ��
	@{$self->{'result'}}=();		#��ʼ��
	$self->{'config'}->{'basehref'}=~s/\?.*//;
	$self->{'config'}->{'basehref'}=~s{([^/.]*):80/}{$1/};
	if($self->{'config'}->{'basehref'}!~m{[^/]/[^/]*$}is)
	{
    		$self->{'config'}->{'basehref'}.="/";
    	}
    	else
    	{
		$self->{'config'}->{'basehref'}=~s{/[^/]*$}{/}is if ($self->{'config'}->{'basehref'});
    	}
    	$self->{'config'}->{'roothref'}=$1 if ($self->{'config'}->{'basehref'}=~m{^([^/]*://[^/]*)});
	$self->parse($html);
	return $self->{'result'};
}

sub start
{
	my ($self,$tag, $attr, $attrseq, $origtext) = @_ ;
	#print '.';
	if($tag eq 'base')
	{
		return if !$attr->{'href'};
		$self->{'config'}->{'basehref'}=$attr->{'href'};
		$self->{'config'}->{'basehref'}=~s{([^/.]*):80/}{$1/};
		if($self->{'config'}->{'basehref'}!~m{[^/]/[^/]*$}is)
		{
	    		$self->{'config'}->{'basehref'}.="/";
	    	}
	    	else
	    	{
			$self->{'config'}->{'basehref'}=~s{/[^/]*$}{/}is if ($self->{'config'}->{'basehref'});
	    	}
	    	$self->{'config'}->{'roothref'}=$1 if ($self->{'config'}->{'basehref'}=~m{^([^/]*://[^/]*)});
	}
	$self->{'_img_'}=0 if $tag eq 'html';
	$self->{'_last_tag_'}=$tag;
	if($self->{'config'}->{'Progress'})
	{
		$self->{'_counter_'}++;
		$self->{'_counter_'}=$self->{'_counter_'}%$self->{'config'}->{'Progress'};
		print "." if !$self->{'_counter_'};
	}
	if ($tag eq 'a') 
	{
		if($attr->{'href'} eq '#')
		{
			$self->{'href'} = $attr->{'onclick'};
		}
		else
		{
			$attr->{'href'}=$self->{'config'}->{'roothref'}.$attr->{'href'} if($attr->{'href'}=~m{^/});
			$attr->{'href'}=$self->{'config'}->{'basehref'}.$attr->{'href'} if($attr->{'href'}!~m{://});
			$self->{'href'} = $attr->{'href'};
			$self->{'href'}=~s/\s*//g if $self->{'config'}->{'trimhref'};
			$self->{'href'}=~s{/\.\./}{/}gi if $self->{'href'}=~m{://[^/]*/\.\.}is;;
			$self->{'href'}=~s{/[^/]*/\.\./}{/}gi;
		}
	}
	elsif($tag eq 'area')
	{
		$attr->{'href'}=$self->{'config'}->{'roothref'}.$attr->{'href'} if($attr->{'href'}=~m{^/});
		$attr->{'href'}=$self->{'config'}->{'basehref'}.$attr->{'href'} if($attr->{'href'}!~m{://});
		$attr->{'href'}=~s{/\.\./}{/}gi if $attr->{'href'}=~m{://[^/]*/\.\.}is;
		$attr->{'href'}=~s{/[^/]*/\.\./}{/}gi;
		push @{$self->{'result'}},{'href'=>$attr->{'href'},'content'=>'AREA'};
	}
	if($tag eq 'table')
	{
		push @{$self->{'tr'}},$self->{'tr_count'};
		push @{$self->{'td'}},$self->{'td_count'};
		$self->{'tr_count'}=0;			#����
		$self->{'td_count'}=0;			#����
		$self->{'table_depth'}++;
		$self->{'table_relative'}++ if($self->{'table_depth'}==1);
		$self->{'table_absolute'}++;
	}
	if($tag eq 'tr')
	{
		$self->{'tr_count'}++;			#����
		$self->{'td_count'}=0;			#����
	}
	if($tag eq 'td')
	{
		$self->{'td_count'}++;			#����
	}
	if($tag eq 'img')
	{
		$attr->{'src'}=~s{\\}{/}g;
		$self->{'img_count'}++;			#����
		$attr->{'src'}=$self->{'config'}->{'roothref'}.$attr->{'src'} if($attr->{'src'}=~m{^/});
		$attr->{'src'}=$self->{'config'}->{'basehref'}.$attr->{'src'} if($attr->{'src'}!~m{://});
		$attr->{'src'}=~s{/\.\./}{/}gi if $attr->{'src'}=~m{://[^/]*/\.\.}is;
		$attr->{'src'}=~s{/[^/]*/\.\./}{/}gi;
		$self->text('_IMG_'.$self->{'img_count'}.'_'.$attr->{'src'});
	}
	push @{$self->{'tags'}},$tag if (!($self->{'config'}->{'ignore'}->{$tag}||$self->{'ignore'}->{$tag}));
	#print "PUSHED @{$self->{'tags'}}\t\t$tag\n";
	return;
}



sub text
{
	my ($self,$text) = @_ ;
	return if $text=~m{^(\n|\r|\s)*$}is;
	#return if !$self->{'href'};
	my %temp=();
	if($text!~m/_IMG_/)
	{
		$temp{'content'}=$text;
	}
	else
	{
		$text=~m/_IMG_(.*)/;
		$temp{'content'}=$1;
		$temp{'isImage'}=1;
	}
	$temp{'href'}=$self->{'href'};
	@{$temp{'tags'}}=@{$self->{'tags'}};
	$temp{'tag'}=$self->{'_last_tag_'};
	$temp{'table_depth'}=$self->{'table_depth'};
	$temp{'table_absolute'}=$self->{'table_absolute'};
	$temp{'table_relative'}=$self->{'table_relative'};
	$temp{'tr_count'}=$self->{'tr_count'};
	$temp{'td_count'}=$self->{'td_count'};
	push @{$self->{'result'}},\%temp;
	return;
}

sub end
{
	my ($self,$tag, $origtext) = @_ ;
	my $poped;
	if ($tag eq 'a')
	{
		$self->{'href'} = '' ;
	}
	if($tag eq 'table')
	{
		$self->{'tr_count'}=pop @{$self->{'tr'}};
		$self->{'td_count'}=pop @{$self->{'td'}};
		$self->{'table_depth'}--;
		#if depth < 0 generate an Exception;
	}
	if (!($self->{'config'}->{'ignore'}->{$tag}||$self->{'ignore'}->{$tag}))
	{
		while($poped =pop @{$self->{'tags'}})
		{
			last if($poped eq $tag);
			#print "POPED  @{$self->{'tags'}}\t\t$poped\t\t$tag\n";
		}
	}
	
	return;
}

1;
