package TuringBot::www2bbs;
use TuringBot::Parser;
use TuringBot::Fetch;


sub new
{
	my $class = shift;
	my %Config = @_;
	my $self = {};
	%{$self}=%Config;
	bless $self,$class;
	$self->{'Parser'}=new TuringBot::Parser;		#	��ʼ��������	
	$self->{'URL_Stack'}=[$self->{'url'}];
	$self->{'list'}=[];
	$self->{'Fetcher'}=new TuringBot::Fetch('Stack'=>$self->{'URL_Stack'});		#	��ʼ��UserAgent
	$self->{'Fetcher'}->{'cached'}=1 if $self->{'Mode'}==1;
	$self->getlist;
    	return $self;
}

sub getlist
{
	my($self)=@_;
	my %visited=();
	my $show_url=$url;
	$show_url=~s{http://[^/]*}{}i;
	my $html='';
	my $url=$self->{'url'};
	$html=$self->{'Fetcher'}->get_by_url($url);
	return 0 if !$html;
	my $result=undef;
	$result=$self->{'Parser'}->strip($html,'basehref'=>$url);
	$self->{'list'}=&{$self->{'getlist'}}($self,$html,$url,$result);
	return 1;
}

sub getpage
{
	my($self)=@_;
	my %visited=();
	my $show_url=$url;
	return if !$self->{'list'};
	return if !@{$self->{'list'}};
	$show_url=~s{http://[^/]*}{}i;
	my $html='';
	my $elem=pop @{$self->{'list'}};
	my $url=$elem->{'href'};
	$html=$self->{'Fetcher'}->get_by_url($url);
	return 'NO' if !$html;
	my $result=undef;
	$result=$self->{'Parser'}->strip($html,'basehref'=>$url);
	return &{$self->{'getdetail'}}($self,$html,$elem,$result);
	#����{'content'=>'','title'=>'','href'=>''}
}

1;