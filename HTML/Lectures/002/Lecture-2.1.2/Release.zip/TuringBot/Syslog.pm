package TuringBot::Syslog;
require Exporter;
@ISA = qw(Exporter);
use strict;
use vars qw(@EXPORT);
@EXPORT = qw(append myLog recordException fatalError seriousError);            # symbols to export by default
use FileHandle;
use POSIX qw(strftime);

#recordException��¼���⣬fatalError����һ��Dump�ļ���
#myLog��¼ϵͳ��Ϣ��

sub myLog
{
	my ($file,$info)=@_;
	my $now_string = strftime "[%m-%d/%H:%M] ", localtime;
	my $fl=new FileHandle(">>syslog/$file\.log");
	$fl->print($now_string,$info,"\n");
	$fl->close;
	return;
}

sub append
{
	my ($file,$info)=@_;
	my $fl=new FileHandle(">>$file");
	$fl->print($info,"\n");
	$fl->close;
	return;
}

sub recordException
{
	my $filename=shift;
	my $info=shift;
	my $now_string = strftime "[%m-%d/%H:%M] ", localtime;
	my $fl=new FileHandle(">>$filename\.err");
	$fl->print($now_string,$info,"\n");
	$fl->close;
	return;
}

sub fatalError
{
	my $info=shift;
	my $now_string = strftime "%m_%d_%H_%M_%S\.dump", localtime;
	my $fl=new FileHandle(">$now_string");
	$fl->print($info,"\n");
	$fl->close;
	exit;
}

sub seriousError
{
	my $info=shift;
	my $now_string = strftime "%m_%d_%H_%M_%S\.dump", localtime;
	my $fl=new FileHandle(">$now_string");
	$fl->print($info,"\n");
	$fl->close;
}

1;