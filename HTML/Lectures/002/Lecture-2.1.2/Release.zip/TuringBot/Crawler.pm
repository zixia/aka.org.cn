package ECS::Crawler;

use ECS::Parser;				#	 HTML������	#
use ECS::Syslog;				#	  ��־����	#
use ECS::Utils;					#	  ��������	#
use ECS::DataBase;				#	  �����ݿ�	#
use ECS::Fetch;					#	  UserAgent	#
use ECS::Update;
use FileHandle;
use POSIX qw(strftime);

use Carp;

# E-Commerce Striper Lib by nullgate

# $Id: Crawler.pm,v 0.5 2000/06/23 10:20:02 gisle Exp $

$VERSION = sprintf("%d.%02d", q$Revision: 0.5 $ =~ /(\d+)\.(\d+)/);

use strict;
my $crawler=undef;
sub new
{
	my $class = shift;
	my %Config = @_;
	my $self = {};
	%{$self}=%Config;
	confess 'Please define a website first' if !$self->{'WebSite'};
	bless $self,$class;
	$self->{'Debug_Stack'}=[];			#	ͳ����Ϣ
	$self->{'IStack'}=[];				#	ͳ����Ϣ
	$self->{'URL_Stack'}=[];			#	ͳ����Ϣ
	$self->{'Debug_Stat'}={};			#	ͳ����Ϣ
	$self->{'Stat'}={};				#	ͳ����Ϣ
	$self->{'INIT_LEVEL'}=0;			#	��ڲ��
	$self->{'Mode'}=0;				#	����ģʽ
	dbsetting('data');				#	�趨����Ŀ¼
	$self->GetOpt() if @ARGV;
	if(!@ARGV)
	{
		system('cat readme');
		exit;
	}
	$self->{'Parser'}=new ECS::Parser;		#	��ʼ��������	
	$self->{'Fetcher'}=new ECS::Fetch('Stack'=>$self->{'URL_Stack'});		#	��ʼ��UserAgent
	$self->{'Fetcher'}->{'cached'}=1 if $self->{'Mode'}==1;
	if(!$self->{'Mode'})
	{
		#	��ʼ�����ݿ�����
		$self->{'DB'}=new ECS::Update('dbi:Oracle(AutoCommit=1):host=localhost;sid=ora8','nullgate','null2000','NA',$self->{'WebSite'});
		$self->{'DB_Stat'}=$self->{'DB'}->{'Stat'};
	}
	$crawler=$self;
    	return $self;
}

sub GetOpt
{
	my $self=shift;
	if($ARGV[0] eq 'D')
	{
		$self->{'Mode'}=1;
	}
	elsif($ARGV[0] eq 'R')				#Ԥ�����
	{
		print "Registering $self->{'WebSite'} by $0\n";
		my $status={'NEW'=>1,'filename'=>$0};
		dbupdate('registry',$self->{'WebSite'},$status);
		exit;
	}
	elsif($ARGV[0] eq 'S')				#Ԥ�����
	{
		print "STOP $self->{'WebSite'} by $0\n";
		my $status={'STOP'=>1,'filename'=>$0};
		dbupdate('registry',$self->{'WebSite'},$status);
		exit;
	}
	elsif($ARGV[0] eq 'T')
	{
		srand($$ ^ time);
		$self->{'Mode'}=2;
	}
	elsif($ARGV[0] eq 'G')
	{
		$self->{'Mode'}=0;
	}
	elsif($ARGV[0] eq 'O')
	{
		$self->show;
		exit;
	}
	elsif($ARGV[0] eq 'H')
	{
		$self->query;
		exit;
	}
	elsif($ARGV[0] eq 'E')
	{
		$self->end;
		exit;
	}
	elsif($ARGV[0] eq 'F')
	{
		$self->show;
		$self->query;
		exit;
	}
	else
	{
		system('cat readme');
		exit;
	}
	if($ARGV[1])
	{
		print "SWITCH TO ",$ARGV[1],"\n";
		if($ARGV[1]=~m{(http://[^']*)}i)
		{
			$self->{'URL'}=$1;
		}
	}

	if($ARGV[2])
	{
		if($ARGV[2]=~m{(^\d*$)}i)
		{
			print "INITIAL LEVEL=",$1,"\n";
			$self->{'INIT_LEVEL'}=$1;
		}
	}
}

sub query
{
	my $self=shift;
	my $name=$0;
	$name=~s{\./}{};
	my $ping=`ps -A | grep $name`;
	my @pings=split("\n",$ping);
	@pings=grep(($_=~s{\s(\d*).*}{$1},$_!=$$),@pings);
	print "������û�����У�\n" if !@pings;
	return 0 if !@pings;
	print "��",$pings[0],"\n";
	kill 1,$pings[0];
	sleep 3;
	system("cat $self->{'WebSite'}.report");
	unlink("$self->{'WebSite'}.report");
	return $pings[0];
}

sub end
{
	my $self=shift;
	my $pid=$self->query();
	return if !$pid;
	print "\n��ȷ���Ƿ�ֹͣ����ֹͣ��������վ����[$self->{'WebSite'}]��";
	my $pin=<STDIN>;
	$pin=~s{[\n\r\s]*$}{}sg;
	if($pin eq $self->{'WebSite'})
	{
		kill 2,$pid;
	}
	else
	{
		print "����...\n";
	}
}

sub launch
{
	my $self=shift;
	my $db=dbload($self->{'WebSite'});
	$self->{'Stat'}->{'PRE_TOTAL'}=$db->{'last_statics'}->{'TRIED'};
	$db=undef;
	&myLog($self->{'WebSite'},"started [Mode=$self->{'Mode'}]");	#	��¼��ʼ	
	if($self->{'Mode'})					
	{							
		my $fl=new FileHandle('>'.$self->{'WebSite'}.'.detail');	
		$fl->close;					
		$fl->open('>'.$self->{'WebSite'}.'.status');		
		$fl->close;					
	}
	else
	{
		unlink($self->{'WebSite'}.'.detail');
		unlink($self->{'WebSite'}.'.status');
	}
	$self->{'Stat'}->{'START_TIME'}=time;
	$SIG{HUP}=\&report;
	$SIG{INT}=\&death;
	eval{
		$self->iterate($self->{'URL'},0,$self->{'INIT_LEVEL'});
	    };
	#Ӧ���и���Ĵ�������
	print $@ if $@;
	&fatalError($self->{'WebSite'}.$@) if $@;			#	DUMP
	$self->statistics;						#	ͳ�ƽ��
}

sub report
{
	my $fl=new FileHandle(">$crawler->{'WebSite'}.report");
	print "CATCHED SIG\n";
	my $temp=$";
	$"=" �� ";
	my $info="";
	if(!$crawler->{'Mode'})
	{
		$info="��"."@{$crawler->{'Stack'}}"."\n��"."@{$crawler->{'IStack'}}"."\n�������ȣ�$crawler->{'cur_abs_depth'} �����ȣ�$crawler->{'cur_rel_depth'}\n����ַ��$crawler->{'cur_url'}\n";
		$info.="���".scalar localtime($crawler->{'Stat'}->{'START_TIME'})."��ʼ���У��Ѿ�������";
		my $gone=time - $crawler->{'Stat'}->{'START_TIME'};
		my $speed=$gone/$crawler->{'Stat'}->{'PAGE_TRIED'} if $crawler->{'Stat'}->{'PAGE_TRIED'};
		my $hour=int($gone/3600);
		$gone=$gone%3600;
		my $minute=int($gone/60);
		$gone=$gone%60;
		$info.="$hourСʱ" if $hour;
		$info.="$minute����" if $minute;
		$info.="$gone��" if $gone;
		$info.="\n�������$crawler->{'Stat'}->{'PAGE_TRIED'}��ҳ�棬�����$crawler->{'DB_Stat'}->{'TRIED'}����Ʒ���£�$crawler->{'DB_Stat'}->{'NEW'}����£�$crawler->{'DB_Stat'}->{'CHANGED'}����";
		$info.="\n�񱾴������ٶ�Ϊ".substr($speed,0,6)."��/ҳ";
		if($speed && $crawler->{'Stat'}->{'PRE_TOTAL'})
		{
			$gone=($crawler->{'Stat'}->{'PRE_TOTAL'}-$crawler->{'Stat'}->{'PAGE_TRIED'})*$speed;
			$hour=int($gone/3600);
			$gone=$gone%3600;
			$minute=int($gone/60);
			$gone=$gone%60;
			$info.="����Ҫ����Լ";
			$info.="$hourСʱ" if $hour;
			$info.="$minute����" if $minute;
			$info.="$gone��" if $gone;
			$info.='('.($crawler->{'Stat'}->{'PRE_TOTAL'}-$crawler->{'Stat'}->{'PAGE_TRIED'}).'ҳ)';
		}
		$info.="��";
	}
	else
	{
		$info="������ģʽ\n��"."@{$crawler->{'Stack'}}"."\n�������ȣ�$crawler->{'cur_abs_depth'} �����ȣ�$crawler->{'cur_rel_depth'}\n����ַ��$crawler->{'cur_url'}\n";
		$info.="���".scalar localtime($crawler->{'Stat'}->{'START_TIME'})."��ʼ���У��Ѿ�������";
		my $gone=time - $crawler->{'Stat'}->{'START_TIME'};
		my $speed=$gone/$crawler->{'Stat'}->{'PAGE_TRIED'} if $crawler->{'Stat'}->{'PAGE_TRIED'};
		my $hour=int($gone/3600);
		$gone=$gone%3600;
		my $minute=int($gone/60);
		$gone=$gone%60;
		$info.="$hourСʱ" if $hour;
		$info.="$minute����" if $minute;
		$info.="$gone��" if $gone;
		$info.="\n�������$crawler->{'Stat'}->{'PAGE_TRIED'}��ҳ�棬�����$crawler->{'Debug_Stat'}->{'REACHED'}����Ʒ��";
		$info.="\n�񱾴������ٶ�Ϊ".substr($speed,0,6)."��/ҳ��";
	}
	$fl->print($info,"\n");
	$"=$temp;
	$fl->close;
}	

sub death
{
	#todo
	exit;
}

sub error
{
	my $self=shift;
	if($self->{'Mode'})
	{
		$self->{'DB_Stat'}->{$_[0]}++;
		&append($self->{'WebSite'}.'.detail',$_[0]."\n"."@{$self->{'Stack'}}"." + "."@{$self->{'Debug_Stack'}}");
	}
	else
	{
		&recordException($self->{'WebSite'},$_[0]."\n"."@{$self->{'Stack'}}"."\n$self->{'cur_abs_depth'}|$self->{'cur_rel_depth'}|$self->{'cur_url'}");
	}
	return undef;
}

sub iterate
{
	my($self,$url,$abs_depth,$rel_depth)=@_;
	$self->{'cur_abs_depth'}=$abs_depth;
	$self->{'cur_rel_depth'}=$rel_depth;
	$self->{'cur_url'}=$url;
	my %visited=();
	$self->{'Stat'}->{'PAGE_TRIED'}++;
	my $show_url=$url;
	$show_url=~s{http://[^/]*}{}i;
	print "\n[$abs_depth][$rel_depth]$show_url STEP:[";
	print "A]";
	#$abs_depth,$rel_depthΪ���ԡ�������
	return $self->error("UNEXPECTED ABSOLUTE DEPTH")  if $abs_depth>$self->{'Max_Depth'};
	return $self->error("UNEXPECTED RELATIVE DEPTH")  if $rel_depth>$self->{'Max_Level'};
	print "\b\bB]";
	my $html='';
#	if($self->{'Mode'}!=1)
#	{
#		$html=$self->_fetch($url);
#	}
#	else
#	{
#		$html=fetch($url,$self->{'URL_Stack'}->[@{$self->{'URL_Stack'}}-1]);
#	}
	$html=$self->{'Fetcher'}->get_by_url($url);
	print "\b\bC]";
	return $self->error("NULL URL OR NET BROKEN\n") if !$html;
	my $result=undef;
	$result=$self->{'Parser'}->strip($html,'basehref'=>$url) if($rel_depth<$self->{'Max_Level'} || $self->{'parseData'});
	print "\b\bD]";
	print "\n" if $self->{'Mode'};
	#����ǽ��ҳ�棬���ý��з������������Խ�ʡ����ʱ�䡣
	my $i=$rel_depth;
	my $goodie=undef;
	if(!$self->{'Mode'})
	{
		for(;$i<=$self->{'Max_Level'};$i++)
		{
			print "\b\b$i]";
			$goodie=&{$self->{'Analyzers'}->[$i]}($self,$html,$url,$result);
			if(ref $goodie)
			{
				print "\b\bG]";
				my $temp='';
				$self->{'Stat'}->{'PAGE_VIEWED'}++;
				$i=1 if !$i;                            #��ҳִֻ��һ��
				my $counter=0;
				my $max=scalar @$goodie;
				foreach $temp(@$goodie)
				{
					$counter++;
					print $temp->{'content'};
					push @{$self->{'IStack'}},$counter.'/'.$max;
					push @{$self->{'Stack'}},$temp->{'content'};
					push @{$self->{'URL_Stack'}},$temp->{'href'};
					$self->iterate($temp->{'href'},$abs_depth+1+$temp->{'ITERAL'},$i+$temp->{'offset'}) if !$visited{$temp->{'href'}};
					pop @{$self->{'Stack'}};
					pop @{$self->{'URL_Stack'}};
					pop @{$self->{'IStack'}};
					$visited{$temp->{'href'}}=1 if $i+$temp->{'offset'}<$self->{'Max_Level'};
					#�ݹ飬�򵥵ط�ֹ�ظ����ӷ��ʡ�
				}
				return;
			}
			else
			{
				if($goodie eq 'OK')
				{
					$self->{'Stat'}->{'REACHED'}++;
					return;
				}
				elsif($goodie eq 'NO')
				{
					$self->{'Stat'}->{'FAILED'}++;
					return;
				}
				print "\b\bF]";
				#�ݹ鷵��
			}
		}
	}
	else
	{
		for(;$i<=$self->{'Max_Level'};$i++)
		{
			$goodie=&{$self->{'Analyzers'}->[$i]}($self,$html,$url,$result);
			if(ref $goodie)
			{
				my $temp='';
				$self->{'Debug_Stat'}->{"ABS $abs_depth TRIED"}++;
				$self->{'Debug_Stat'}->{"REL $rel_depth TRIED"}++;
				if(@$goodie)
				{
					$self->{'Debug_Stat'}->{"ABS $abs_depth PARSED"}++;
					$self->{'Debug_Stat'}->{"REL $rel_depth PARSED"}++;
					my $cur_index;
					my @todo;
					my $iindex=-1;
					foreach $temp(@$goodie)
					{
						$iindex++;
						$temp->{'index'}=$iindex;
					}
					foreach $temp(@{$self->{'Debug_Stack'}})
					{
						$cur_index+=$temp;
					}
					if(!$cur_index)		#��¼��һ����Ϣ
					{
						&append($self->{'WebSite'}.'.detail',"--== LEVEL $abs_depth ==--");
						foreach $temp(@$goodie)
						{
							&append($self->{'WebSite'}.'.detail',"$temp->{'content'} [$temp->{'href'}]");
						}
						$temp=shift @$goodie;
						push @todo,$temp;
					}
					else
					{
						&append($self->{'WebSite'}.'.detail',"PARSED: "."@{$self->{'Stack'}}"." + "."@{$self->{'Debug_Stack'}}");
					}
					
					
					if($self->{'Range'}->[$i]<0 || @$goodie<=$self->{'Range'}->[$i])
					{
						#��򵥵����
						push @todo,@$goodie;
					}
					elsif($self->{'Range'}->[$i])
					{
						#���Ǵ�����һҳ�����
						my @nextpage=grep($_->{'ITERAL'},@$goodie);
						my $flag=1;
						if(@nextpage)	#��һ��Ļ�������һҳ
						{
							if(rand() >= 0.5)
							{
								$flag=0;
								push @todo,@nextpage;
							}
							@$goodie=grep(!($_->{'ITERAL'}),@$goodie);
							
						}
						if($flag)
						{
							#���ѡȡһϵ����
							for($iindex=0;$iindex<$self->{'Range'}->[$i];$iindex++)
							{
								$cur_index=rand()*scalar(@$goodie);
								$cur_index=int $cur_index;
								push @todo,$goodie->[$cur_index];
								print "$goodie->[$cur_index]->{'index'} ADDED\n";
								splice(@$goodie,$cur_index,1);
							}
						}
					}
					
					$i=1 if !$i;                            #��ҳִֻ��һ��
					foreach $temp(@todo)
					{
						print $temp->{'content'};
						push @{$self->{'URL_Stack'}},$temp->{'href'};
						push @{$self->{'Stack'}},$temp->{'content'};
						push @{$self->{'Debug_Stack'}},$temp->{'index'};
						$self->iterate($temp->{'href'},$abs_depth+1+$temp->{'ITERAL'},$i+$temp->{'offset'}) if !$visited{$temp->{'href'}};
						pop @{$self->{'Debug_Stack'}};
						pop @{$self->{'Stack'}};
						pop @{$self->{'URL_Stack'}};
						$visited{$temp->{'href'}}=1 if $i+$temp->{'offset'}<$self->{'Max_Level'};
						#�ݹ飬�򵥵ط�ֹ�ظ����ӷ��ʡ�
					}
					return;
				}
				else
				{
					&append($self->{'WebSite'}.'.detail',"NO_RESULT: "."@{$self->{'Stack'}}"." + "."@{$self->{'Debug_Stack'}}"."\n$url\n");
					$self->{'Debug_Stat'}->{"ABS $abs_depth FAILED"}++;
					$self->{'Debug_Stat'}->{"REL $rel_depth FAILED"}++;
					return;
				}
			}
			else
			{
				if ($goodie eq 'OK')
				{
					&append($self->{'WebSite'}.'.detail',"REACHED: "."@{$self->{'Stack'}}"." + "."@{$self->{'Debug_Stack'}}");
					$self->{'Debug_Stat'}->{"REACHED"}++;
					return;
				}
				elsif($goodie eq 'NO')
				{
					&append($self->{'WebSite'}.'.detail',"FAILED: "."@{$self->{'Stack'}}"." + "."@{$self->{'Debug_Stack'}}");
					$self->{'Debug_Stat'}->{"FAILED"}++;
					return;
				}
				#�ݹ鷵��
			}
		}
		
	}
	$self->{'Stat'}->{'FAILED'}++;
	return $self->error("NOP");
}


sub statistics
{
	my $self=shift;
	if($self->{'Mode'})
	{
		my %result;
		my ($left,$right)=();
		&append($self->{'WebSite'}.'.status',"-==ORIGINAL STATUS==-");
		while(($left,$right)=each %{$self->{'Debug_Stat'}})
		{
			&append($self->{'WebSite'}.'.status',"$left = $ right");
			if($left=~m/REL.*TRIED/)
			{
				$result{'TRIED'}+=$right;
			}
			elsif($left=~m/REL.*PARSED/)
			{
				$result{'PARSED'}+=$right;
			}
			elsif($left=~m/REL.*FAILED/)
			{
				$result{'FAILED'}+=$right;
			}
		}
		$result{'REACHED'}=$self->{'Debug_Stat'}->{'REACHED'};
		&append($self->{'WebSite'}.'.status',"-==FINAL STATUS==-");
		while(($left,$right)=each %result)
		{
			&append($self->{'WebSite'}.'.status',"$left = $ right");
		}
		dbsetting('data');
		my $db=dbload($self->{'WebSite'});
		if(!$db->{'_isComplex_'})
		{
			$db={};
			$db->{'_isComplex_'}=1;
			dbsave($self->{'WebSite'},$db);
			#$db->{'total_statics'}={};
			#$db->{'last_statics'}={};
		}
		$db->{'verify'}={};
		%{$db->{'verify'}}=%result;
		$db->{'verify'}->{'pages'}=$self->{'Stat'}->{'PAGE_TRIED'};
		$db->{'verify'}->{'starttime'}=$self->{'Stat'}->{'START_TIME'};
		$db->{'verify'}->{'endtime'}=time;
		$db->{'verify'}->{'speed'}=($db->{'verify'}->{'endtime'}-$db->{'verify'}->{'starttime'})/$db->{'verify'}->{'pages'} if $db->{'verify'}->{'pages'};
		if(!$result{'REACHED'})
		{
			$db->{'verify'}->{'UNAVAILABLE'}=1;
		}
		dbsave($self->{'WebSite'},$db);
	}
	else
	{
		$self->{'Stat'}->{'END_TIME'}=time;
		my $db=dbload($self->{'WebSite'});
		if(! $db->{'_isComplex_'})
		{
			$db->{'_isComplex_'}=1;
			dbsave($self->{'WebSite'},$db);
		}
		$db->{'last_statics'}={};
		$db->{'last_statics'}->{'TIME'}=($self->{'Stat'}->{'END_TIME'}+$self->{'Stat'}->{'START_TIME'})/2;
		$db->{'last_statics'}->{'TIMECOST'}=$self->{'Stat'}->{'END_TIME'}-$self->{'Stat'}->{'START_TIME'};
		$db->{'last_statics'}->{'TRIED'}=$self->{'Stat'}->{'PAGE_TRIED'};
		$db->{'last_statics'}->{'REACHED'}=$self->{'Stat'}->{'REACHED'};
		$db->{'last_statics'}->{'FAILED'}=$self->{'Stat'}->{'FAILED'};
		$db->{'last_statics'}->{'PRODUCTS'}=$self->{'DB_Stat'}->{'TRIED'};
		$db->{'last_statics'}->{'CHANGED'}=$self->{'DB_Stat'}->{'CHANGED'};
		$db->{'last_statics'}->{'NEW'}=$self->{'DB_Stat'}->{'NEW'};
		$db->{'last_statics'}->{'OLD'}=$self->{'DB_Stat'}->{'OLD'};
		$db->{'last_statics'}->{'CHANGED'}=$self->{'DB_Stat'}->{'CHANGED'};
		$db->{'last_statics'}->{'SPEED'}=$db->{'last_statics'}->{'TIMECOST'}/$db->{'last_statics'}->{'PRODUCTS'} if $db->{'last_statics'}->{'PRODUCTS'};
		$db->{'last_statics'}->{'PAGESPEED'}=$db->{'last_statics'}->{'TIMECOST'}/$db->{'last_statics'}->{'TRIED'} if $db->{'last_statics'}->{'TRIED'};
		$db->{'last_statics'}->{'REFRESH_RATE'}=($db->{'last_statics'}->{'CHANGED'}+2*$db->{'last_statics'}->{'NEW'})/$db->{'last_statics'}->{'PRODUCTS'} if $db->{'last_statics'}->{'PRODUCTS'};
		$db->{'last_statics'}->{'QUALITY'}=$db->{'last_statics'}->{'PRODUCTS'}/$db->{'last_statics'}->{'TRIED'} if $db->{'last_statics'}->{'TRIED'};
		dbsave($self->{'WebSite'},$db);
		return		
	}
}

sub feed
{
	my $self=shift;
	my %Goods=@_;
	$self->validate(\%Goods) if $self->{'Mode'};
	if(!$self->{'Mode'})
	{
		if(!$Goods{'isBook'})
		{
			$self->{'DB'}->addGoods(%Goods);
		}
		else
		{
			$self->{'DB'}->addBooks(%Goods);
		}
	}
	my ($left,$right)=();
	return if $self->{'Mute'};
	print "\n";
	while(($left,$right)=each(%Goods))
	{
		print "�����ԡ�",substr($left,0,7),"\t$right\n";
	}
}

sub validate
{
	my $self=shift;
	my $Goods=shift;
	my @important=('Prize','URLDetail','URLBuy','Class','Name');
	my ($key,$value,$error)=();
	$error=0;
	foreach $key(@important)
	{
		if(!$Goods->{$key})
		{
			$error=1;
			$self->{'Debug_Stat'}->{"NO $key"}++;
			&append($self->{'WebSite'}.'.detail',"NO $key: "."@{$self->{'Stack'}}"." + "."@{$self->{'Debug_Stack'}}\n$self->{'cur_url'}");
		}
	}
	if ($error)
	{
		$self->{'Debug_Stat'}->{"Critical loss of data"}++;
		return;
	}
	foreach $key(@{$self->{'Validate'}})
	{
		if(!$Goods->{$key})
		{
			&append($self->{'WebSite'}.'.detail',"NO $key: "."@{$self->{'Stack'}}"." + "."@{$self->{'Debug_Stack'}}\n$self->{'cur_url'}");
			$error=1;
			$self->{'Debug_Stat'}->{"NO $key"}++;
		}
	}
	if ($error)
	{
		$self->{'Debug_Stat'}->{"Common loss of data"}++;
		return;
	}
	return 1;
}

sub show
{
	my $self=shift;
	my $content=dbload($self->{'WebSite'});
	if($content->{'verify'})
	{
		print "�����ԡ�\n";
		print "\t�ϴβ���ʱ��=",scalar localtime($content->{'verify'}->{'endtime'});
		if($content->{'verify'}->{'UNAVAILABLE'})
		{
			print "����ʧ��";
		}
		else
		{
			print "\n\t���ҳ����Ŀ��",$content->{'verify'}->{'pages'},"  \tҳ";
			print "\n\t�����Ʒ��Ŀ��",$content->{'verify'}->{'REACHED'},"  \t��";
			print "\n\t���ҳ���ٶȣ�",substr($content->{'verify'}->{'speed'},0,6),"\t��/ҳ��";
			print "\n\tʧ��ҳ����Ŀ��",$content->{'verify'}->{'FAILED'} if $content->{'verify'}->{'FAILED'};
		}
		print "\n";
	}
	else
	{
		print "�����ԡ���δ����\n";
	}
	if($content->{'last_statics'})
	{
		print "�����С�\n";
		print "\t�ϴ�����ʱ�䣺",scalar localtime($content->{'last_statics'}->{'TIME'});
		print "\n\t��������ʱ�䣺";
		my $gone=$content->{'last_statics'}->{'TIMECOST'};
		my $hour=int($gone/3600);
		$gone=$gone%3600;
		my $minute=int($gone/60);
		$gone=$gone%60;
		print "$hourСʱ" if $hour;
		print "$minute����" if $minute;
		print "$gone��" if $gone;
		print "\n\t���ҳ����Ŀ��",$content->{'last_statics'}->{'TRIED'},"  \tҳ";
		print "\n\t�����Ʒ��Ŀ��",$content->{'last_statics'}->{'PRODUCTS'},"  \t��";
		print "\n\t�²�Ʒ����Ŀ��",$content->{'last_statics'}->{'NEW'},"  \t��";
		print "\n\t���²�Ʒ��Ŀ��",$content->{'last_statics'}->{'CHANGED'},"  \t��";
		print "\n\t���ҳ���ٶȣ�",substr($content->{'last_statics'}->{'PAGESPEED'},0,6),"\t��/ҳ��";
		print "\n\t�����Ʒ�ٶȣ�",substr($content->{'last_statics'}->{'SPEED'},0,6),"\t��/��Ʒ";
	}
	print "\n";
	
}

sub DESTROY
{
	my $self=shift;
	$self->{'DB'}->DESTROY;
}

sub test
{
	1;
}

1;
