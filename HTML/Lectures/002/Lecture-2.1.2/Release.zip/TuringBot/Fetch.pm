package TuringBot::Fetch;
use FileHandle;
use LWP;
use strict;
use POSIX qw(strftime);
require HTTP::Cookies;

sub new
{
	my ($type,%Config)=@_;
	my $self={};
	my ($key,$value)=();
	while(($key,$value)=each(%Config))
	{
		$self->{$key}=$value;
	}
	$self->{'Stack'}||=[];
	#print ref $self->{'Stack'},"__\n";
	$self->{'wait_interval'}||=360;
	$self->{'wait_circle'}||=20;
	$self->{'retry'}||=3;
	$self->{'ua'}=new LWP::UserAgent;
	$self->{'ua'}->agent("GNU[BR]/0.001");
	$self->{'cookie'} = HTTP::Cookies->new;
	$self->{'ua'}->proxy(qw['http'],$self->{'proxy'}) if $self->{'proxy'};
	$self->{'ua'}->cookie_jar($self->{'cookie'});
	$self->{'ua'}->timeout(150);
	bless $self,$type;
	return $self;
}

sub fetch
{
	my $self=shift;
	my $url=shift;
	my $refer=shift if @_;
	my $req = new HTTP::Request GET => $url;
	$req->referer($refer) if $refer;
	my $res=$self->{'ua'}->request($req);
	if($res->is_success)
	{
		return $res->content;
	}
	else
	{
		return ;
	}
}

sub get_by_req
{
	my ($self,$req)=@_;
	my $res=$self->{'ua'}->request($req);
	if($res->is_success)
	{
		return $res->content;
	}
	else
	{
		return ;
	}
}

sub get_by_url
{
	my ($self,$url)=@_;
	my $temp=$url;
	if($self->{'cached'})
	{
		$temp=~s{http://}{}i;
		$temp=~s{[/.\:?]}{_}ig;
		$temp.='.html';
		if (-e "cache/$temp")
		{
			print "C";
			my $old=$/;
			$/=undef;
			my $fh=new FileHandle("cache/$temp");
			my $html=<$fh>;
			#print $html;
			$/=$old;
			$fh->close;
			return $html;
		}
	}
	my $req = new HTTP::Request GET => $url;
	#print $url,"\n";
	$req->referer($self->{'Stack'}->[@{$self->{'Stack'}}-1]) if @{$self->{'Stack'}};
	my ($i,$j,$result)=();
	for($i=1;$i<=$self->{'retry'};$i++)
	{
		$result=$self->get_by_req($req);
		if($result && $self->{'cached'})
		{
			my $fh=new FileHandle(">cache/$temp");
			print $fh $result;
			$fh->close;
		}
		return $result if $result;
		print 'x';
	}
	return if $self->{'cached'};
	if($self->is_alive($url))
	{
		return;
	}
	return if !$self->wait_site($url);
	for($i=1;$i<=$self->{'retry'};$i++)
	{
		$result=$self->get_by_req($req);
		return $result if $result;
		print 'x';
	}
	return;
}

sub wait_site
{
	my ($self,$url)=@_;
	my $i=undef;
	for($i=1;$i<=$self->{'wait_circle'};$i++)
	{
		return 1 if $self->is_alive($url);
		sleep($self->{'wait_interval'});
	}
	return 0;
}

sub is_alive
{
	my ($self,$url)=@_;
	$url=~m{://([^/]*)};
	my $host=$1;
	eval 
	{
		$SIG{CHLD}='IGNORE';
		$SIG{ALRM} = sub { die "alarm\n";};
		alarm(120);
		my $result=`ping $host -c 3`;
		alarm(0);
	};
	if($@)
	{
		my $ping=`ps -A | grep ping`;
		my @pings=split("\n",$ping);
		grep(($_=~s{\s(\d*).*}{$1},1),@pings);
		kill 9,$pings[0];
		return 0
	};
	return 1;
}

sub RefreshCookie
{
	my $self=shift;
	$self->{'cookie'}->DESTROY;
	$self->{'cookie'} = HTTP::Cookies->new;
	$self->{'ua'}->cookie_jar($self->{'cookie'});
}

sub Refresh
{
	my $self=shift;
	$self->{'ua'}->DESTROY;
	delete $self->{'ua'};
	$self->{'ua'}=new LWP::UserAgent;
	$self->{'ua'}->agent("GNU[BR]/0.001");
	$self->{'ua'}->proxy(qw['http'],$self->{'proxy'}) if $self->{'proxy'};
	$self->{'cookie'}->DESTROY;
	$self->{'cookie'} = HTTP::Cookies->new;
	$self->{'ua'}->cookie_jar($self->{'cookie'});
}
1;
