
//file gtk.c
//Compile gcc -o gtk gtk.c `gtk-config --cflags --libs`
//run: ./gtk

#include <locale.h>
#include <gtk/gtk.h>

int main (int argc, char *argv[])
{

    GtkWidget *window;
    GtkWidget *vbox;
    GtkWidget *entry;
    GtkWidget *text;
    GtkWidget *button;

    gtk_set_locale();
    gtk_init (&argc, &argv);
    gtk_rc_add_default_file("./gtkrc.zh");

    /* create a new window */
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
//    gtk_widget_set_usize( GTK_WIDGET (window), 200, 500);
    gtk_window_set_title(GTK_WINDOW (window), "GTK Entry");
    gtk_signal_connect(GTK_OBJECT (window), "delete_event",
                       (GtkSignalFunc) gtk_exit, NULL);

    vbox = gtk_vbox_new (FALSE, 0);
    gtk_container_add (GTK_CONTAINER (window), vbox);
    gtk_widget_show (vbox);

    entry = gtk_entry_new_with_max_length (60);
    gtk_entry_select_region (GTK_ENTRY (entry),
                             0, GTK_ENTRY(entry)->text_length);
    gtk_box_pack_start (GTK_BOX (vbox), entry, TRUE, TRUE, 0);
    gtk_widget_show (entry);

    text = gtk_text_new (NULL, NULL);
    gtk_text_set_editable (GTK_TEXT (text), TRUE);
    gtk_box_pack_start (GTK_BOX (vbox), text, TRUE, TRUE, 0);
    gtk_widget_show(text);

    button = gtk_button_new_with_label ("�رմ���");
    gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
                               GTK_SIGNAL_FUNC(gtk_exit),
                               GTK_OBJECT (window));
    gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
    GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
    gtk_widget_grab_default (button);
    gtk_widget_show (button);
    
    gtk_widget_show(window);

    gtk_main();
    return(0);
}


