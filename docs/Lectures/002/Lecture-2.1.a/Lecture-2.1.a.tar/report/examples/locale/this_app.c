
     //gcc -o this_app this_app.c

     /* file this_app.c */
     #include <locale.h>
     #include <libintl.h>
     #define _(String)  gettext(String)
     #define PACKAGE "this_app"

     int main(int argc, char **argv){
          setlocale(LC_ALL, "");    
          
          bindtextdomain(PACKAGE, "/usr/share/locale");
          textdomain(PACKAGE);

          printf(_("Test Message"));
     }


