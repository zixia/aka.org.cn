
#include <locale.h>
#include <stdio.h>
#include <time.h>

int main()
{
	time_t now;
	struct tm *tm;
	char buf[100];

	setlocale(LC_ALL, "");
	now = time(NULL);
	tm = localtime(&now);
	strftime(buf, sizeof(buf), "%c", tm);
	printf("%s\n", buf);
	return 0;
}
