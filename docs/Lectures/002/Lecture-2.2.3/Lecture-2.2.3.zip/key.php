<?

 $ZKeyPKey="THIS_IS_A_RANDOM_STRING_qeu82kmssd";

 function GetID()
 {
        global $ZKEY,$ZKeyPKey;

        if(strlen($ZKEY)<40)return "";

        $zks = explode('-',$ZKEY);

        $ID = $zks[0];
        $TM = substr($zks[1],0,strlen($zks[1])-3)+0;
        $MDK = $zks[2];

        if(($tm = time())-$TM>3600)return "";

        if(md5($ID."-".$zks[1]."-".$ZKeyPKey)!=$MDK)return "";

        $newkey = $ID."-".$tm."000-".md5($ID."-".$tm."000-".$ZKeyPKey);

        setcookie("ZKEY",$newkey,$tm+36000,"",".mydomain.com");

        return $ID;
 }

 function NewID($ID)
 {
        global $ZKEY,$ZKeyPKey;

        $tm = time();

        $newkey = $ID."-".$tm."000-".md5($ID."-".$tm."000-".$ZKeyPKey);

        setcookie("ZKEY",$newkey,$tm+36000,"",".mydomain.com");

        return $newkey;
 }

?>