<?
	include("sql.php");
	include("key.php");
	$err = "";
	if($add)
	{
		$mysql = mysql_connect($SQLHOST,$SQLUSER,$SQLPASS);
		if(!$mysql)
		{
			exit("���ݿⷱæ�����Ժ�");
		}
		else
		{
			$uid = strtolower($uid);
			$userPasswd = mysql_fetch_row(mysql_db_query('users',"SELECT MD5PASS FROM users WHERE USERID='$uid'",$mysql));
			if(!$userPasswd || strlen($userPasswd[0])!=32)
				$err .= "�û�������<BR>";
			else
			{
				if(md5($pass)!= $userPasswd[0])
					$err .= "���벻��ȷ<br>";
				else
				{
					NewID($uid);
					mysql_db_query('users',"UPDATE users SET LASTIP='$REMOTE_ADDR' WHERE USERID='$uid'",$mysql);
					echo "��¼�ɹ���";
				}
			}
			mysql_close($mysql);
		}
	}

?>
<?if($err)echo $err?>;
<FORM METHOD=POST>
<INPUT TYPE=HIDDEN NAME=add VALUE=1>
�˺� <INPUT NAME=uid><BR>
���� <INPUT NAME=pass TYPE=password><BR>
<INPUT TYPE=SUBMIT VALUE='��¼'>
</FORM>