<?
SQLHOST='localhost';
SQLUSER='webuser';
SQLPASS='myweb';
?>