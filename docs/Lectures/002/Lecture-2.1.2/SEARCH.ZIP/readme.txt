Search 2.02 -- February 7, 1998
-----------

Search 2.02 is a simple search engine for those who would like
users to be able to search their pages but don't need a heavy-duty
search engine.

Setup:

1. Place search.pl in your cgi-bin
2. Edit the variables at the beginning of the script.

	You may rename the script search.cgi if your server
	requires it.

If you only want to search the directory you set as "$basedir,"
use the following for the "paths" input:

	<input type=hidden name="paths" value="basedir">

Add directories to search using ";"s between the directories.  For
example:

	<input type=hidden name="paths" value="basedir;directory1;directory1/directory2;directory3">

All users must use the "logon" input.  The admin shoul leave this
input blank to search subdirectories of $basedir.


Features:

1. Can be set up to search multiple directories.
2. It extracts the actual title of the page and displays that as
	a link when the results are displayed.
3. Unauthorized searches are not possible.
4. Can be used by multiple users.
5. Can search more than one file type.


If you have any comments/suggestions, please go to 
http://www.zonecoaster.com/wwwboard/


Please do not redistribute this script.  I will happily give it
to anyone that requests it, but i would like to have control
over its distribution so that i can know where it is being
used and see how it is being used.


Thanks.
