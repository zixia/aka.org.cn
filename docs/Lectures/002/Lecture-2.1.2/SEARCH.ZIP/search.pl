#!/usr/bin/perl

#################################################################################################
#search.pl 2.02
#
#A simple script to search .html pages in a directory.
#written by Bernard Sowa <bernard@zonecoaster.com>
#Fabruary 7, 1998
#
#Please do not redistribute this script.
#
#Feel free to modify it as you wish, but if you do make any modifications, please
#submit them to me and I will give you credit in this section of the script.
#
#Thanks.  
#
#	DISCLAIMER:  I AM IN NO WAY RESPONSIBLE FOR ANY DAMAGE THIS SCRIPT MAY CAUSE
##################################################################################################

#################################################################################################
#Configuration
#
#$basedir
#	The base directory(absolute path) which contains all of the subdirectories you wish
#	to search
#
#	NOTICE $basedir HAS A TRAILING SLASH
#
#$imageurl
#	The url of a images
#
#$baseurl
#	The url onto which the subdirectories in @path are appended.
#
#	Notice that $baseurl INCLUDES THE TRAILING SLASH.
#
#	For Example:
#
#	If $basedir is /ROOT/LOCAL/USERS/ represented by $baseurl='http://yourhost.here/users/'
#	then JDOE's home directory would be /ROOT/LOCAL/USERS/JDOE/ and the link to all pages 
#	found in his directory which match the search string would be generated as 
#	"http://yourhost.here/JDOE/page.html".  
#
#	The script simply assumes that the directory 
#	structure of your system matches the URL mapping of your server software.
#	It just appends the user's home directory to $baseurl.
#
#$tilde
#	If user's home directories are called by,
#	http://yourhost.here/~jdoe/   , for example, set it to '~';
#	Pages containing the search string will be displayed with the "~" in place.
#
#$pub
#	If users have public_html as their home directories change this line to
#
#		$pub='public_html/';
#
#	the script will search $basedir$user/public_html/directory/path/
#	rather than $basedir$user/directory/path/
#
#$ending
#	The extension for files to search(html or htm--Don't include the period)
#
#@filetypes
#	Types of files that the script should search through(extensions).
#
#$valid
#	Valid URLs(HTTP Referers) that can search your site.  For example, if your
#	site is http://www.yoursite.com/you/  and you want only your pages to have access
#	to the script and search your directories, you could set $valid
#	to http://www.yoursite.com/you/  because all of your pages would have that part
#	in common.  If their in different directories, that will differ but the 
#	http://www.yoursite.com/you/ will always be there in the HTTP referer.
#
#$webmastername
#	The name of the person who owns the site that the script will be used on
#
#$webmastermail
#	The above person's email address.
#################################################################################################

$basedir = '/home/httpd/';
$imageurl = 'http://linux.cqi.com.cn/~elvis/flame.gif';
$tilde='~';	#either '' or '~'
$pub='public_html/';	#either '' or 'public_html/'
@filetypes=('html','txt','htm','shtml');
@valid=('linux.cqi.com.cn/~elvis/');
$webmastername='Elvis Tam';
$webmastermail='elvis@126.com';

#################################################################################################

#check if logon matches Referer URL
if($ENV{'HTTP_REFERER'} !~ /$baseurl\/$tilde$formdata{'logon'}/)
{
	print "Content-type: text/html\n\n";
	print "<html>\n<title>����</title>\n";
	print "<body bgcolor=\"\#ffffff\" text=\"\#000000\">\n\n";
	print "�����username.  ��ֻ���������� <b>�����ѵ�</b> ҳ��.\n";
	print "</ul>\n<center><hr width=50%></center>\n</html>";
	exit 0;
}

foreach $referer (@valid)
{
	if($ENV{'HTTP_REFERER'} =~ /$referer/)
	{
		$good_ref="yes";
	}
}
if($ARGV[0] eq "")
{
	if($good_ref ne "yes")
	{
		print "Content-type: text/html\n\n";
		print "<title>��  ��  ��</title>";
		print "<body bgcolor=\"\#ffffff\" text=\"\#000000\">";
		print "����ͼ�ڵ�ַ��������ű���URL ";
		print "��ʹ�ò��Ϸ��ı����������������߶��ǲ�������.";
		print "</html>\n";
		exit 0;
	}
}

#################################################################################################
#Get form data
#################################################################################################


if($ARGV[0] ne "")
{
	@bern=('search1','search','type','insensitive','user','','paths','basedir;guestbook');
	%formdata=@bern;
}
else
{
	&get_form_data;
}

#################################################################################################
#Check search string to see if it's worth searching for.
#################################################################################################

if ($formdata{'search1'} eq "" | $formdata{'search1'} =~ /^ /)
{
	print "Content-type: text/html\n\n";
	print "<title>Error!</title>";
	print "<body bgcolor=\"\#ffffff\" text=\"\#000000\">";
	if ($formdata{'search1'} eq "")
	{
		print "�㲢û�������κ��ַ�.";
	}
	else
	{
		print "��������ַ�ǰ���пո�.";
	}
	print '<p>';
	print '�밴"����"�İ�ť��ȥ�ٳ���.';
	print "����ϵϵͳ����Ա<a href=\"mailto:$webmastermail\">$webmastername</a> ";
	print "�������Ҫ��һ����Ԯ��.<p><br>";
	print "</html>";
	exit 0;
}
#################################################################################################
#Make array of directories to search.
#################################################################################################
else
{
	$user = $formdata{'logon'};
	$baseurl = $formdata{'baseurl'};

	if($formdata{'paths'} =~ /\;/)
	{
		@temppaths=split("\;",$formdata{'paths'});
		foreach $directory1 (@temppaths)
		{
			if($directory1 eq "basedir")
			{
				push(@paths,"basedir");
			}
			else
			{
				push(@paths,"$directory1/"); #put a slash onto the end of the directory name
			}
		}
	}
	else
	{
		push(@paths,"basedir");
	}

	$totalcount=0;

	#@paths is an array containing the directories to search.(with trailing slashes)
	#if user wants to search the base directory, the array also contains "basedir"

	print "Content-type: text/html\n\n";
	print "<title>�������</title>\n";
	print "<body bgcolor=\"\#ffffff\" text=\"\#000000\">\n";
	print "<h1>�������</h1>\n";
	print "<p>\n";
	print "������Ĺؼ��� <b>$formdata{'search1'}</b> �ڱ�վ�������������\n";
	print "<p>\n";
	print "<hr><br>\n";

	#Get list of all files of specified types
	#in the specified directories.
	foreach $directory (@paths)
	{
		foreach $filetype (@filetypes)
		{
			if ($user eq "")	#if being used to search $basedir
			{
				if($directory ne "basedir")
				{
					opendir(DIR,"$basedir$directory.") || &error("$basedir$directory");
				}
				else
				{
					opendir(DIR,"$basedir.") || &error("$basedir");
				}
			}
			else				#if being used by a regular user
			{
				if($directory ne "basedir")
				{
					opendir(DIR,"$basedir$user/$pub$directory.") || &error("$basedir$user/$pub$directory");
				}
				else
				{
					opendir(DIR,"$basedir$user/$pub.") || &error("$basedir$user/$pub");
				}
			}
			@nb=grep(/\.$filetype$/,readdir(DIR));
			foreach $thing (@nb)
			{
				if($user eq "")	#superuser
				{
					if($directory ne "basedir")
					{
						push(@names,"$basedir$directory$thing");
						push(@URLS,"$basedir$directory$thing","$baseurl$directory$thing");
					}
					else
					{
						push(@names,"$basedir$thing");
						push(@URLS,"$basedir$thing","$baseurl$thing");
					}
				}
				else				#regular user
				{
					if($directory ne "basedir")
					{
						push(@names,"$basedir$user/$pub$directory$thing");
						push(@URLS,"$basedir$user/$pub$directory$thing","$baseurl$directory$thing");
					}
					else
					{
						push(@names,"$basedir$user/$pub$thing");
						push(@URLS,"$basedir$user/$pub$thing","$baseurl$thing");
					}
				}
			}
			close(DIR);
		}#go to the next file in the directory
	}#go to the next directory and do it again.

	#@URLS contains "file location","file url"
	#@names contains "file location","file location2"...

	#Make @URLs associative so we can call up the URL just by using
	#the value int @names as the key.
	%URLS = @URLS;

	$tempcount=@names;
	$totfiles=$totfiles + $tempcount;

	#Now you have a list of the eligible files in the all of the directories.
	#Search each of them for the desired string.  If you find it, remember
	#the path and the name of the file and extract the title.

	foreach $file (@names)	#for each .html file in the array @names, do the following
	{
		$found="nothing";

		open (HTML,"$file") || &error("$file");
		@contents=<HTML>;	#Read the contents into an array
		close (HTML);		#so that you can work with it and close it.

		$phenom=join('',@contents);

		$numtimes=0;	#Will be used to count no. of occurrences

		if($formdata{'type'} eq "insensitive")		#If search type is "case insenstitive"
		{
			$numtimes++ while $phenom =~ /$formdata{'search1'}/gi;
			if($numtimes != 0)
			{
				++$totalcount;
			}
		}
		else						#if search type is "case-sensitive"
		{
			$numtimes++ while $phenom =~ /$formdata{'search1'}/g;
			if($numtimes != 0)
			{
				++$totalcount;
			}
		}
		if ($numtimes != 0)	#if search string is found, print link to the page
		{
			if($file =~ /htm.?$/i)
			{
				if ($phenom =~ /title/)
				{
					@a=split(/title\>/,$phenom);
					chop $a[1];
					chop $a[1];
					$b=$a[1];
				}
				elsif ($phenom =~ /TITLE/)
				{
					@a=split(/TITLE\>/,$phenom);
					chop $a[1];
					chop $a[1];
					$b=$a[1];
				}
				else
				{
					$b='NO TITLE';
				}
			}
			else
			{
				$b='NO TITLE';
			}
			#print the HTML for the file
			print "<br><img src=\"$imageurl\" alt=\"[\*]\"><a href=\"$URLS{$file}\">$b</a>\($numtimes ��\)\n";
		}
	}#Go to the next file in the list.

	if ($totalcount eq "0")
	{
		print "<center>û�з����κΰ����ؼ���Ϊ <b>$formdata{'search1'}</b> ���ļ�.</center>\n";
	}

	print "<hr><br>\n";
	print "<p><b>���������ļ���:</b> $totfiles\n";
	print "<br><b>��������:</b> case-$formdata{'type'}\n";
	print "<br><br><center>\n����ʽ�� <a href=\"http://oh.yeah.net/\">Oh Yeah Net</a>����<br></center>\n";
	print "</html>\n";
}
exit 0;

##########################################################################################
#Subroutines
##########################################################################################

sub get_form_data{

	@pairs=split(/\&/,$ENV{'QUERY_STRING'});
	foreach $pair (@pairs)
	{
		($name,$value) = split(/\=/,$pair);
		$name =~ s/\+/ /g;
		$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
		$value =~ s/~!/ ~!/g;
		$value =~ s/\+/ /g;
		$value =~ s/\r//g;
		push (@formdata,$name);
		push (@formdata,$value);
	}
	%formdata=@formdata;
	return %formdata;
}

sub error{
	print "<html>\n";
	print "<title>����</title>\n";
	print "<body bgcolor=\"\#ffffff\" text=\"\#000000\">\n";
	print "���ܴ�: $_[0]\n";
	print "</html>\n";
	exit 0;
}


#the end
