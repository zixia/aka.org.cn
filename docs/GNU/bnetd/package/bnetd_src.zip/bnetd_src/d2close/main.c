/*
 * Copyright (C) 1998  Mark Baysinger (mbaysing@ucsd.edu)
 * Copyright (C) 1998,1999,2000  Ross Combs (rocombs@cs.nmsu.edu)
 * Copyright (C) 2000  Onlyer (onlyer@263.net)
 * Some BITS modifications:
 * 		Copyright (C) 2000  Marco Ziech (mmz@gmx.net)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#include "config.h"
#include "setup.h"

#include <stdio.h>
#include <errno.h>

#define USE_STDDEF_HEADERS
#define USE_STDC_HEADERS
#define USE_STRING_HEADERS
#define USE_UNISTD_HEADERS
#define USE_FCNTL_HEADERS

#include "compat.h"

#include "compat/strerror.h"
#include "compat/strdup.h"

#include "hexdump.h"
#include "channel.h"
#include "game.h"
#include "versioncheck.h"
#include "server.h"
#include "eventlog.h"
#include "account.h"
#include "connection.h"
#include "virtconn.h"
#include "watch.h"
#include "timer.h"
#include "adbanner.h"
#include "game.h"
#include "version.h"
#include "eventlog.h"
#include "prefs.h"
#include "ladder.h"
#include "adbanner.h"
#include "ipban.h"
#include "gametrans.h"
#include "helpfile.h"
#include "chatcmd.h"
#include "d2ladder.h"
#include "d2server.h"


static void usage(char const * progname);


static void usage(char const * progname)
{
    fprintf(stderr,
	    "usage: %s [<options>]\n\n"
	    "    -c FILE, --config=FILE   use FILE as configuration file\n"
	    "    -d FILE, --hexdump=FILE  do hex dump of packets into FILE\n"
	    "    -m FILE, --mlog=FILE     memory use log into FILE\n"
#if defined(HAVE_FORK) && defined(HAVE_CHDIR) && (defined(HAVE_SETPGID) || defined(HAVE_SETPGRP))
	    "    -f, --foreground         don't daemonize\n"
#else
	    "    -f, --foreground         don't daemonize (default)\n"
#endif
	    "    -h, --help, --usage      show this information and exit\n"
	    "    -v, --version            print version number and exit\n",
	    progname);
    exit(1);
}


extern int main(int argc, char * argv[])
{
    int          a;
    char const * pidfile;
    char const * hexfile=NULL;
    char const * mlogfile=NULL;
    int          foreground=0;
    
    if (argc<1 || !argv || !argv[0])
    {
        fprintf(stderr,"bad arguments\n");
        return 1;
    }
    
    preffile = NULL;
    for (a=1; a<argc; a++)
        if (strncmp(argv[a],"--config=",9)==0)
        {
            if (preffile)
            {
                fprintf(stderr,"%s: configuration file was already specified as \"%s\"\n",argv[0],preffile);
                usage(argv[0]);
            }
	    preffile = &argv[a][9];
	}
        else if (strcmp(argv[a],"-c")==0)
        {
            if (a+1>argc)
            {
                fprintf(stderr,"%s: option \"%s\" requires an argument\n",argv[0],argv[a]);
                usage(argv[0]);
            }
            if (preffile)
            {
                fprintf(stderr,"%s: configuration file was already specified as \"%s\"\n",argv[0],preffile);
                usage(argv[0]);
            }
            a++;
	    preffile = argv[a];
        }
	else if (strncmp(argv[a],"--mlog=",7)==0)
	{
	    if (mlogfile) 
            {
                fprintf(stderr,"%s: configuration file was already specified as \"%s\"\n",argv[0],mlogfile);
                usage(argv[0]);
            }
	    mlogfile =&argv[a][7];
	}
	else if (strcmp(argv[a],"-m")==0)
	{
	    if (a+1>argc)
	    {
                fprintf(stderr,"%s: option \"%s\" requires an argument\n",argv[0],argv[a]);
                usage(argv[0]);
            }
            if (mlogfile)
            {
                fprintf(stderr,"%s: configuration file was already specified as \"%s\"\n",argv[0],mlogfile);
                usage(argv[0]);
            }
            a++;
	    mlogfile = argv[a];
	}
        else if (strncmp(argv[a],"--hexdump=",10)==0)
        {
            if (hexfile)
            {
                fprintf(stderr,"%s: configuration file was already specified as \"%s\"\n",argv[0],hexfile);
                usage(argv[0]);
            }
            hexfile = &argv[a][10];
        }
        else if (strcmp(argv[a],"-d")==0)
        {
            if (a+1>argc)
            {
                fprintf(stderr,"%s: option \"%s\" requires an argument\n",argv[0],argv[a]);
                usage(argv[0]);
            }
            if (hexfile)
            {
                fprintf(stderr,"%s: configuration file was already specified as \"%s\"\n",argv[0],hexfile);
                usage(argv[0]);
            }
            a++;
            hexfile = argv[a];
        }
        else if (strcmp(argv[a],"-f")==0 || strcmp(argv[a],"--foreground")==0)
            foreground = 1;
        else if (strcmp(argv[a],"-v")==0 || strcmp(argv[a],"--version")==0)
	{
            printf("version "BNETD_VERSION"\n");
            return 0;
	}
        else if (strcmp(argv[a],"-h")==0 || strcmp(argv[a],"--help")==0 || strcmp(argv[a],"--usage")==0)
            usage(argv[0]);
	else if (strcmp(argv[a],"--config")==0 || strcmp(argv[a],"--hexdump")==0)
	{
            fprintf(stderr,"%s: option \"%s\" requires and argument.\n",argv[0],argv[a]);
            usage(argv[0]);
	}
	else
        {
            fprintf(stderr,"%s: bad option \"%s\"\n",argv[0],argv[a]);
            usage(argv[0]);
        }
#ifdef USE_CHECK_ALLOC
    if (!mlogfile) check_set_file(NULL);
    else check_set_file(mlogfile);
#endif
    
    eventlog_set(stderr);
    /* errors to eventlog from here on... */
    
    if (preffile)
    {
	if (prefs_load(preffile)<0)
	{
	    eventlog(eventlog_level_error,"main","could not parse configuration file (exiting)");
	    return 1;
	}
    }
    else
	if (prefs_load(BNETD_DEFAULT_CONF_FILE)<0)
	    eventlog(eventlog_level_warn,"main","using default configuration");
    
    {
	char const * levels;
	char * temp;
	char * tok;
	
	eventlog_clear_level();
	if ((levels = prefs_get_loglevels()))
	{
	    if (!(temp = strdup(levels)))
	    {
		eventlog(eventlog_level_error,"main","could not allocate memory for temp (exiting)");
		return 1;
	    }
	    tok = strtok(temp,","); /* strtok modifies the string it is passed */
	    while (tok)
	    {
		if (eventlog_add_level(tok)<0)
		    eventlog(eventlog_level_error,"main","could not add log level \"%s\"",tok);
		tok = strtok(NULL,",");
	    }
	    free(temp);
	}
    }
    
    if (eventlog_open(prefs_get_logfile())<0)
    {
	if (prefs_get_logfile())
	    eventlog(eventlog_level_error,"main","could not use file \"%s\" for the eventlog (exiting)",prefs_get_logfile());
	else
	    eventlog(eventlog_level_error,"main","no logfile specified in configuration file \"%s\" (exiting)",preffile);
	return 1;
    }
    
    /* eventlog must go to log file from here on... */
    
#if defined(HAVE_FORK) && defined(HAVE_CHDIR) && (defined(HAVE_SETPGID) || defined(HAVE_SETPGRP))
    if (!foreground)
    {
	if (chdir("/")<0)
	{
	    eventlog(eventlog_level_error,"main","could not change working directory to / (chdir: %s)",strerror(errno));
	    return 1;
	}
	
	switch (fork())
	{
	case -1:
	    eventlog(eventlog_level_error,"main","could not fork (fork: %s)",strerror(errno));
	    return 1;
	case 0: /* child */
	    break;
	default: /* parent */
	    return 0;
	}
	
	close(0); /* stdin */
	close(1); /* stdout */
	close(2); /* stderr */
	
# ifdef HAVE_SETPGID
	if (setpgid(0,0)<0)
	{
	    eventlog(eventlog_level_error,"main","could not create new process group (setpgid: %s)",strerror(errno));
	    return 1;
	}
# else
#  ifdef HAVE_SETPGRP
#   ifdef SETPGRP_VOID
        if (setpgrp()<0)
        {
            eventlog(eventlog_level_error,"main","could not create new process group (setpgrp: %s)",strerror(errno));
            return 1;
        }
#   else
	if (setpgrp(0,0)<0)
	{
	    eventlog(eventlog_level_error,"main","could not create new process group (setpgrp: %s)",strerror(errno));
	    return 1;
	}
#   endif
#  endif
# endif
    }
#endif
    
    pidfile = strdup(prefs_get_pidfile());
    if (pidfile[0]=='\0')
    {
	free((void *)pidfile);
	pidfile = NULL;
    }
    
    if (pidfile)
    {
#ifdef HAVE_GETPID
	FILE * fp;
	
	if (!(fp = fopen(pidfile,"w+")))
	{
	    eventlog(eventlog_level_error,"main","unable to open pid file \"%s\" for writing (fopen: %s)",pidfile,strerror(errno));
	    free((void *)pidfile);
	    pidfile = NULL;
	}
	else
	{
	    fprintf(fp,"%u",(unsigned int)getpid());
	    if (fclose(fp)<0)
		eventlog(eventlog_level_error,"main","could not close pid file \"%s\" after writing (fclose: %s)",pidfile,strerror(errno));
	}
#else
	eventlog(eventlog_level_warn,"main","no getpid() system call, disable pid file in bnetd.conf");
	free((void *)pidfile);
	pidfile = NULL;
#endif
    }
    
#ifdef HAVE_GETPID
    eventlog(eventlog_level_info,"main","bnetd version "BNETD_VERSION" process %u",(unsigned int)getpid());
#else
    eventlog(eventlog_level_info,"main","bnetd version "BNETD_VERSION);
#endif
    eventlog(eventlog_level_info,"main","logging event levels: %s",prefs_get_loglevels());
    
    if (hexfile) {
	if (!(hexstrm = fopen(hexfile,"a")))
	    eventlog(eventlog_level_error,"main","could not open file \"%s\" for writing the hexdump (fopen: %s)",hexfile,strerror(errno));
	else {
	    fprintf(hexstrm,"# dump generated by bnetd version "BNETD_VERSION"\n");
	}
    }
    
    connlist_create();
    virtconnlist_create();
    gamelist_create();
    channellist_create();
    d2servlist_create();
    timerlist_create();
    watchlist_create();

    if (helpfile_init(prefs_get_helpfile())<0)
	eventlog(eventlog_level_error,"main","could not load helpfile");
    if (ipbanlist_load(prefs_get_ipbanfile())<0)
	eventlog(eventlog_level_error,"main","could not load IP ban list");
    if (adbannerlist_create(prefs_get_adfile())<0)
	eventlog(eventlog_level_error,"main","could not load adbanner list");
    if (gametrans_load(prefs_get_transfile())<0)
	eventlog(eventlog_level_error,"main","could not load gametrans list");
    if (chatfile_init(prefs_get_chatfile())<0)
	eventlog(eventlog_level_error,"main","could not load chatfile");
    if (versioncheck_load(prefs_get_versionfile())<0)
	eventlog(eventlog_level_error,"main","could not load version file");

    
    accountlist_load_default();

    if  (prefs_allow_preload_account()) accountlist_create();
    else accountlist_create_empty();

    ladderlist_create();
    d2ladder_init();
    
    /* now process connections and network traffic */
    if (server_process()<0)
    {
        eventlog(eventlog_level_info,"main","failed to initialize network (exiting)");
	if (pidfile)
	{
	    if (remove(pidfile)<0)
		eventlog(eventlog_level_error,"main","could not remove pid file \"%s\" (remove: %s)",pidfile,strerror(errno));
	    free((void *)pidfile);
	}
        return 1;
    }
    
    eventlog(eventlog_level_info,"main","unloading user accounts");
    ladderlist_destroy();
    accountlist_destroy();
    accountlist_unload_default();
    
    watchlist_destroy();
    timerlist_destroy();

    d2ladder_unload();
    gametrans_unload();
    versioncheck_unload();
    adbannerlist_destroy();
    ipbanlist_unload();
    helpfile_unload();
    channellist_destroy();
    gamelist_destroy();
    d2servlist_destroy();
    connlist_destroy();
    virtconnlist_destroy();
    
    if (hexstrm)
    {
	fprintf(hexstrm,"# end of dump\n");
	if (fclose(hexstrm)<0)
	    eventlog(eventlog_level_error,"main","could not close hexdump file \"%s\" after writing (fclose: %s)",hexfile,strerror(errno));
    }
    
    eventlog(eventlog_level_info,"main","server has shut down");
    if (pidfile)
    {
	if (remove(pidfile)<0)
	    eventlog(eventlog_level_error,"main","could not remove pid file \"%s\" (remove: %s)",pidfile,strerror(errno));
	free((void *)pidfile);
    }
    
    prefs_unload();
#ifdef USE_CHECK_ALLOC
    check_cleanup();
#endif

    return 0;
}
