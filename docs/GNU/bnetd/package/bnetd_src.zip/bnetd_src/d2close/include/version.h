#ifndef BNETD_VERSION
# define BNETD_VERSION "0.1.0pre1"
#endif
