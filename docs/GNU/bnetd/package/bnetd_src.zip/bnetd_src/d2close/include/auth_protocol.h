/*
 * Copyright (C) 2000  Ross Combs (rocombs@cs.nmsu.edu)
 * Copyright (C) 2000  Onlyer (onlyer@263.net)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#ifndef INCLUDED_AUTH_PROTOCOL_TYPES
#define INCLUDED_AUTH_PROTOCOL_TYPES

#ifdef JUST_NEED_TYPES
#include "bn_type.h"
#else
#define JUST_NEED_TYPES
#include "bn_type.h"
#undef JUST_NEED_TYPES
#endif


/*
 * The "auth" protocol that is used for holding profiles on the server.
 * FIXME: put the #define's into the PROTO section
 */


/******************************************************/
typedef struct
{
    bn_short size;
    bn_byte  type;
} t_auth_header;
/******************************************************/


/******************************************************/
typedef struct
{
    t_auth_header h;
} t_auth_generic;
/******************************************************/


/******************************************************/
/*
3a 00 01 01 00 00 00 fa   9e 0d d1 d8 94 f6 07 f6    :...............
0f 08 00 00 00 00 00 42   1b 00 00 b2 7e 27 44 d5    .......B....~'D.
c5 fb 07 fa 9e bf 63 1b   57 1b 69 7f 4f a9 c0 b8    ......c.W.i.O...
83 e9 4c 4d 6f 4e 6b 32   6b 00                      ..LMoNk2k.

3a 00 01 01 00 00 00 06   ed 68 67 d8 94 f6 07 89    :........hg.....
6a 21 00 00 00 00 00 91   20 00 00 62 d5 f7 e4 e4    j!...... ..b....
b1 df c4 a5 1c 65 bd 67   98 17 89 2c 1f 19 53 24    .....e.g...,..S$
d0 08 2f 4e 6f 6d 61 64   58 00                      ../NomadX.
*/
#define CLIENT_AUTHLOGINREQ 0x01
typedef struct
{
    t_auth_header h;
    bn_int        unknown1; /* seq number? */ /* from 0x35ff packet */
    bn_int        unknown2; /* from 0x35ff packet */
    bn_int        unknown3; /* from 0x35ff packet */
    bn_int        sessionkey; /* from 0x35ff packet */
    bn_int        unknown5; /* 00 00 00 00 */ /* from 0x35ff packet */
    bn_int        unknown6; /* hash salt? */ /* from 0x35ff packet */
    bn_int        secret_hash[5]; /* from 0x35ff packet */
    bn_int        unknown7; /* _bucky_ No friggin clue what it is... */
    /* character name */
} t_client_authloginreq;
/******************************************************/


/******************************************************/
/*
07 00 01 00 00 00 00                                 .......

07 00 01 0c 00 00 00                                 .......
*/
#define SERVER_AUTHLOGINREPLY 0x01
typedef struct
{
    t_auth_header h;
    bn_int        reply;
} t_server_authloginreply;
#define SERVER_AUTHLOGINREPLY_REPLY_SUCCESS 0x00000000
#define SERVER_AUTHLOGINREPLY_REPLY_BADPASS 0x0000000c /* FIXME: guess.. maybe alreadylogged in */
                                                       /* _bucky_ D2DV v1.02 inteprets as "Banned from b.net" */
/******************************************************/


/******************************************************/
/*
0f 00 02 01 00 00 00 00   00 42 4e 45 54 44 00       .........BNETD.

0d 00 02 00 00 00 00 00   00 61 73 64 00             .........asd.

0e 00 02 00 00 00 00 00   00 71 77 65 72 00          .........qwer.

0e 00 02 04 00 00 00 00   00 51 6c 65 78 00          .........Qlex.

0f 00 02 02 00 00 00 00   00 42 65 6e 6e 79 00       .........Benny.

11 00 02 02 00 00 00 00   00 54 68 6f 72 73 65 6e    .........Thorsen
00                                                   .

12 00 02 03 00 00 00 00   00 51 6c 65 78 54 45 53    .........QlexTES
54 00                                                T.

12 00 02 01 00 00 00 00   00 51 6c 65 78 54 45 53    .........QlexTES
54 00                                                T.

10 00 02 01 00 00 00 00   00 53 68 61 6d 61 72 00    .........Shamar.

0e 00 02 01 00 00 00 00   00 4b 75 72 74 00          .........Kurt.

0e 00 02 01 00 00 00 00   00 42 65 6e 74 00          .........Bent.


hardcore char create
00000030                    13 00 02 01 00 00 00 04 00 6F       .........o
00000040  6E 6C 79 65 72 2D 74 68 00                      nlyer-th.       

	    
*/
#define CLIENT_CREATECHARREQ 0x02
typedef struct
{
    t_auth_header h;
    bn_short      class;
    bn_short	  unknown1;
    bn_short	  type;		/* 0x0=Normal 0x4=hardcore ,the same as in .d2s file */
    /* character name */
} t_client_createcharreq;
#define CLIENT_CREATECHARREQ_CLASS_AMAZON    0x0000
#define CLIENT_CREATECHARREQ_CLASS_SORCERESS 0x0001
#define CLIENT_CREATECHARREQ_CLASS_NECRO     0x0002
#define CLIENT_CREATECHARREQ_CLASS_PALADIN   0x0003
#define CLIENT_CREATECHARREQ_CLASS_BARBARIAN 0x0004

/******************************************************/


/******************************************************/
/*
07 00 02 00 00 00 00                                 .......

07 00 02 14 00 00 00                                 .......
*/
#define SERVER_CREATECHARREPLY 0x02
typedef struct
{
    t_auth_header h;
    bn_int        reply;
} t_server_createcharreply;
#define SERVER_CREATECHARREPLY_REPLY_SUCCESS	0x00000000
#define SERVER_CREATECHARREPLY_REPLY_ERROR	0x00000001
#define SERVER_CREATECHARREPLY_REPLY_NOTFOUND   0x00000046

/******************************************************/


/******************************************************/
/*
17 00 03 1A 00 00 10 00   00 01 FF 08 46 64 67 00    ............Fdg.
44 67 00 64 66 67 00                                 Dg.dfg.

13 00 03 1B 00 00 10 00   00 01 FF 08 42 6C 6F 70    ............Blop
00 00 00                                             ...

13 00 03 02 00 00 10 00   00 01 FF 08 54 65 73 74    ............Test
00 00 00                                             ...

1F 00 03 02 00 00 10 00   00 01 05 08 53 74 66 75    ............Stfu
00 42 75 73 74 61 00 68   65 79 20 66 30 30 00       .Busta.hey f00.

33 00 03 02 00 00 10 00   00 01 FF 08 47 61 6D 65    3...........Game
6E 61 6D 65 00 50 61 73   73 77 6F 72 64 66 69 65    name.Passwordfie
6C 64 00 47 61 6D 65 44   65 73 63 72 69 70 74 69    ld.GameDescripti
6F 6E 00                                             on.

0030  44 3E 6C FB 00 00 32 00  03 02 00 00 00 00 00 01   D>l...2.........
0040  62 05 47 61 6D 65 6E 61  6D 65 00 50 61 73 73 77   b.Gamename.Passw
0050  6F 72 64 00 74 68 69 73  20 69 73 20 61 20 74 65   ord.this.is.a.te
0060  73 74 20 67 61 6D 65 00                            st.game.

hell game: test,8 level diff,4 maxchar
0030  43 F8 57 E3 00 00 13 00  03 06 00 00 20 00 00 01   C.W.............
0040  08 04 54 65 73 74 00 00  00                        ..Test...

nightmare game: test
0030  43 B2 67 C0 00 00 13 00  03 08 00 00 10 00 00 01   C.g.............
0040  08 04 54 65 73 74 00 00  00                        ..Test...




*/
#define CLIENT_CREATEGAMEREQ 0x03
typedef struct
{
    t_auth_header h;
    bn_short      seqno;   /* 02 00, 1b 00, 1a 00 */ /* sequence no? */
    bn_byte       unknown1;   /* always zero */
    bn_byte	  difficulty;   
    bn_short      unknown2;   /* always zero?                             */
    bn_byte       unknown3;   /* Difficulty                               */
    bn_byte       leveldiff;  /* Only allow people of +/- n level to join */
    bn_byte       maxchar;    /* Maximum number of chars allowed in game  */
    /* game name */
    /* game pass */
    /* game desc */
} t_client_creategamereq;
#define CLIENT_CREATEGAMEREQ_UNKNOWN1             0x0200
#define CLIENT_CREATEGAMEREQ_UNKNOWN2             0x0010
#define CLIENT_CREATEGAMEREQ_UNKNOWN3             0x0000
#define CLIENT_CREATEGAMEREQ_DIFFICULTY_NORMAL    0x00
#define CLIENT_CREATEGAMEREQ_DIFFICULTY_NIGHTMARE 0x10
#define CLIENT_CREATEGAMEREQ_DIFFICULTY_HELL	  0x20
#define CLIENT_CREATEGAMEREQ_LEVELDIFF_ANY        0xff
/******************************************************/


/******************************************************/
/*
0d 00 03 02 00 00 00 00   00 1f 00 00 00             .............

0d 00 03 02 00 41 23 00   00 00 00 00 00             .....A#......

0030  22 38 DF 28 00 00 0D 00  03 0C 00 53 00 00 00 00   "8.(.......S....
0040  00 00 00  
from fsgs -- create ok,failed join

0030  22 38 DD 18 00 00 0D 00  03 10 00 00 00 00 00 1F   "8..............
0040  00 00 00                                           ...
already exist the same name

0030  22 38 DA 9E 00 00 0D 00  03 1C 00 56 00 00 00 00   "8.........V....
0040  00 00 00                                           ...
ok

no new game can be created now
0030  FF 11 2A 89 00 00 0D 00  03 2C 00 00 00 00 00 20   ..*......,......
0040  00 00 00                                           ...

*/
#define SERVER_CREATEGAMEREPLY 0x03
typedef struct
{
    t_auth_header h;
    bn_short      seqno; /* sequence no? same as client? */
    bn_int	  token;
    bn_int        reply; /* reply? */
} t_server_creategamereply;
#define SERVER_CREATEGAMEREPLY_REPLY_OK			0x00000000
#define SERVER_CREATEGAMEREPLY_REPLY_ERROR		0x00000001
#define SERVER_CREATEGAMEREPLY_REPLY_INVALID_NAME	0x0000001e
#define SERVER_CREATEGAMEREPLY_REPLY_NAME_EXIST		0x0000001f	/* game exist */
#define SERVER_CREATEGAMEREPLY_REPLY_DISABLE		0x00000020

/******************************************************/

/*
wait in line

0030  FF 88 93 7B 00 00 07 00  14 16 01 00 00            ...{.........

*/
#define SERVER_CREATEGAME_WAIT	    0x14
typedef struct
{
    t_auth_header h;
    bn_int	  position;	/* position of in line to create a game	*/
} t_server_creategame_wait;



#define CLIENT_CANCEL_CREATE	    0x13
typedef struct
{
    t_auth_header   h;
} t_client_cancel_create;

/******************************************************/
/*
10 00 04 03 00 53 74 66   75 00 42 75 73 74 61 00    .....Stfu.Busta.


0030  44 31 88 20 00 00 17 00  04 03 00 47 61 6D 65 6E   D1.........Gamen
0040  61 6D 65 00 50 61 73 73  77 6F 72 64 00            ame.Password.


*/
#define CLIENT_JOINGAMEREQ2 0x04
typedef struct
{
    t_auth_header h;
    bn_short      seqno;
    /* game name */
    /* game pass */
} t_client_joingamereq2;
/******************************************************/


/******************************************************/
/*
15 00 04 03 00 ce 00 00   00 d8 94 f6 34 af f9 07    ............4...
10 00 00 00 00                                       .....


0030  22 38 D6 97 00 00 15 00  04 0B 00 00 00 00 00 00   "8..............
0040  00 00 00 00 00 00 00 2A  00 00 00                  .......*...
game not exist

0030  22 38 CE 34 00 00 15 00  04 1D 00 00 00 00 00 C3   "8.4............
0040  8F 81 73 56 00 00 00 00  00 00 00                  ..sV.......
join ok	 0x56 is from creategame

this is later in game server to check the sessionnumber

srv		      97 00  00 00 00 00               "8..........

cli		      61 56 00 00 00 00 00 01 03 00   Da.3..aV........
    00 00 6F 6E 6C 79 65 72 2D 63 68 6E 00 00 24 E0   ..onlyer-chn..$.
    B8 05                                              ..


*/
#define SERVER_JOINGAMEREPLY2 0x04
typedef struct
{
    t_auth_header h;
    bn_short      seqno; /* same as request unknown1? */
    bn_int        unknown2;
    bn_int        addr; /* game server IP (port is 4000) */ /* 216 148 246 52 */
			/* if the reply is error,should also make the addr to be zero */
			/* the client will examine addr first,if non-zero,then join ok */
    bn_int        token;
    bn_int        reply;
} t_server_joingamereply2;
#define SERVER_JOINGAMEREPLY2_UNKNOWN2			0x00000000
#define SERVER_JOINGAMEREPLY2_REPLY_PASS_ERROR	        0x00000029
#define SERVER_JOINGAMEREPLY2_REPLY_NOT_EXIST	        0x0000002a
#define SERVER_JOINGAMEREPLY2_REPLY_GAME_FULL	        0x0000002b
#define SERVER_JOINGAMEREPLY2_REPLY_LEVEL_LIMIT		0x0000002c
#define SERVER_JOINGAMEREPLY2_REPLY_OK		   	0x00000000
#define SERVER_JOINGAMEREPLY2_REPLY_ERROR   	   	0x00000001

/******************************************************/


/******************************************************/
/*
send(socket 0x00000314, flags 0x00000000) returned 0xa bytes:
0x0000: 0a 00 05 05 00 00 00 00   00 00                      ..........

send(socket 0x00000314, flags 0x00000000) returned 0xa bytes:
0x0000: 0a 00 05 06 00 00 00 00   00 00                      ..........	


client game list request
*/
#define CLIENT_D2GAMELISTREQ 0x05		
typedef struct
{
    t_auth_header h;
    bn_short      seqno;
    bn_int        unknown2;	    /* always zero */
    bn_byte	  unknown3;
} t_client_d2gamelistreq;
/******************************************************/


/******************************************************/
/*
37 00 05 05 00 a8 32 00   00 01 04 10 00 00 49 6e    7.....2.......In
65 65 64 61 6d 75 6c 65   74 00 6f 66 66 65 72 69    eedamulet.offeri
6e 67 20 67 6f 6c 64 2f   72 61 72 65 2f 73 65 74    ng gold/rare/set
20 69 74 65 6d 73 00 16   00 05 05 00 a4 32 00 00     items.......2..
01 04 10 00 00 50 6f 6f   70 6f 6f 00 00 17 00 05    .....Poopoo.....
05 00 9f 32 00 00 01 04   10 00 00 42 61 6c 6c 65    ...2.......Balle
72 61 00 00 1a 00 05 05   00 9c 32 00 00 01 04 10    ra........2.....
00 00 41 65 72 6f 6e 20   54 65 73 74 00 00 13 00    ..Aeron Test....
05 05 00 9b 32 00 00 02   04 10 00 00 46 75 6e 00    ....2.......Fun.
00 18 00 05 05 00 98 32   00 00 01 04 10 00 00 4f    .......2.......O
70 65 6e 00 6f 70 65 6e   00 1c 00 05 05 00 86 32    pen.open.......2
00 00 03 04 10 00 00 4a   75 73 74 20 50 6c 61 79    .......Just Play
69 6e 67 00 00 16 00 05   05 00 85 32 00 00 01 04    ing........2....
10 00 00 59 61 68 6f 6f   6f 00 00 29 00 05 05 00    ...Yahooo..)....
82 32 00 00 03 04 10 00   00 4c 65 74 27 73 20 4b    .2.......Let's K
69 63 6b 20 41 7a 65 00   41 6c 6c 20 57 65 6c 63    ick Aze.All Welc
6f 6d 65 00 1c 00 05 05   00 80 32 00 00 03 04 10    ome.......2.....
00 00 44 32 69 00 4a 6f   69 6e 20 61 6c 6c 21 00    ..D2i.Join all!.
1b 00 05 05 00 7d 32 00   00 07 04 10 00 00 54 72    .....}2.......Tr
61 64 65 73 20 52 20 55   73 00 00                   ades R Us..

17 00 05 05 00 5e 32 00   00 03 04 10 00 00 48 75    .....^2.......Hu
6e 74 65 72 73 00 00                                 nters..

                          11 00 05 06 00 00 00 00    ..Mcaw..........
00 02 00 00 00 00 00 00   00                         .........


server_game_list_reply


no new game can create

0030  FF 62 26 2E 00 00 10 00  05 24 00 00 00 00 00 00   .b&......$......
0040  FF FF FF FF 00 00                                  ......


0030  FF 62 25 A9 00 00 10 00  05 25 00 00 00 00 00 74   .b%......%.....t
0040  FF FF FF FF 00 00                                  ......



*/
#define SERVER_D2GAMELISTREPLY 0x05
typedef struct
{
    t_auth_header h;
    bn_short      seqno; /* same as request? sequence no? */
    bn_int	  token;
    bn_byte	  currchar;
    bn_int	  unknown1;
    /* string game name,	0x0 ends */
    /* string game description, 0x0 ends */
} t_server_d2gamelistreply;
#define SERVER_D2GAMELISTREPLY_UNKNOWN1	  0x00001004
#define SERVER_D2GAMELISTREPLY_UNKNOWN1_END 0x00000000
/******************************************************/


/******************************************************/
/*
0A 00 06 55 00 4E 6F 70   65 00                      ...U.Nope.

09 00 06 34 00 4B 6F 62   00                         ...4.Kob.

server game details request
*/
#define CLIENT_GAMEINFOREQ 0x06
typedef struct
{
    t_auth_header h;
    bn_short       seqno; /* sequence no? */
    /* game name */
} t_client_gameinforeq;
/******************************************************/


/******************************************************/
/*
38 00 06 04 00 04 10 00   00 02 03 04 CC CC CC CC    8...............
CC CC CC CC CC CC CC CC   CC CC 11 08 CC CC CC CC    ................
CC CC CC CC CC CC CC CC   CC CC 00 54 55 52 42 4F    ...........TURBO
00 44 61 50 69 6D 70 00                              .DaPimp.

58 00 06 66 00 04 10 00   00 06 04 04 00 01 03 03    X..f............
CC CC CC CC CC CC CC CC   CC CC 10 08 13 10 14 0D    ................
CC CC CC CC CC CC CC CC   CC CC 00 50 79 6E 65 4B    ...........PyneK
6E 6F 74 00 44 61 50 69   6D 70 00 43 61 6C 6C 65    not.DaPimp.Calle
73 74 6F 00 42 6C 61 69   72 00 4C 79 6F 72 61 6E    sto.Blair.Lyoran
00 53 4F 50 48 41 4C 00                              .SOPHAL.

server game details reply

0030  22 38 21 52 00 00 3A 00  06 0C 00 5C 00 00 00 00   "8.R..:....\....
0040  00 00 00 01 04 04 01 03  00 00 00 00 00 00 00 00   ................
0050  00 00 00 00 00 00 00 01  00 00 00 00 00 00 00 00   ................
0060  00 00 00 00 00 00 00 00  47 6F 6C 64 6D 61 6E 00   ........Goldman.
0070                                                     
etime 0:0:0, level 1-5, up to 4 players, Goldman level 1 paladin

*/

#define SERVER_GAMEINFOREPLY	0x06
typedef struct
{
    t_auth_header h;
    bn_short      seqno; /* sequence no? same as client? */
    bn_int        token;
    bn_int	  etime;
    bn_byte	  gamelevel;
    bn_byte	  leveldiff;
    bn_byte	  maxchar;
    bn_byte	  currchar;
    bn_byte	  class[16];
    bn_byte	  level[16];
    bn_byte	  unknown1;
    /* characters */
} t_server_gameinforeply;


/******************************************************/



/******************************************************/
#define CLIENT_CHARNAMEREQ  0x07
typedef struct
{
    t_auth_header h;
    /*  charname */
} t_client_charnamereq;
/******************************************************/


/******************************************************/
/*
07 00 07 00 00 00 00                                 .......
*/
#define SERVER_CHARNAMEREPLY 0x07
typedef struct
{
    t_auth_header h;
    bn_int        reply;  /* reply? */
} t_server_charnamereply;

#define SERVER_CHARNAMEREPLY_SUCCESS	    0x00000000
#define SERVER_CHARNAMEREPLY_ERROR	    0x00000001	/* need disconnect client */

/******************************************************/


/*
send(socket 0x00000370, flags 0x00000000) returned 0x5 bytes:
0x0000: 05 00 0a 00 00                                       .....

recv(socket 0x00000370, flags 0x00000000) returned 0x9 bytes:
0x0000: 09 00 0a 00 00 00 00 00   00                         .........
*/

/******************************************************/
/*
13: recv class=auth[0x0006] type=unknown[0x0011] length=4
0000:   04 00 11 0A                                          ....
13: recv class=auth[0x0006] type=unknown[0x0011] length=4
0000:   04 00 11 0B                                          ....
*/
#define CLIENT_LADDERINFOREQ	    0x11
typedef struct /* FIXME: ladder request? */
{
    t_auth_header h;
    bn_byte       type;
} t_client_ladderinforeq;
/******************************************************/
#define D2LADDERINFO_HC_OVERALL		    0x0
#define D2LADDERINFO_HC_CLASS_AM	    0x1
#define D2LADDERINFO_HC_CLASS_SO	    0x2
#define D2LADDERINFO_HC_CLASS_NE	    0x3
#define D2LADDERINFO_HC_CLASS_PA	    0x4
#define D2LADDERINFO_HC_CLASS_BA	    0x5

#define D2LADDERINFO_STD_OVERALL	    0x9
#define D2LADDERINFO_STD_CLASS_AM	    0xA
#define D2LADDERINFO_STD_CLASS_SO	    0xB
#define D2LADDERINFO_STD_CLASS_NE	    0xC
#define D2LADDERINFO_STD_CLASS_PA	    0xD
#define D2LADDERINFO_STD_CLASS_BA	    0xE


/******************************************************/
/*
1.standard - by class
0A- class ama
0B- class sor
0C- class nec
0D- class pal
0E- class bar

0030  FF 94 17 FB 00 00 2A 01  11 0A 20 01 20 01 00 00   ......*.........
0040  0A 00 00 00 10 00 00 00  BC 13 BD 60 00 00 00 00   ...........`....
0050  00 0C 5A 00 53 68 61 76  65 6E 61 00 00 00 00 00   ..Z.Shavena.....
0060  00 00 00 00 74 7B B5 60  00 00 00 00 00 0B 5A 00   ....t{.`......Z.
0070  4E 69 63 6F 6C 65 5F 41  70 70 6C 65 74 6F 6E 00   Nicole_Appleton.
0080  E5 44 02 50 00 00 00 00  00 0B 57 00 43 61 72 79   .D.P......W.Cary
0090  00 00 00 00 00 00 00 00  00 00 00 00 B0 39 BF 4E   .............9.N
00A0  00 00 00 00 00 0C 57 00  41 6C 63 79 6E 6F 65 00   ......W.Alcynoe.
00B0  00 00 00 00 00 00 00 00  B4 A7 F2 4A 00 00 00 00   ...........J....
00C0  00 0B 57 00 41 6C 61 65  73 69 61 00 00 00 00 00   ..W.Alaesia.....
00D0  00 00 00 00 A3 49 91 4A  00 00 00 00 00 0C 57 00   .....I.J......W.
00E0  76 61 6C 6B 65 72 69 65  00 00 00 00 00 00 00 00   valkerie........
00F0  83 CE F5 47 00 00 00 00  00 0C 56 00 76 61 6E 64   ...G......V.vand
0100  65 6E 62 65 72 67 00 00  00 00 00 00 7C 52 D6 47   enberg......|R.G
0110  00 00 00 00 00 0B 56 00  50 69 77 69 2D 57 75 72   ......V.Piwi-Wur
0120  73 74 00 00 00 00 00 00  6E 5F 64 46 00 00 00 00   st......n_dF....
0130  00 0C 56 00 4B 69 65 66  65 72 48 75 62 5F 41 00   ..V.KieferHub_A.
0140  00 00 00 00 F9 55 73 45  00 00 00 00 00 0C 56 00   .....UsE......V.
0150  74 61 61 72 6E 61 41 4D  00 00 00 00 00 00 00 00   taarnaAM........
0160                                                     

for by class-each class shows 10 chars
for by overall-altogether showes 50 chars
each page shows about 14 chars

hc-class header is   20 01 20 01 00 00 0A 00 00 00 10 00 00 00
hc-overall header is 80 05 90 01 00 00 32 00 00 00 10 00 00 00

std-class is the same as hc-class
std-overall the same as hc-overall

*/
#define SERVER_LADDERINFOREPLY	 0x11
typedef struct
{
    t_auth_header h;
    bn_byte       type; 
    bn_short	  total_len;
    bn_short      len;
    bn_short      cont_len;
    bn_int        total_count;
    bn_int        unknown3; /* count? */
} t_server_ladderinforeply;
#define SERVER_LADDERINFOREPLY_UNKNOWN3		    0x00000010

typedef struct
{
    bn_int	exp;
    bn_int	unknown1;   /* always zero */
    bn_byte	class;	    /* high 4 bit is for hardcore status, 0x3? means hardcore died */
			    /* 0x2? means hardcore alive */
    bn_byte	title;	    /* the same code as in .d2s files */
    bn_byte	level;	    
    bn_byte	unknown2;   /* always zero */
    char        charname[16];
} t_server_ladderinfo_entry;


#define CLIENT_AUTHMOTDREQ	    0x12
typedef struct
{
    t_auth_header   h;
} t_client_authmotdreq;


#define SERVER_AUTHMOTDREPLY	    0x12
typedef struct
{
    t_auth_header   h;
    bn_byte	    unknown1;	    /* flag to control the following char ? */
				    /* unknown1 any char works */
    /* a string message	*/
} t_server_authmotdreply;
    
#define SERVER_AUTHMOTDREPLY_UNKNOWN1	0x00


/*
0030  44 69 9D 5C 00 00 0A 00  07 6F 6E 6C 79 65 72 00   Di.\.....onlyer.
*/



#define CLIENT_DELCHARREQ	    0x0a
typedef struct
{
    t_auth_header   h;
    /* string char name */
} t_client_delcharreq;


#define SERVER_DELCHARREPLY	    0x0a

typedef struct
{
    t_auth_header   h;
    bn_int	    reply;
} t_server_delcharreply;

#define SERVER_DELCHARREPLY_SUCCESS 0x00000000
#define SERVER_DELCHARREPLY_ERROR   0x00000001

#endif
