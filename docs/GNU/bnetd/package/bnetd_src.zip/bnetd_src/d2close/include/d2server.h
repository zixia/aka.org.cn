/*
 * Copyright (C) 2000  Onlyer (onlyer@263.net)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#ifndef INCLUDED_D2SERVER_TYPES
#define INCLUDED_D2SERVER_TYPES

#define USE_TIME_HEADERS
#include "compat.h"

typedef enum
{
    d2server_status_none,
    d2server_status_connected,
    d2server_status_connecting
} t_d2server_status; 


typedef struct d2serv_info
#ifdef D2SERVER_INTERNAL_ACCESS
{
    unsigned int      	id;
    t_d2server_status   status;
    unsigned int      	tsocket;
    unsigned int      	maxgame;
    unsigned int      	gamenum;
    unsigned int      	token;
    time_t	      	lasttest;
} 
#endif
t_d2serv_info;


#endif

#ifndef JUST_NEED_TYPES
#ifndef INCLUDED_D2SERVER_PROTOS
#define INCLUDED_D2SERVER_PROTOS

#ifdef JUST_NEED_TYPES
#define USE_TIME_HEADERS
#include "compat.h"

#include "addr.h"
#else
#define USE_TIME_HEADERS
#include "compat.h"
#define JUST_NEED_TYPES
#include "addr.h"
#undef JUST_NEED_TYPES
#endif


extern t_addrlist * d2servlist(void);
extern int d2servlist_create(void);
extern int d2servlist_destroy(void);
extern int d2servlist_add_server(char const * servname);
extern int d2servlist_del_server(unsigned int id);
extern int d2servlist_retest(void);
extern t_addr * d2servlist_choose_server(void);
extern t_addr * d2servlist_get_server_by_id(unsigned int id);

extern int d2server_create_info(t_addr * addr);
extern int d2server_destroy(t_addr * addr);
extern int d2server_connect(t_addr * addr);
extern unsigned int d2server_get_id(t_addr * addr);
extern t_d2server_status d2server_get_status(t_addr * addr);
extern int d2server_set_status(t_addr * addr, t_d2server_status status);
extern int d2server_set_gamenum(t_addr * addr, unsigned int gamenum);
extern int d2server_get_gamenum(t_addr * addr);
extern int d2server_set_token(t_addr * addr, unsigned int token);
extern int d2server_get_token(t_addr * addr);
extern unsigned int d2server_get_socket(t_addr * addr);
extern time_t d2server_get_lasttest(t_addr * addr);
extern int d2server_set_lasttest(t_addr * addr, time_t lasttest);
extern unsigned int d2server_get_maxgame(t_addr * addr);
extern int d2server_set_maxgame(t_addr * addr, unsigned int maxgame);


#endif
#endif

