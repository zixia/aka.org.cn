/*
 * Copyright (C) 2000  Onlyer (onlyer@263.net)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#ifndef INCLUDED_D2CHARFILE_TYPES
#define INCLUDED_D2CHARFILE_TYPES

#ifdef JUST_NEED_TYPES
#include "bn_type.h"
#else
#define JUST_NEED_TYPES
#include "bn_type.h"
#undef JUST_NEED_TYPES
#endif

#define D2CHARFILE_PADBYTE              0xff


typedef struct d2save_chargfx
{
    bn_byte	    helmgfx;
    bn_byte	    bodygfx;
    bn_byte	    leggfx;
    bn_byte	    lhandgfx;
    bn_byte	    rhandgfx;
    bn_byte	    lhandweapon;
    bn_byte	    rhandweapon;
    bn_byte	    unknown1;
    bn_byte	    lpadgfx;
    bn_byte	    rpadgfx;
    bn_int	    unknown2;
    bn_short	    unknown3;
}
t_d2save_chargfx;

typedef struct d2save_charcolor
{
    bn_byte	    helmcolor;
    bn_byte	    bodycolor;
    bn_byte	    legcolor;
    bn_byte	    lhandcolor;
    bn_byte	    rhandcolor;
    bn_byte	    lhandweapon;
    bn_byte	    rhandweapon;
    bn_byte	    unknown1;
    bn_byte	    lpadcolor;
    bn_byte	    rpadcolor;
    bn_int	    unknown2;
    bn_short	    unknown3;
} t_d2save_charcolor;

/* color mask code -- each color spreaded with a range
    0x25-0x27    blue
    0x28-0x2A	 red
    0x2B-0x2D    green
    0x2E-0x30	 yellow
    0x31-0x33	 purple 
*/

/* Partial weapon code list:
          0x2f: 1H Axe
          0x30: 1H Sword
          0x50: 2H Staff
          0x51: Another 2H Staff
          0x52: Another 2H Staff
          0x53: Another 2H Staff
          0x54: 2H Axe
          0x55: Scythe
          0x56: empty?
          0x57: Another 2H Axe
          0x58: Halberd?
          0x59: empty?
          0x5a: Another 2H Axe
          0x5b: Another Halberd
          0x5c: empty?
          0x5d: 1H club?
          0x5e: empty?
          0x5f: empty?
*/




/* The ONLY 0x00 that should appear should be the terminating NUL for  */
/* the character name string and the guild tag string, they're used as */
/* delimiters to seperate character name and the character structure   */
/* If you got any other NUL's in here the next character's info will   */
/* be royally fucked up - using 0x01 or 0xff for unknowns seem to work */
/* well                                                                */
typedef struct
{
    /* "RealmName,CharacterName" - for closed characters */
    /* - OR -                                            */
    /* "CharacterName" - for open characters             */
    /* - strlen(CharacterName) must be <= 15 -           */
    bn_byte unknownb1;     /* 0x83, 0x87? */
    bn_byte unknownb2;     /* 0x80...? */
    t_d2save_chargfx  gfx;
    bn_byte class;     /* 0x01=Amazon, 0x02=Sor, 0x03=Nec, 0x04=Pal, 0x05=Bar */
    t_d2save_charcolor color;
    
    bn_byte level;     /* yes, byte, not short/int/long  */
    bn_byte status;    /* 0x01-03 = Norm & alive         */
                       /* 0x04-07 = HC & alive           */
                       /* 0x08-0b = Norm & "dead"?       */
                       /* 0x0c+   = HC & dead, chat only */
                       /* Add 0x80 to get same effect    */
			/* 0x80 - 0x83 for Normal & alive
			   0x84 - 0x87 for HC & alive
			   0x88 - 0x8b for Normal & dead
			   0x8c - 0x8f for HC & dead
			   only low 4 bit have effect
			   the same as the status bit in .d2s file
			*/
    bn_byte title;     /* 0x00-01=none 02-03=Sir/Dame 04-05=Lord 06-07=Baron */
			/* 0x80 - 0x87 for None	    
			   0x88 - 0x8f for Sir/Dame/		/Count/Countess/
			   0x90 - 0x97 for Lord/Lady/		/Duke/Duchess/
			   0x98 - 0x9f for Baron/Baroness/	/King/Queen
			   9f +	Baron
			   in .d2s file:
			   00-03 None 04-07 Sir 08-0b Lord 0c-0f Baron
			   10+ Baron
			*/
                       /* Same codes for HC chars                            */
                       /* Add 0x80 to get same effect    */
    bn_byte unknownb13;
    bn_byte emblembgc; /* Guild emblem background colour */
    bn_byte emblemfgc; /* Guild emblem foreground colour */
    bn_byte emblemnum; /* Guild emblem type number       */
    
/* emblem number corresponds to D2DATA.MPQ/data/global/ui/Emblems/iconXXa.dc6 */
/* where XX = emblem number - 1 (ie, 0x0A corresponds to icon09a.dc6) use     */
/* for dummy values seem safe... 0x01 won't work, you'll get an emblem...     */
    
    bn_byte unknownb14;
    bn_byte end;
    bn_int  exp;	/* the data below end is not sent to client,just for server */
    /* Guild Tag */

} t_d2char_info;



typedef bn_basic  t_d2save_header[8];

#define D2SAVE_HEADER	"\x55\xaa\x55\xaa\x47\x0\x0\x0"
#define D2SAVE_GAMEDATA_HEADER	    "Woo!\x6\x0\x0\x0"
#define D2SAVE_GAMEDATA_LEN	    8
#define D2SAVE_NEWBIE_SIZE	    130
#define D2SAVE_MIN_SIZE		    657

typedef bn_basic  t_d2save_name[16];

typedef struct 
{
    t_d2save_header h;
    t_d2save_name   name;
    bn_byte	    status;
    bn_byte	    title;
    bn_int	    unknown1;	    /* 00 00 DD 00 */
    bn_short	    char_ver;	    /* 10 00 */
    bn_short	    unknown4;	    /* 82 00 */
    bn_short	    class;	/* then same as in t_d2char_info,but reduce 1    */
    bn_short	    level;
    t_d2save_chargfx  gfx;
    t_d2save_charcolor color;
    /* others seems not important to the game server */
    /* just bypass them				     */
    char	    data[D2SAVE_MIN_SIZE];
} t_d2save;

#define D2SAVE_STATUS_HCALIVE	 0x04
#define D2SAVE_STATUS_NORMALIVE	 0x01
#define D2SAVE_FLAG_OFFSET	 0x232
#define D2SAVE_EXP_OFFSET	 0x269
#define D2SAVE_EXPFLAG_MASK	 0x2000


#endif


#ifndef JUST_NEED_TYPES
#ifndef INCLUDED_D2CHARFILE_PROTOS
#define INCLUDED_D2CHARFILE_PROTOS

#ifdef JUST_NEED_TYPES
#include "account.h"
#else
#define JUST_NEED_TYPES
#include "account.h"
#undef JUST_NEED_TYPES
#endif


extern int d2char_addchar(t_account * account,char const * charname,\
			  unsigned short class,int hardcore);
extern int d2char_delchar(t_account * account,char const * charname,int listonly);
extern int d2char_findcharfile(char const * charname);
extern int d2char_findchar(t_account * account,char const * charname);
extern int d2char_getnumber(t_account * account);
extern t_d2char_info * d2char_getcharinfo(char const * charname);
extern int d2char_setcharinfo(char const * charname,char * info);
extern char const * d2char_getrealmname(char const * charname);
extern unsigned int d2char_getlevel(char const * charname);
extern unsigned int d2char_getclass(char const * charname);
extern unsigned int d2char_gethardcore(char const * charname);
extern unsigned int d2char_gettitle(char const * charname);

#endif
#endif

