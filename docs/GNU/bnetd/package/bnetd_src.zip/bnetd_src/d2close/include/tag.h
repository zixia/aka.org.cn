/*
 * Copyright (C) 1998  Mark Baysinger (mbaysing@ucsd.edu)
 * Copyright (C) 1998,1999,2000  Ross Combs (rocombs@cs.nmsu.edu)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#ifndef INCLUDED_TAG_TYPES
#define INCLUDED_TAG_TYPES

/* Software tags */
#define CLIENTTAG_BNCHATBOT "CHAT" /* CHAT bot */
#define CLIENTTAG_STARCRAFT "STAR" /* Starcraft (original) */
#define CLIENTTAG_BROODWARS "SEXP" /* Starcraft EXpansion Pack */
#define CLIENTTAG_SHAREWARE "SSHR" /* Starcraft Shareware */
#define CLIENTTAG_DIABLORTL "DRTL" /* Diablo ReTaiL */
#define CLIENTTAG_DIABLOSHR "DSHR" /* Diablo SHaReware */
#define CLIENTTAG_WARCIIBNE "W2BN" /* WarCraft II Battle.net Edition */
#define CLIENTTAG_STARJAPAN "JSTR" /* FIXME: Starcraft Japan? */
#define CLIENTTAG_DIABLOII  "D2DV" /* Diablo II */

/* Architecture tags */
#define ARCHTAG_INTEL       "IX86" /* Windows on Intel X86 */
#define ARCHTAG_PRC         "PMAC" /* MacOS   on PowerPC   */

/* Server tag */
#define BNETTAG "bnet" /* Battle.net */

/* Filetype tags (note these are "backwards") */
#define EXTENSIONTAG_PCX "xcp."
#define EXTENSIONTAG_SMK "kms."

#endif
