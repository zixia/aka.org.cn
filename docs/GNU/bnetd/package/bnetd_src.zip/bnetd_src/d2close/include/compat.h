/*
 * Copyright (C) 2000  Onlyer (onlyer@263.net)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#include "compat/oscompat.h"
#ifdef USE_STDDEF_HEADERS
# ifdef HAVE_STDDEF_H
#   include <stddef.h>
# else
#   ifndef NULL
#     define NULL ((void *)0)
#   endif
# endif
#undef USE_STDDEF_HEADERS
#endif

#ifdef USE_STDC_HEADERS
# ifdef STDC_HEADERS
#   include <stdlib.h>
# else
#   ifdef HAVE_MALLOC_H
#     include <malloc.h>
#   endif
# endif 
# undef USE_STDC_HEADERS
#endif

#ifdef USE_STRING_HEADERS
# ifdef HAVE_STRING_H                                                                         
#   include <string.h>                                                                         
# else                                                                                        
#   ifdef HAVE_STRINGS_H                                                                       
#     include <strings.h>                                                                       
#   endif                                                                                      
# endif
# undef USE_STRING_HEADERS
#endif

#ifdef USE_TIME_HEADERS
# ifdef TIME_WITH_SYS_TIME                                                                    
#   include <sys/time.h>                                                                       
#   include <time.h>                                                                           
# else                                                                                        
#   ifdef HAVE_SYS_TIME_H                                                                      
#     include <sys/time.h>                                                                      
#   else                                                                                       
#     include <time.h>                                                                          
#   endif                                                                                      
# endif
# undef USE_TIME_HEADERS
#endif                                                                                       


#ifdef USE_SIGNAL_HEADERS
# if defined(HAVE_SIGACTION) && defined(HAVE_SIGPROCMASK) && defined(HAVE_SIGADDSET)
#  include <signal.h>
#  include "compat/signal.h"
# endif
# undef USE_SIGNAL_HEADERS
#endif

#ifdef USE_SOCKET_HEADERS
# ifdef HAVE_SYS_SOCKET_H
#  include <sys/socket.h>
# endif
# include "compat/socket.h"
# ifdef HAVE_NETINET_IN_H
#  include <netinet/in.h>
# endif
# include "compat/netinet_in.h"
# ifdef HAVE_ARPA_INET_H
#  include <arpa/inet.h>
# endif
# include "compat/inet_ntoa.h"
# ifdef HAVE_NETDB_H
#  include <netdb.h>
# endif
# undef USE_SOCKET_HEADERS
#endif

#ifdef USE_SYS_TYPES_HEADERS
# ifdef HAVE_SYS_TYPES_H
#  include <sys/types.h>
# endif
# undef USE_SYS_TYPES_HEADERS
#endif

#ifdef USE_MEMORY_HEADERS
# ifdef HAVE_MEMORY_H
#  include <memory.h>
# endif
# undef USE_MEMORY_HEADERS
#endif

#ifdef USE_SELECT_HEADERS
# ifdef HAVE_SYS_SELECT_H
#  include <sys/select.h>
# endif
# undef USE_SELECT_HEADERS
#endif

#ifdef USE_SYS_PARAM_HEADERS
# ifdef HAVE_SYS_PARAM_H
#  include <sys/param.h>
# endif
# undef USE_SYS_PARAM_HEADERS
#endif

#ifdef USE_UNISTD_HEADERS
# ifdef HAVE_UNISTD_H
#  include <unistd.h>
# endif
# undef USE_UNISTD_HEADERS
#endif

#ifdef USE_FCNTL_HEADERS
# ifdef HAVE_FCNTL_H
#  include <fcntl.h>
# endif
# undef USE_FCNTL_HEADERS
#endif

#ifdef USE_SYS_STAT_HEADERS
# ifdef HAVE_SYS_STAT_H
#  include <sys/stat.h>
# endif
# ifdef WIN32
#  include <io.h>
# endif
# undef USE_SYS_STAT_HEADERS
#endif

#ifdef USE_STDARG_HEADERS
# ifdef HAVE_STDARG_H
#  include <stdarg.h>
# else
#  ifdef HAVE_VARARGS_H
#   include <varargs.h>
#  endif
# endif
#undef USE_STDARG_HEADERS
#endif

#ifdef USE_SYS_WAIT_HEADERS
# ifdef HAVE_SYS_WAIT_H
#  include <sys/wait.h>
# endif
#undef USE_SYS_WAIT_HEADERS
#endif

#ifdef USE_UNAME_HEADERS
# ifdef HAVE_SYS_UTSNAME_H
#  include <sys/utsname.h>
# endif
# include "compat/uname.h"
#undef USE_UNAME_HEADERS
#endif
