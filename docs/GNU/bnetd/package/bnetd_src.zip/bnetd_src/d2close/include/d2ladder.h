/*
 * Copyright (C) 2000  Onlyer (onlyer@263.net)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "list.h"
#include "d2charfile.h"

#define D2LADDER_OVERALL_LEN	    50
#define D2LADDER_CLASS_LEN	    10
#define D2LADDER_PACKET_LEN	    14


typedef struct
{
    char	    charname[16];
    unsigned int    exp;
    unsigned int    class;
    unsigned int    title;
    unsigned int    status;
    unsigned int    level;

} t_d2ladder_info;

typedef struct
{
    unsigned int type;
    t_d2ladder_info * info;
    unsigned int len;
} t_d2ladder;

typedef t_list t_d2ladderlist;


extern int d2ladder_insert_item(char const * charname,t_d2char_info * info,unsigned int type);
extern t_d2ladder * d2ladderlist_find_type(unsigned int type);
extern int d2ladder_sort(unsigned int type);
extern int d2ladder_create(void);
extern int d2ladder_loadinfo(void);
extern void d2ladder_unload_data(void);
extern void d2ladder_unload(void);
extern int d2ladder_limit(unsigned int type);
extern int d2ladder_init(void);
extern t_d2ladderlist * d2ladder_getlist(void);
