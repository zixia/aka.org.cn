/*
 * Copyright (C) 1998,1999,2000  Ross Combs (rocombs@cs.nmsu.edu)
 * Copyright (C) 1999  Rob Crittenden (rcrit@greyoak.com)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#ifndef INCLUDED_SETUP_H
#define INCLUDED_SETUP_H

/* This file contains compile-time configuration parameters including
 * debugging options, default configuration values, and format strings.
 */

/* print bad calling locations of account functions */
#define  DEBUG_ACCOUNT

#define  LIST_DEBUG

#undef	 USE_CHECK_ALLOC
/*
#define DEBUG_D2GAME
*/

#define LADDER_REFRESH_TIME		    60	/* in minutes */

#define D2GAME_QUITTIME			    15

#define D2SERVER_PACKET_CHECK_INTERVAL	    60
#define D2CHECK_INTERVAL		    120
#define D2SERVER_CONNECT_TIMEOUT	    15


/* make bnchat, etc print debug messages */
#undef CLIENTDEBUG

#ifdef USE_CHECK_ALLOC
# include "check_alloc.h"
#endif

/* I have a hacked up mem_test.c that puts magic numbers in newly
 * allocated memory and freed memory. Instead of making the library
 * remember the size of each allocation, I have a special free(),
 * called pfree(), that takes a second parameter which is the size
 * of the area to free.
 */

# ifdef __GNUC__
/* the __attribute__ will give proper format warnings with -Wall */
#define PRINTF_ATTR(fmtarg,varg) __attribute__ ((format (printf, 3, 4)));
#else
#define PRINTF_ATTR(fmtarg,varg)
#endif

/* this will use GCC evensions to verify that all module arguments to
   eventlog() are correct. Compile and use this script:
   strings bnetd |
   egrep '@\([^@]*@@[a-z_]*\)@' |
   sed -e 's/@(\([^:]*\):\([a-z_]*\)@@\([a-z_]*\))@/\1 \2 \3/g' |
   awk '{ if ( $2 != $3 ) printf("%s: %s->%s\n",$1,$2,$3); }'
*/
#undef DEBUGMODSTRINGS

/* this will test get/unget memory management in account.c */
/*#undef TESTUNGET*/
#undef TESTUNGET

/* length of listen socket queue */
#define LISTEN_QUEUE 100

/* the format for account numbers */
#define UID_FORMAT "#%08u"
#define UID_MAXLEN 8

/* the format for game ids */
#define GAMEID_FORMAT "#%06u"
#define GAMEID_MAXLEN 8

/* the format of timestamps in the logfile */
#define EVENT_TIME_FORMAT "%b %d %H:%M:%S"
#define EVENT_TIME_MAXLEN 32

/* the format of the stat times in bnstat */
#define STAT_TIME_FORMAT "%Y %b %d %H:%M:%S"
#define STAT_TIME_MAXLEN 32

/* the format of the file modification time in bnftp */
#define FILE_TIME_FORMAT "%Y %b %d %H:%M:%S"
#define FILE_TIME_MAXLEN 32

/* the format of the dates in the game report and for /gameinfo */
#define GAME_TIME_FORMAT "%a %b %d %H:%M:%S %Z"
#define GAME_TIME_MAXLEN 32

#ifndef BNETD_DEFAULT_CONF_FILE
# define BNETD_DEFAULT_CONF_FILE "conf/bnetd.conf"
#endif
#define BNETD_FILE_DIR          "files"
#define BNETD_USER_DIR          "users"
#define BNETD_PLAYERINFO_DIR    "users/info"
#define BNETD_REALM_SERVER	"Zixia"
#define BNETD_REALM_PORT	9998
#define BNETD_REALM_ADDR	"166.111.167.40"
#define BNETD_REALM_CHARMAX	8
#define BNETD_REALM_DESC	"Diablo II Realm Server"
#define BNETD_REPORT_DIR        "reports"
#define BNETD_LOG_FILE          "logs/bnetd.log"
#define BNETD_TEMPLATE_FILE     "conf/account_template.txt"
#define BNETD_MOTD_FILE         "conf/bnmotd.txt"
#define BNETD_NEWS_DIR          "news"
#define BNETD_AD_FILE           "conf/ad.conf"
#define BNETD_CHANNEL_FILE      "conf/channel.conf"
#define BNETD_PID_FILE          "" /* this means "none" */
#define BNETD_ACCOUNT_TMP       ".bnetd_acct_temp"
#define BITS_IPBAN_FILE         "conf/bnban"
#define BNETD_HELP_FILE         "conf/bnhelpfile"
#define BNETD_FORTUNECMD        "/usr/games/fortune"
#define BNETD_TRANS_FILE        "conf/gametrans"
#define BNETD_CHAT_FILE		"conf/bnchat"
#define BNETD_VERSION_FILE	"conf/version"
#define BNETD_CHAT_HIMSELF	"himself"

/* files relative to FILE_DIR */
#define BNETD_TOS_FILE    "tos.txt"
#define BNETD_ICON_FILE   "icons.bni"
#define BNETD_VERSION_MPQ "IX86ver1.mpq"
#define BNETD_FILE_NAME_LEN	  32

/* other default configuration values */
#define BNETD_LOG_LEVELS          "warn,error"
#define BNETD_SERV_ADDRS          ":" /* this means "all" */
#define BNETD_SERV_PORT           6112 /* use this port if not specified */
#define BNETD_TRACK_ADDRS         "track.bnetd.org"
#define BNETD_TRACK_PORT          6114 /* use this port if not specified */
#define BNETD_DEF_TEST_PORT       6112 /* default guess for UDP test port */
#define BNETD_MIN_TEST_PORT       6112
#define BNETD_MAX_TEST_PORT       6500
#define BNETD_USERSYNC            300
#define BNETD_USERFLUSH           1000
#define BNETD_LATENCY             10
#define BNETD_TRACK_TIME          0
#define BNETD_POLL_INTERVAL       20000 /* 20 ms */
#define BNETD_SHUTDELAY           300
#define BNETD_SHUTDECR            60
#define BNETD_DEFAULT_OWNER       "Bob"
#define BNETD_DEFAULT_KEY         "3310541526205"
#define BNETD_DEFAULT_HOST        "localhost"
#define BNETD_D2SERV_PORT	  4000
#define BNETD_MAX_D2GAME          50
#define LADDER_INIT_RATING	  1000
#define BNETD_MPQCALC_KEY	  "A=1712948426 B=3600030607 C=3390417959 4 A=A-S B=B^C C=C-A A=A-B"

#define BNETD_NULL		  "(null)"


/* BITS (uplink) defaults */
#define BITS_DO_UPLINK        0
#define BITS_ALLOW_UPLINK     0

/* adjustable constants */
#define BNETD_LADDER_DEFAULT_TIME "19764578 0" /* 0:00 1 Jan 1970 GMT */

#endif
