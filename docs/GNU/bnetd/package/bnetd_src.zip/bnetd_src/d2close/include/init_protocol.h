/*
 * Copyright (C) 1998,1999  Ross Combs (rocombs@cs.nmsu.edu)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#ifndef INCLUDED_INIT_PROTOCOL_TYPES
#define INCLUDED_INIT_PROTOCOL_TYPES

#ifdef JUST_NEED_TYPES
#include "bn_type.h"
#else
#define JUST_NEED_TYPES
#include "bn_type.h"
#undef JUST_NEED_TYPES
#endif

/*
 * There is a single byte sent upon initial connections that
 * reports the connection type.
 */

/******************************************************/
typedef struct
{
    bn_byte class;
} t_connect_header;
/******************************************************/

#endif

#ifndef JUST_NEED_TYPES
#ifndef INCLUDED_INIT_PROTOCOL_PROTOS
#define INCLUDED_INIT_PROTOCOL_PROTOS

#define CONNECT_CLASS_DEFER  0x01 /* normal or auth connection */
#define CONNECT_CLASS_FILE   0x02
#define CONNECT_CLASS_BOT    0x03
#define CONNECT_CLASS_BITS   0xbd

#endif
#endif
