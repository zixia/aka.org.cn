/*
 * Copyright (C) 1998  Mark Baysinger (mbaysing@ucsd.edu)
 * Copyright (C) 1998,1999,2000  Ross Combs (rocombs@cs.nmsu.edu)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#ifndef INCLUDED_EVENTLOG_TYPES
#define INCLUDED_EVENTLOG_TYPES

typedef enum
{
    eventlog_level_none = 0,
    eventlog_level_trace= 1,
    eventlog_level_debug= 2,
    eventlog_level_info = 4,
    eventlog_level_warn = 8,
    eventlog_level_error=16
} t_eventlog_level;

#endif


#ifndef JUST_NEED_TYPES
#ifndef INCLUDED_EVENTLOG_PROTOS
#define INCLUDED_EVENTLOG_PROTOS

#include <stdio.h>

extern void eventlog_set(FILE * fp);
extern int eventlog_open(char const * filename);
extern void eventlog_clear_level(void);
extern int eventlog_add_level(char const * levelname);
extern int eventlog_del_level(char const * levelname);
#ifdef DEBUGMODSTRINGS
extern void eventlog_real(t_eventlog_level level, char const * module, char const * fmt, ...) PRINTF_ATTR(3,4);
#define eventlog(l,m,f,args...) eventlog_real(l,"@(" __FILE__ ":" m "@@" __func__ ")@",f,##args)
#else
extern void eventlog(t_eventlog_level level, char const * module, char const * fmt, ...) PRINTF_ATTR(3,4);
#endif

#endif
#endif
