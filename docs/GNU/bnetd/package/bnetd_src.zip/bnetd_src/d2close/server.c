/*
 * Copyright (C) 1998,1999  Mark Baysinger (mbaysing@ucsd.edu)
 * Copyright (C) 1998,1999,2000  Ross Combs (rocombs@cs.nmsu.edu)
 * Copyright (C) 2000  Marco Ziech (mmz@gmx.net)
 * Copyright (C) 2000  Onlyer (onlyer@263.net)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#define SERVER_INTERNAL_ACCESS
#include "config.h"
#include "setup.h"

#include <stdio.h>
#include <errno.h>

#define USE_STDDEF_HEADERS
#define USE_STDC_HEADERS
#define USE_MEMORY_HEADERS
#define USE_STRING_HEADERS
#define USE_TIME_HEADERS
#define USE_SOCKET_HEADERS
#define USE_SIGNAL_HEADERS
#define USE_FCNTL_HEADERS
#define USE_UNISTD_HEADERS
#define USE_SYS_TYPES_HEADERS
#define USE_SYS_SELECT_HEADERS
#define USE_SYS_PARAM_HEADERS

#include "compat.h"

#include "compat/memset.h"
#include "compat/difftime.h"
#include "compat/strerror.h"
#include "compat/psock.h"

#include "packet.h"
#include "init_protocol.h"
#include "udp_protocol.h"
#include "connection.h"
#include "hexdump.h"
#include "eventlog.h"
#include "message.h"
#include "queue.h"
#include "bnetd.h"
#include "handle_udp.h"

#include "network.h"
#include "prefs.h"
#include "account.h"
#include "tracker.h"
#include "list.h"
#include "adbanner.h"
#include "timer.h"
#include "addr.h"
#include "tag.h"
#include "bn_type.h"
#include "ipban.h"
#include "helpfile.h"
#include "gametrans.h"
#include "server.h"
#include "chatcmd.h"

#include "versioncheck.h"
#include "virtconn.h"
#include "game.h"
#include "d2game.h"
#include "d2server.h"
#include "d2ladder.h"

#if defined(HAVE_SIGACTION) && defined(HAVE_SIGPROCMASK) && defined(HAVE_SIGADDSET)
static void quit_sig_handle(int unused);
static void restart_sig_handle(int unused);
static void save_sig_handle(int unused);
#endif



static int init_connection(t_connection * c);

static time_t starttime;
static volatile time_t sigexittime=0;
static volatile time_t d2ladder_nexttime;
static volatile int do_restart=0;
static volatile int do_save=0;
static volatile int got_epipe=0;


extern void d2ladder_refresh_time_wrapper(unsigned int nexttime)
{
    if (nexttime) {
	d2ladder_nexttime=time(NULL)+nexttime*60;
    }
    else d2ladder_nexttime=0;
    eventlog(eventlog_level_info,"d2ladder_refresh_time_wrapper","next refresh time is %d",(int) d2ladder_nexttime);
    return;
}

extern void server_quit_wrapper(unsigned int delay) 
{
    if (!delay) {
    if (sigexittime)
	sigexittime -= prefs_get_shutdown_decr();
    else 
	sigexittime = time(NULL)+(time_t)prefs_get_shutdown_delay();
    }
    else sigexittime = time(NULL)+delay;
}

#if defined(HAVE_SIGACTION) && defined(HAVE_SIGPROCMASK) && defined(HAVE_SIGADDSET)
static void quit_sig_handle(int unused)
{
    if (sigexittime)
	sigexittime -= prefs_get_shutdown_decr();
    else
	sigexittime = time(NULL)+(time_t)prefs_get_shutdown_delay(); /* in five minutes */
}


static void restart_sig_handle(int unused)
{
    do_restart = 1;
}


static void save_sig_handle(int unused)
{
    do_save = 1;
}


static void pipe_sig_handle(int unused)
{
    got_epipe = 1;
}
#endif


extern int udptest_send(t_connection const * c)
{
    t_packet *         upacket;
    struct sockaddr_in caddr;
    unsigned int       tries,successes;
    
    memset(&caddr,0,sizeof(caddr));
    caddr.sin_family = AF_INET;
    caddr.sin_port = htons(conn_get_game_port(c));
    caddr.sin_addr.s_addr = htonl(conn_get_game_addr(c));
    
    for (tries=successes=0; successes!=2 && tries<5; tries++)
    {
	if (!(upacket = packet_create(packet_class_udp)))
	{
            eventlog(eventlog_level_error,"udptest_send","[%d] could not allocate memory for packet",conn_get_socket(c));
	    continue;
	}
	packet_set_size(upacket,sizeof(t_server_udptest));
	packet_set_type(upacket,SERVER_UDPTEST);
	bn_int_tag_set(&upacket->u.server_udptest.bnettag,BNETTAG);
	
	if (hexstrm)
	{
	    fprintf(hexstrm,"%d: send class=%s[0x%04hx] type=%s[0x%04hx] ",
		    conn_get_game_socket(c),
		    packet_get_class_str(upacket),packet_get_class(upacket),
		    packet_get_type_str(upacket,packet_dir_from_server),packet_get_type(upacket));
	    fprintf(hexstrm,"from=%s ",
		    addr_num_to_addr_str(conn_get_game_addr(c),conn_get_game_port(c)));
	    fprintf(hexstrm,"to=%s ",
		    addr_num_to_addr_str(ntohl(caddr.sin_addr.s_addr),ntohs(caddr.sin_port)));
	    fprintf(hexstrm,"length=%u\n",
		    packet_get_size(upacket));
	    hexdump(hexstrm,packet_get_raw_data(upacket,0),packet_get_size(upacket));
	}
	
        if (psock_sendto(conn_get_game_socket(c),
			 packet_get_raw_data_const(upacket,0),packet_get_size(upacket),
			 0,(struct sockaddr *)&caddr,sizeof(caddr))!=packet_get_size(upacket))
            eventlog(eventlog_level_error,"udptest_send","[%d] failed to send UDPTEST to %s (attempt %u) (psock_sendto: %s)",conn_get_socket(c),addr_num_to_addr_str(ntohl(caddr.sin_addr.s_addr),conn_get_game_port(c)),tries+1,strerror(psock_errno()));
	else
	    successes++;
	
	packet_del_ref(upacket);
    }
    
    if (successes!=2)
	return -1;
    
    return 0;
}


static int init_connection(t_connection * c)
{
    int              addlen;
    t_connect_header con_hdr;
    
    /* determine connection class by first character sent by client */
    addlen = psock_recv(conn_get_socket(c),&con_hdr,sizeof(con_hdr),0);
    
    if (addlen<0 && (
#ifdef PSOCK_EINTR
	             psock_errno()==PSOCK_EINTR ||
#endif
#ifdef PSOCK_EAGAIN
	             psock_errno()==PSOCK_EAGAIN ||
#endif
#ifdef PSOCK_EWOULDBLOCK
		     psock_errno()==PSOCK_EWOULDBLOCK ||
#endif
		     1))
	return 0;
    
    /* error occured or connection lost */
    if (addlen<1)
    {
	eventlog(eventlog_level_error,"init_connection","[%d] could not get connection class (closing connection) (psock_recv: %s)",conn_get_socket(c),strerror(psock_errno()));
	return -1;
    }
    
    switch (bn_byte_get(con_hdr.class))
    {
    case CONNECT_CLASS_DEFER:
	eventlog(eventlog_level_info,"init_connection","[%d] client initiated normal or auth connection",conn_get_socket(c));
	conn_set_state(c,conn_state_connected);
	conn_set_class(c,conn_class_defer);
        conn_set_realm(c,0);
    
/*
	if (prefs_get_udptest_port()!=0)
	    conn_set_game_port(c,prefs_get_udptest_port());
	udptest_send(c);

*/
	
	break;
	
    case CONNECT_CLASS_FILE:
	eventlog(eventlog_level_info,"init_connection","[%d] client initiated file download connection",conn_get_socket(c));
	conn_set_state(c,conn_state_connected);
	conn_set_class(c,conn_class_file);
	conn_set_realm(c,0);
	
	break;
	
    case CONNECT_CLASS_BITS:
	eventlog(eventlog_level_info,"init_connection","[%d] client initiated BNETD uplink connection",conn_get_socket(c));
	if (!prefs_get_allow_uplink())
	{
	    eventlog(eventlog_level_info,"init_connection","[%d] allow_uplink is disabled",conn_get_socket(c));
	    return -1;
	}
	conn_set_state(c,conn_state_connected);
	conn_set_class(c,conn_class_bits);
        conn_set_realm(c,0);

	break;
	
    case CONNECT_CLASS_BOT:
	eventlog(eventlog_level_info,"init_connection","[%d] client initiated chat bot connection",conn_get_socket(c));
	conn_set_state(c,conn_state_connected);
	conn_set_class(c,conn_class_bot);
        conn_set_realm(c,0);
	
	break;
	
    default:
	eventlog(eventlog_level_error,"init_connection","[%d] client initiated unknown connection class 0x%02x (length %d) (closing connection)",conn_get_socket(c),(unsigned int)bn_byte_get(con_hdr.class),addlen);
	return -1;
    }
    
    return 0;
}


extern unsigned int server_get_uptime(void)
{
    return (unsigned int)difftime(time(NULL),starttime);
}



extern int server_process(void)
{
    char                   tempa[32];
    struct timeval         tv;
    t_addrlist *           laddrs;
    t_addr *               curr_laddr;
    t_addr_data            laddr_data;
    t_laddr_info *         laddr_info;
    t_psock_fd_set         rfds, wfds;
    int                    highest_fd;
    time_t                 curr_exittime, prev_exittime, prev_savetime, track_time, now;
    unsigned int           syncdelta;
    t_connection *         c;
    t_elem const *	   elem;
    int                    csocket;
    int                    ssocket;
    int                    usocket;
#if defined(HAVE_SIGACTION) && defined(HAVE_SIGPROCMASK) && defined(HAVE_SIGADDSET)
    sigset_t               block_set;
    sigset_t               save_set;
#endif
    int                    do_track;
    unsigned int           count;

    unsigned short	   d2game_lport;
    int			   d2game_lsock;
    int			   d2game_csocket;
    int			   d2game_ssocket;
    struct sockaddr_in	   d2game_laddr;
    
    t_addr		   * curr_taddr;
    int			   tsocket;

    t_virtconn *	   vc;

    
    
    if (psock_init()<0)
    {
	eventlog(eventlog_level_error,"server_process","could not initialize socket functions");
	return -1;
    }

/*	d2game server init starts	*/ 
    if (prefs_allow_d2game()) 
    {
	d2game_lport	 = prefs_get_d2game_lport();

	
	if ((d2game_lsock = psock_socket(PSOCK_PF_INET,PSOCK_SOCK_STREAM,0))<0)
	{
	    eventlog(eventlog_level_error,"d2game_process","could not create listening socket(psock_socket:%s)",strerror(psock_errno()));
	    return -1;
	}
	
	{
	    int val=1;
	    if (psock_setsockopt(d2game_lsock,PSOCK_SOL_SOCKET,PSOCK_SO_REUSEADDR,(char *)&val,sizeof(int))<0)
		eventlog(eventlog_level_error,"d2game_process","[%d] could not set socket option SO_REUSEADDR(psock_setsockopt:%s)",d2game_lsock,strerror(psock_errno()));
	}
	
	memset(&d2game_laddr,0,sizeof(d2game_laddr));
	d2game_laddr.sin_family = AF_INET;
	d2game_laddr.sin_port = htons(d2game_lport);
	d2game_laddr.sin_addr.s_addr = htonl(INADDR_ANY);
	if (psock_bind(d2game_lsock,(struct sockaddr *)&d2game_laddr,sizeof(d2game_laddr))<0)
	{
	    eventlog(eventlog_level_error,"d2game_process","could bind socket to address 0.0.0.0:%hu TCP (psock_bind: %s)",d2game_lport,strerror(psock_errno()));
	    psock_close(d2game_lsock);
	    return -1;
	}
    
    /* tell socket to listen for connections */
	if (psock_listen(d2game_lsock,LISTEN_QUEUE)<0)
	{
	    eventlog(eventlog_level_error,"d2game_process","could not listen (psock_listen: %s)",strerror(psock_errno()));
	    psock_close(d2game_lsock);
	    return -1;
	}

	if (psock_ctl(d2game_lsock,PSOCK_NONBLOCK)<0)
	    eventlog(eventlog_level_error,"d2game_process","could not set TCP listen socket to non-blocking mode (psock_ctl: %s)",strerror(psock_errno()));

	eventlog(eventlog_level_info,"d2game_process","listening on TCP port %hu",d2game_lport);

    }

/*	d2game server init ends  */
	

    d2ladder_create();

    if (prefs_get_ladder_refresh_time()) {
    d2ladder_nexttime=time(NULL)+prefs_get_ladder_refresh_time()*60;
    }
    else d2ladder_nexttime=0;
    
    /* setup the tracking mechanism */
    if (prefs_get_track())
    {
	tracker_set_servers(prefs_get_trackserv_addrs());
	track_time = time(NULL)-prefs_get_track();
	do_track = 1;
    }
    else
	do_track = 0;
    
    syncdelta = prefs_get_user_sync_timer();
    
    if (!(laddrs = addrlist_create(prefs_get_bnetdserv_addrs(),INADDR_ANY,BNETD_SERV_PORT)))
    {
	eventlog(eventlog_level_error,"server_process","could not create server address list from \"%s\"",prefs_get_bnetdserv_addrs());
	goto error_track;
    }
    
    LIST_TRAVERSE_DATA_CONST(laddrs,elem,curr_laddr)
    {
	if (!(laddr_info = malloc(sizeof(t_laddr_info))))
	{
	    eventlog(eventlog_level_error,"server_process","could not create a listening socket (psock_socket: %s)",strerror(psock_errno()));
	    goto error_listen;
	}
	if ((ssocket = psock_socket(PSOCK_PF_INET,PSOCK_SOCK_STREAM,0))<0)
	{
	    eventlog(eventlog_level_error,"server_process","could not create a listening socket (psock_socket: %s)",strerror(psock_errno()));
	    free(laddr_info);
	    goto error_listen;
	}
	if ((usocket = psock_socket(PSOCK_PF_INET,PSOCK_SOCK_DGRAM,0))<0)
	{
	    eventlog(eventlog_level_error,"server_process","could not create UDP socket (psock_socket: %s)",strerror(psock_errno()));
	    psock_close(ssocket);
	    free(laddr_info);
	    goto error_listen;
	}
	
	laddr_info->ssocket = ssocket;
	laddr_info->usocket = usocket;
	laddr_data.p = laddr_info;
	if (addr_set_data(curr_laddr,laddr_data)<0)
	{
	    eventlog(eventlog_level_error,"server_process","could not set address data");
	    psock_close(usocket);
	    psock_close(ssocket);
	    free(laddr_info);
	    goto error_listen;
	}
	
	{
	    int val;
	    val = 1;
	    if (psock_setsockopt(ssocket,PSOCK_SOL_SOCKET,PSOCK_SO_REUSEADDR,(char *)&val,sizeof(int))<0)
		eventlog(eventlog_level_error,"server_process","could not set socket option SO_REUSEADDR (psock_setsockopt: %s)",strerror(psock_errno()));
	    /* not a fatal error... */
	}
	
	{
	    struct sockaddr_in saddr;
	    
	    memset(&saddr,0,sizeof(saddr));
	    saddr.sin_family = AF_INET;
	    saddr.sin_port = htons(addr_get_port(curr_laddr));
	    saddr.sin_addr.s_addr = htonl(addr_get_ip(curr_laddr));
	    if (psock_bind(ssocket,(struct sockaddr *)&saddr,sizeof(saddr))<0)
	    {
		if (addr_get_addr_str(curr_laddr,tempa,sizeof(tempa))<0)
		    strcpy(tempa,"x.x.x.x:x");
		eventlog(eventlog_level_error,"server_process","could bind socket to address %s TCP (psock_bind: %s)",tempa,strerror(psock_errno()));
		goto error_listen;
	    }
	    
	    memset(&saddr,0,sizeof(saddr));
	    saddr.sin_family = AF_INET;
	    saddr.sin_port = htons(addr_get_port(curr_laddr));
	    saddr.sin_addr.s_addr = htonl(addr_get_ip(curr_laddr));
	    if (psock_bind(usocket,(struct sockaddr *)&saddr,sizeof(saddr))<0)
	    {
		if (addr_get_addr_str(curr_laddr,tempa,sizeof(tempa))<0)
		    strcpy(tempa,"x.x.x.x:x");
		eventlog(eventlog_level_error,"server_process","could bind socket to address %s UDP (psock_bind: %s)",tempa,strerror(psock_errno()));
		goto error_listen;
	    }
	}
	
	/* tell socket to listen for connections */
	if (psock_listen(ssocket,LISTEN_QUEUE)<0)
	{
	    eventlog(eventlog_level_error,"server_process","could not listen (psock_listen: %s)",strerror(psock_errno()));
	    goto error_listen;
	}
	
	if (addr_get_addr_str(curr_laddr,tempa,sizeof(tempa))<0)
	    strcpy(tempa,"x.x.x.x:x");
	eventlog(eventlog_level_info,"server_process","listening on %s TCP",tempa);
	
	if (psock_ctl(ssocket,PSOCK_NONBLOCK)<0)
	    eventlog(eventlog_level_error,"server_process","could not set TCP listen socket to non-blocking mode (psock_ctl: %s)",strerror(psock_errno()));
	if (psock_ctl(usocket,PSOCK_NONBLOCK)<0)
	    eventlog(eventlog_level_error,"server_process","could not set UDP socket to non-blocking mode (psock_ctl: %s)",strerror(psock_errno()));
    }
    
    /* setup signal handlers */
    prev_exittime = sigexittime;
    
#if defined(HAVE_SIGACTION) && defined(HAVE_SIGPROCMASK) && defined(HAVE_SIGADDSET)
    if (sigemptyset(&save_set)<0)
    {
	eventlog(eventlog_level_error,"server_process","could not initialize signal set (sigemptyset: %s)",strerror(errno));
	goto error_listen;
    }
    if (sigemptyset(&block_set)<0)
    {
	eventlog(eventlog_level_error,"server_process","could not initialize signal set (sigemptyset: %s)",strerror(errno));
	goto error_listen;
    }
    if (sigaddset(&block_set,SIGINT)<0)
    {
	eventlog(eventlog_level_error,"server_process","could not add signal to set (sigemptyset: %s)",strerror(errno));
	goto error_listen;
    }
    if (sigaddset(&block_set,SIGHUP)<0)
    {
	eventlog(eventlog_level_error,"server_process","could not add signal to set (sigemptyset: %s)",strerror(errno));
	goto error_listen;
    }
    if (sigaddset(&block_set,SIGTERM)<0)
    {
	eventlog(eventlog_level_error,"server_process","could not add signal to set (sigemptyset: %s)",strerror(errno));
	goto error_listen;
    }
    if (sigaddset(&block_set,SIGUSR1)<0)
    {
	eventlog(eventlog_level_error,"server_process","could not add signal to set (sigemptyset: %s)",strerror(errno));
	goto error_listen;
    }
    
    {
	struct sigaction quit_action;
	struct sigaction restart_action;
	struct sigaction save_action;
	struct sigaction pipe_action;

	quit_action.sa_handler = quit_sig_handle;
	if (sigemptyset(&quit_action.sa_mask)<0)
	    eventlog(eventlog_level_error,"server_process","could not initialize signal set (sigemptyset: %s)",strerror(errno));
	quit_action.sa_flags = SA_RESTART;
	
	restart_action.sa_handler = restart_sig_handle;
	if (sigemptyset(&restart_action.sa_mask)<0)
	    eventlog(eventlog_level_error,"server_process","could not initialize signal set (sigemptyset: %s)",strerror(errno));
	restart_action.sa_flags = SA_RESTART;
	
	save_action.sa_handler = save_sig_handle;
	if (sigemptyset(&save_action.sa_mask)<0)
	    eventlog(eventlog_level_error,"server_process","could not initialize signal set (sigemptyset: %s)",strerror(errno));
	save_action.sa_flags = SA_RESTART;

	pipe_action.sa_handler = pipe_sig_handle;
	if (sigemptyset(&pipe_action.sa_mask)<0)
	    eventlog(eventlog_level_error,"server_process","could not initialize signal set (sigemptyset: %s)",strerror(errno));
	pipe_action.sa_flags = SA_RESTART;
	
	if (sigaction(SIGINT,&quit_action,NULL)<0) /* control-c */
	    eventlog(eventlog_level_error,"server_process","could not set SIGINT signal handler (sigaction: %s)",strerror(errno));
	if (sigaction(SIGHUP,&restart_action,NULL)<0)
	    eventlog(eventlog_level_error,"server_process","could not set SIGHUP signal handler (sigaction: %s)",strerror(errno));
	if (sigaction(SIGTERM,&quit_action,NULL)<0)
	    eventlog(eventlog_level_error,"server_process","could not set SIGTERM signal handler (sigaction: %s)",strerror(errno));
	if (sigaction(SIGUSR1,&save_action,NULL)<0)
	    eventlog(eventlog_level_error,"server_process","could not set SIGUSR1 signal handler (sigaction: %s)",strerror(errno));
	if (sigaction(SIGPIPE,&pipe_action,NULL)<0)
	    eventlog(eventlog_level_error,"server_process","could not set SIGPIPE signal handler (sigaction: %s)",strerror(errno));
    }
#endif
    
    starttime=prev_savetime = time(NULL);
    count = 0;
    
/* for here to go ready for connections */

while (1)  {
    
#if defined(HAVE_SIGACTION) && defined(HAVE_SIGPROCMASK) && defined(HAVE_SIGADDSET)
	if (sigprocmask(SIG_SETMASK,&save_set,NULL)<0)
	    eventlog(eventlog_level_error,"server_process","could not unblock signals");
	/* receive signals here */
	if (sigprocmask(SIG_SETMASK,&block_set,NULL)<0)
	    eventlog(eventlog_level_error,"server_process","could not block signals");
#endif
	
	if (got_epipe)	{
	    got_epipe = 0;
	    eventlog(eventlog_level_info,"server_process","handled SIGPIPE");
	}
	
	now = time(NULL);

	if (d2ladder_nexttime && d2ladder_nexttime<now) {
		eventlog(eventlog_level_info,"server_process","going to refresh ladder system");
		d2ladder_unload_data();
		d2ladder_create();
		now=time(NULL);
		eventlog(eventlog_level_info,"server_process","done refresh ladder system");
		if (prefs_get_ladder_refresh_time()) {
		    d2ladder_nexttime=now+prefs_get_ladder_refresh_time()*60;
		}
		else d2ladder_nexttime=0;
	}
	
	curr_exittime = sigexittime;
	if (curr_exittime && (curr_exittime<=now || connlist_get_length()<1)) {
	    eventlog(eventlog_level_info,"server_process","the server is shutting down NOW! (%d connections left)",connlist_get_length());
	    break;
	}
	if (prev_exittime!=curr_exittime) {
	    char text[MAX_MESSAGE_LEN];
	    
	    sprintf(text,"The server will shut down in %02d:%02d minutes (%d connections left).",((int)(curr_exittime-now))/60,((int)(curr_exittime-now))%60,connlist_get_length());
	    message_send_all(MT_ERROR,NULL,text);
	    eventlog(eventlog_level_info,"server_process","the server will shut down in %02d:%02d minutes (%d connections left)",((int)(curr_exittime-now))/60,((int)(curr_exittime-now))%60,connlist_get_length());
	}
	prev_exittime = curr_exittime;
	
	if (syncdelta && prev_savetime+(time_t)syncdelta<=now) {
	    accountlist_save(prefs_get_user_sync_timer());
	    gamelist_check_voidgame();
	    prev_savetime = now;
	}
	
	if (do_save) {
	    eventlog(eventlog_level_info,"server_process","saving accounts due to signal");
	    accountlist_save(0);
	    do_save = 0;
	}
	
	if (do_restart)
	{
	    eventlog(eventlog_level_info,"server_process","reading configuration files");
	    if (preffile) {
        	if (prefs_load(preffile)<0)
		    eventlog(eventlog_level_error,"server_process","could not parse configuration file");
	    }
	    else
		if (prefs_load(BNETD_DEFAULT_CONF_FILE)<0)
		    eventlog(eventlog_level_error,"server_process","using default configuration");
	    
	    if (eventlog_open(prefs_get_logfile())<0)
		eventlog(eventlog_level_error,"server_process","could not use the file \"%s\" for the eventlog",prefs_get_logfile());
	    
	    /* FIXME: load new network settings */
	    /* FIXME: load new ad banners */
	    
	    accountlist_load_default(); /* FIXME: free old one */
	    
	    /* FIXME: reload channel list */
	    
	    if (ipbanlist_unload()<0)
		eventlog(eventlog_level_error,"server_process","could not unload old IP ban list");
	    if (ipbanlist_load(prefs_get_ipbanfile())<0)
		eventlog(eventlog_level_error,"server_process","could not load new IP ban list");

	    chatfile_unload();
	    if (chatfile_init(prefs_get_chatfile())<0)
		eventlog(eventlog_level_error,"server_process","could not load the chatfile");

	    versioncheck_unload();
	    if (versioncheck_load(prefs_get_versionfile())<0)
		eventlog(eventlog_level_error,"server_process","coult not load version file");
	    
	    helpfile_unload();
	    if (helpfile_init(prefs_get_helpfile())<0)
		eventlog(eventlog_level_error,"server_process","could not load the helpfile");
	    
	    if (adbannerlist_destroy()<0)
		eventlog(eventlog_level_error,"server_process","could not unload old adbanner list");
	    if (adbannerlist_create(prefs_get_adfile())<0)
		eventlog(eventlog_level_error,"server_process","could not new adbanner list");
	    
	    if (gametrans_unload()<0)
		eventlog(eventlog_level_error,"server_process","could not unload old gametrans list");
	    if (gametrans_load(prefs_get_transfile())<0)
		eventlog(eventlog_level_error,"server_process","could not load new gametrans list");
	    
	    syncdelta = prefs_get_user_sync_timer();
	    
	    eventlog(eventlog_level_info,"server_process","done reconfiguring");
	    
	    do_restart = 0;
	}

	/* only check timers once a second */ 
	if (++count>=(1000000/BNETD_POLL_INTERVAL)) {
	    timerlist_check_timers(now);
	    count = 0;
	}
	/* above is to check signal for restarting saving and etc  */	

	/* loop over all connections to create the sets for select() */
	PSOCK_FD_ZERO(&rfds);
	PSOCK_FD_ZERO(&wfds);
	/*
	highest_fd = -1;
	*/

/*	d2game server create fd sets starts	*/
    if (prefs_allow_d2game())
    {
	highest_fd = d2game_lsock;
	PSOCK_FD_SET(d2game_lsock,&rfds);


	LIST_TRAVERSE_DATA_CONST(d2servlist(),elem,curr_taddr)
	{
	    if (!addr_get_info(curr_taddr)) {
		 if (d2server_create_info(curr_taddr)<0) {
		    eventlog(eventlog_level_error,"d2game_process","could not create info");
		 }
		 continue;
	    }
	    {
		time_t		    lasttest;
		t_d2server_status   status;

		tsocket=d2server_get_socket(curr_taddr);
		lasttest=d2server_get_lasttest(curr_taddr);
		status=d2server_get_status(curr_taddr);
		addr_get_addr_str(curr_taddr,tempa,sizeof(tempa));

		if (status==d2server_status_none) {
		    if ((now-lasttest)>prefs_get_d2server_check_interval()) {
			eventlog(eventlog_level_debug,"d2game_process","trying to connect to d2game server %s",tempa);
			d2server_connect(curr_taddr);
			d2server_set_lasttest(curr_taddr,now);

		      if (status==d2server_status_connected)	{
			eventlog(eventlog_level_debug,"d2game_process","successfully connected to d2game server %s",tempa);
			d2server_set_token(curr_taddr,1);
			d2server_set_gamenum(curr_taddr,0);
		      }
		    }
		}
		else if (status==d2server_status_connected) {
			PSOCK_FD_SET(tsocket,&rfds);
			if (tsocket>highest_fd) highest_fd=tsocket;
			if (now-lasttest>D2SERVER_PACKET_CHECK_INTERVAL) {
			    PSOCK_FD_SET(tsocket,&wfds);
			    if (tsocket>highest_fd) highest_fd=tsocket;
			}
		}
		else if (status==d2server_status_connecting) {
		    if (now-lasttest>D2SERVER_CONNECT_TIMEOUT) {
			eventlog(eventlog_level_debug,"d2game_process","connecting to d2game server %s timed-out",tempa);
			d2server_set_status(curr_taddr,d2server_status_none);
			psock_close(tsocket);
			d2server_set_lasttest(curr_taddr,now);
			continue;
		    }
		    PSOCK_FD_SET(tsocket,&wfds);
		    if (tsocket>highest_fd) highest_fd=tsocket;
		}

	    }

	}
	
	LIST_TRAVERSE_DATA_CONST(virtconnlist(),elem,vc)
	{
            d2game_csocket = virtconn_get_client_socket(vc);
	    if (!virtconn_get_quittime(vc)) {
	    if (queue_get_length((t_queue const * const *)virtconn_get_clientout_queue(vc))>0)
	        PSOCK_FD_SET(d2game_csocket,&wfds); 

	    PSOCK_FD_SET(d2game_csocket,&rfds);
	    if (d2game_csocket>highest_fd)
                highest_fd = d2game_csocket;
	    }
	    
	    switch (virtconn_get_state(vc))
	    {
	    case virtconn_state_connecting:
		/*
		eventlog(eventlog_level_debug,"d2game_process","waiting for %d to finish connecting",d2game_ssocket);
		*/

		d2game_ssocket = virtconn_get_server_socket(vc);
		PSOCK_FD_SET(d2game_ssocket,&wfds); 
		
		if (d2game_ssocket>highest_fd)
		    highest_fd = d2game_ssocket;
		break;
	    case virtconn_state_connected:
	    case virtconn_state_in_game:
	    case virtconn_state_quitting:
		d2game_ssocket = virtconn_get_server_socket(vc);
		if (queue_get_length((t_queue const * const *)virtconn_get_serverout_queue(vc))>0)
		    PSOCK_FD_SET(d2game_ssocket,&wfds); 
		PSOCK_FD_SET(d2game_ssocket,&rfds);
		
		if (d2game_ssocket>highest_fd)
		    highest_fd = d2game_ssocket;
		break;
	    case virtconn_state_login:
	    default: 
		break;
	    }
	}
    }
/*  d2game server create fd sets ends	*/

	
	LIST_TRAVERSE_DATA_CONST(laddrs,elem,curr_laddr)
	{
	    laddr_data = addr_get_data(curr_laddr);
	    laddr_info = laddr_data.p;
	    
	    ssocket = laddr_info->ssocket;
	    usocket = laddr_info->usocket;
            
	    PSOCK_FD_SET(ssocket,&rfds);
	    PSOCK_FD_SET(usocket,&rfds);
            
	    if (ssocket>highest_fd)
        	highest_fd = ssocket;
	    if (usocket>highest_fd)
        	highest_fd = usocket;
	}
	
	LIST_TRAVERSE_DATA_CONST(connlist(),elem,c)
	{
            csocket = conn_get_socket(c);
	    
	    if (queue_get_length((t_queue const * const *)conn_get_out_queue(c))>0)
		PSOCK_FD_SET(csocket,&wfds); /* pending output, also check for writeability */
	    PSOCK_FD_SET(csocket,&rfds);
            
	    if (csocket>highest_fd)
        	highest_fd = csocket;
	}
	/* update rdfs and wfds */
	
	/* always set the select() timeout */
	tv.tv_sec  = 0;
	tv.tv_usec = BNETD_POLL_INTERVAL;
	
	/* find which sockets need servicing */
	switch (psock_select(highest_fd+1,&rfds,&wfds,NULL,&tv)) {
	case -1: /* error */
	    if (
#ifdef PSOCK_EINTR
		errno!=PSOCK_EINTR &&
#endif
		1)
	        eventlog(eventlog_level_error,"server_process","select failed (select: %s)",strerror(errno));
	case 0: /* timeout and no sockets ready */
	    continue;
	}
	/* wait some useconds to got incoming and data */
	
/*  d2game server check fd sets starts */
    if (prefs_allow_d2game())
    {
	    LIST_TRAVERSE_DATA_CONST(d2servlist(),elem,curr_taddr)
	    {
	    if (!addr_get_info(curr_taddr)) continue;
	    if (d2server_get_status(curr_taddr)==d2server_status_none) continue;

	    tsocket=d2server_get_socket(curr_taddr); 
	    addr_get_addr_str(curr_taddr,tempa,sizeof(tempa));
	    if (PSOCK_FD_ISSET(tsocket,&rfds)) {
		t_packet * packet;
		unsigned int currsize=0;
		if ((packet=packet_create(packet_class_raw))) {
		    packet_set_size(packet,1);
		    switch (net_recv_packet(tsocket,packet,&currsize)) {
			case -1:
			    eventlog(eventlog_level_error,"d2game_process","remove d2game server %s from list",tempa);
			    d2server_set_status(curr_taddr,d2server_status_none);
			    psock_close(tsocket);
			    break;
			case 0:
			case 1:
			    break;
		    }
		    packet_del_ref(packet);
		}
	    }

	    if (PSOCK_FD_ISSET(tsocket,&wfds)) {
		if (d2server_get_status(curr_taddr)==d2server_status_connecting) {
		    int err;
		    int errlen;
		    
		    errlen = sizeof(err);
		    if (psock_getsockopt(tsocket,PSOCK_SOL_SOCKET,PSOCK_SO_ERROR,(char *)&err,&errlen)!=0)
		    {
			eventlog(eventlog_level_error,"d2game_process","unable to read socket error (psock_getsockopt[psock_connect]: %s)",strerror(psock_errno()));
			d2server_set_status(curr_taddr,d2server_status_none);
			psock_close(tsocket);
			continue;
		    }
		    if (err==0) {
			d2server_set_status(curr_taddr,d2server_status_connected);
			eventlog(eventlog_level_debug,"d2game_process","got d2game server %s connected",tempa);
			d2server_set_token(curr_taddr,1);
			d2server_set_gamenum(curr_taddr,0);
		    }
		    else
		    {
			eventlog(eventlog_level_error,"d2game_process","could not connect to d2game server %s",tempa);
			d2server_set_status(curr_taddr,d2server_status_none);
			psock_close(tsocket);
			continue;
		    }
		}
		else if (now-d2server_get_lasttest(curr_taddr)>D2SERVER_PACKET_CHECK_INTERVAL) {
		    t_packet * tpacket;
		    unsigned int currsize=0;
		    if ((tpacket=packet_create(packet_class_raw))) {
			packet_append_data(tpacket,"\x66",1);
			switch (net_send_packet(tsocket,tpacket,&currsize))
			{
			    case -1:
				eventlog(eventlog_level_error,"d2game_process","remove d2game server %s from list",tempa);
				d2server_set_status(curr_taddr,d2server_status_none);
				psock_close(tsocket);
				break;
			    case 0:
			    case 1:
				d2server_set_lasttest(curr_taddr,now);
				break;
			}
			packet_del_ref(tpacket);
		    }
		}
	    }
	}

    
	if (PSOCK_FD_ISSET(d2game_lsock,&rfds))
	{
            int                asock;
	    struct sockaddr_in caddr;
	    unsigned int       caddr_len;
            
	    /* accept the connection */
	    caddr_len = sizeof(caddr);
	    if ((asock = psock_accept(d2game_lsock,(struct sockaddr *)&caddr,&caddr_len))<0)
	    {
		if (psock_errno()==PSOCK_EWOULDBLOCK || psock_errno()==PSOCK_ECONNABORTED) /* BSD, POSIX error for aborted connections, SYSV often uses EAGAIN */
		    eventlog(eventlog_level_error,"d2game_process","client aborted connection (psock_accept: %s)",strerror(psock_errno()));
		else /* EAGAIN can mean out of resources _or_ connection aborted */
		    if (psock_errno()!=PSOCK_EINTR)
			eventlog(eventlog_level_error,"d2game_process","could not accept new connection (psock_accept: %s)",strerror(psock_errno()));
	    }
	    else
	    {
		int ssd;
		/*
		int val=1;
		if (psock_setsockopt(asock,PSOCK_SOL_SOCKET,PSOCK_SO_KEEPALIVE,(char *)&val,sizeof(val))<0)
		    eventlog(eventlog_level_error,"d2game_process","[%d] could not set socket option SO_KEEPALIVE (psock_setsockopt: %s)",asock,strerror(psock_errno()));

		if (psock_setsockopt(asock,IPPROTO_TCP,TCP_NODELAY,(char *)&val,sizeof(val))<0) 
		    eventlog(eventlog_level_error,"d2game_process","could not set nodelay %s for asock",strerror(psock_errno()));
		*/
		eventlog(eventlog_level_info,"d2game_process","[%d] accepted connection from %s:%hu",asock,inet_ntoa(caddr.sin_addr),ntohs(caddr.sin_port));
		if (psock_ctl(asock,PSOCK_NONBLOCK)<0)
		{
		    eventlog(eventlog_level_error,"d2game_process","[%d] could not set TCP socket to non-blocking mode (closing connection) (psock_ctl: %s)",asock,strerror(psock_errno()));
		    psock_close(asock);
		}
		else {
		    if ((ssd = psock_socket(PSOCK_PF_INET,PSOCK_SOCK_STREAM,0))<0)
		    {
			eventlog(eventlog_level_error,"d2game_process","[%d] could create TCP socket (closing connection) (psock_socket: %s)",asock,strerror(psock_errno()));
			psock_close(asock);
		    }
		    /*
		    if (psock_setsockopt(ssd,IPPROTO_TCP,TCP_NODELAY,(char *)&val,sizeof(val))<0) {
			eventlog(eventlog_level_error,"d2game_process","could not set nodelay %s for ssd",strerror(psock_errno()));
		    }
		    else 
		    */
			if (psock_ctl(ssd,PSOCK_NONBLOCK)<0)
			{
			    eventlog(eventlog_level_error,"d2game_process","[%d] could not set TCP socket to non-blocking mode (closing connection) (psock_ctl: %s)",asock,strerror(psock_errno()));
			    psock_close(ssd);
			    psock_close(asock);
			}
			else
			    if (!(vc = virtconn_create(asock,ssd,ntohl(caddr.sin_addr.s_addr),BNETD_MIN_TEST_PORT)))
			    {
				eventlog(eventlog_level_error,"d2game_process","[%d] unable to create new connection (closing connection)",asock);
				psock_close(ssd);
				psock_close(asock);
			    }
			    else
			    {
				memset(&caddr,0,sizeof(caddr));
				caddr.sin_family = AF_INET;
				caddr.sin_port = htons(virtconn_get_udpport(vc));
				caddr.sin_addr.s_addr = htonl(virtconn_get_udpaddr(vc));
				eventlog(eventlog_level_info,"d2game_process","[%d] addr now %s:%hu",asock,inet_ntoa(caddr.sin_addr),ntohs(caddr.sin_port));
			    }
		}
	    }

	    /* need init here if client are waiting for server response */
	    virtconn_init(vc);
	}
	
	/* search connections for sockets that need service */
	LIST_TRAVERSE_DATA_CONST(virtconnlist(),elem,vc)
	{

	    unsigned int currsize;
	    t_packet *   packet;
	    
	    if (virtconn_get_state(vc)==virtconn_state_destroy) {
		virtconn_destroy(vc);
		continue;
	    }

	    /* add for fine send */
	    if (virtconn_get_quittime(vc) && (time(NULL)-virtconn_get_quittime(vc))>D2GAME_QUITTIME) {
		eventlog(eventlog_level_debug,"d2game_process","destroyed virtconn due to quittime reached");
		virtconn_destroy(vc);
		continue;
	    }

            d2game_csocket = virtconn_get_client_socket(vc);
	    if (virtconn_get_state(vc)==virtconn_state_connected ||
		virtconn_get_state(vc)==virtconn_state_in_game	||
		virtconn_get_state(vc)==virtconn_state_quitting ||
		virtconn_get_state(vc)==virtconn_state_connecting)
		d2game_ssocket = virtconn_get_server_socket(vc);
	    else
		d2game_ssocket = -1;
	    
	    if (PSOCK_FD_ISSET(d2game_csocket,&rfds))
	    {
	    /*
		if (virtconn_get_state(vc)==virtconn_state_initial)
		{
		}
	    */
		{
		    currsize = virtconn_get_clientin_size(vc);
		    
		    if (!*virtconn_get_clientin_queue(vc))
		    {
			if (!(packet = packet_create(packet_class_d2game)))
		        {
			    eventlog(eventlog_level_error,"d2game_process","could not allocate raw packet for input");
			    continue;
			}
			packet_set_size(packet,MAX_PACKET_SIZE); 
			queue_push_packet(virtconn_get_clientin_queue(vc),packet);
			packet_del_ref(packet);
			if (!*virtconn_get_clientin_queue(vc))
			    continue; /* push failed */
			currsize = 0;
		    }
		    
		    packet = queue_peek_packet((t_queue const * const *)virtconn_get_clientin_queue(vc)); /* avoid warning */
		    switch (net_recv_packet(d2game_csocket,packet,&currsize))
		    {
		    case -1:
			if (virtconn_get_state(vc)!=virtconn_state_in_game &&
			    virtconn_get_state(vc)!=virtconn_state_quitting) {
			    virtconn_destroy(vc);
			    continue;
			}
			virtconn_autoquit(vc);
			if (!virtconn_get_quittime(vc)) {
			    eventlog(eventlog_level_debug,"d2game_process","client disconnected,set quit time");
			    virtconn_set_quittime(vc,time(NULL));
			}
			continue;
			
		    case 0: /* still working on it */
			virtconn_set_clientin_size(vc,currsize);
			if (currsize<1) break;
			else packet_set_size(packet,currsize);
			
		    case 1: /* done reading */
			
			packet = queue_pull_packet(virtconn_get_clientin_queue(vc));
			
			if (d2game_handle_client_packet(vc,packet)!=1) {
			queue_push_packet(virtconn_get_serverout_queue(vc),packet);
			}
			packet_del_ref(packet);
			virtconn_set_clientin_size(vc,0);
		    }
		}
	    }
	    
	    if (d2game_ssocket!=-1 && PSOCK_FD_ISSET(d2game_ssocket,&rfds))
	    {
		currsize = virtconn_get_serverin_size(vc);
		
		if (!*virtconn_get_serverin_queue(vc))
		{
		    if (!(packet = packet_create(packet_class_d2game)))
		    {
			eventlog(eventlog_level_error,"d2game_process","could not allocate d2game packet for input");
			continue;
		    }
		    packet_set_size(packet,MAX_PACKET_SIZE); /* read as much as possible */
		    queue_push_packet(virtconn_get_serverin_queue(vc),packet);
		    packet_del_ref(packet);
		    if (!*virtconn_get_serverin_queue(vc))
			continue; /* push failed */
		    currsize = 0;
		}
		
		packet = queue_peek_packet((t_queue const * const *)virtconn_get_serverin_queue(vc)); /* avoid warning */
		switch (net_recv_packet(d2game_ssocket,packet,&currsize))
		{
		case -1:
		    virtconn_destroy(vc);
		    continue;
		    
		case 0: /* still working on it */
		    virtconn_set_serverin_size(vc,currsize);
		    if (currsize<1) break;
		    else packet_set_size(packet,currsize);
		    
		case 1: /* done reading */
		    packet = queue_pull_packet(virtconn_get_serverin_queue(vc));
		    if (hexstrm)
		    {
			fprintf(hexstrm,"%d: srv class=%s[0x%04hx] type=%s[0x%04hx] length=%hu\n",
				d2game_ssocket,
				packet_get_class_str(packet),packet_get_class(packet),
				packet_get_type_str(packet,packet_dir_from_server),packet_get_type(packet),
				packet_get_size(packet));
			hexdump(hexstrm,packet_get_raw_data(packet,0),packet_get_size(packet));
		    }
		    
		    if (d2game_handle_server_packet(vc,packet)!=1 && !virtconn_get_quittime(vc)) {
		    queue_push_packet(virtconn_get_clientout_queue(vc),packet);
		    }
		    packet_del_ref(packet);
		    virtconn_set_serverin_size(vc,0);
		}
	    }
	    
	    if (PSOCK_FD_ISSET(d2game_csocket,&wfds))
	    {
		currsize = virtconn_get_clientout_size(vc);
		switch (net_send_packet(d2game_csocket,queue_peek_packet((t_queue const * const *)virtconn_get_clientout_queue(vc)),&currsize)) /* avoid warning */
		{
		case -1:
			if (virtconn_get_state(vc)!=virtconn_state_in_game &&
			    virtconn_get_state(vc)!=virtconn_state_quitting) {
			    virtconn_destroy(vc);
			    continue;
			}
			virtconn_autoquit(vc);
			if (!virtconn_get_quittime(vc)) {
			    eventlog(eventlog_level_debug,"d2game_process","client disconnected,set quit time");
			    virtconn_set_quittime(vc,time(NULL));
			}
			continue;
		    
		case 0: /* still working on it */
		    virtconn_set_clientout_size(vc,currsize);
		    break;
		    
		case 1: /* done sending */
		    packet = queue_pull_packet(virtconn_get_clientout_queue(vc));
		    packet_del_ref(packet);
		    virtconn_set_clientout_size(vc,0);
		}
	    }
	    
	    if (d2game_ssocket!=-1 && PSOCK_FD_ISSET(d2game_ssocket,&wfds))
	    {
		if (virtconn_get_state(vc)==virtconn_state_connecting)
		{
		    int err;
		    int errlen;
		    
		    errlen = sizeof(err);
		    if (psock_getsockopt(d2game_ssocket,PSOCK_SOL_SOCKET,PSOCK_SO_ERROR,(char *)&err,&errlen)<0)
		    {
			eventlog(eventlog_level_error,"d2game_process","[%d] unable to read socket error (psock_getsockopt[psock_connect]: %s)",virtconn_get_client_socket(vc),strerror(psock_errno()));
			virtconn_destroy(vc);
			continue;
		    }
		    if (err==0)
			virtconn_set_state(vc,virtconn_state_connected);
		    else
		    {
			eventlog(eventlog_level_error,"d2game_process","[%d] could not connect to server (psock_getsockopt[psock_connect]: %s)",virtconn_get_client_socket(vc),strerror(err));
			virtconn_destroy(vc);
			continue;
		    }
		}
		else
		{
		    currsize = virtconn_get_serverout_size(vc);
		    switch (net_send_packet(d2game_ssocket,queue_peek_packet((t_queue const * const *)virtconn_get_serverout_queue(vc)),&currsize)) /* avoid warning */
		    {
		    case -1:
			virtconn_destroy(vc);
			continue;
			
		    case 0: /* still working on it */
			virtconn_set_serverout_size(vc,currsize);
			break;
			
		    case 1: /* done sending */
			packet = queue_pull_packet(virtconn_get_serverout_queue(vc));
			if (hexstrm)
			{
			    fprintf(hexstrm,"%d: cli class=%s[0x%04hx] type=%s[0x%04hx] length=%hu\n",
				    d2game_csocket,
				    packet_get_class_str(packet),packet_get_class(packet),
				    packet_get_type_str(packet,packet_dir_from_client),packet_get_type(packet),
				    packet_get_size(packet));
			    hexdump(hexstrm,packet_get_raw_data_const(packet,0),packet_get_size(packet));
			}
			packet_del_ref(packet);
			virtconn_set_serverout_size(vc,0);
		    }
		}
	    }
	    list_purge(virtconnlist());
	}
    }
/*	d2game server check fd sets ends    */


	/* check for incoming connection */
/*
	if (!curr_exittime) 
*/
		
/* don't allow connections while exiting... FIXME: close listening sockets instead? */
	LIST_TRAVERSE_DATA_CONST(laddrs,elem,curr_laddr)
	{
		laddr_data = addr_get_data(curr_laddr);
		laddr_info = laddr_data.p;
		
		ssocket = laddr_info->ssocket;
		usocket = laddr_info->usocket;
		
		if (PSOCK_FD_ISSET(ssocket,&rfds)) {
		    struct sockaddr_in caddr;
		    unsigned int       caddr_len;
		    
		    if (addr_get_addr_str(curr_laddr,tempa,sizeof(tempa))<0)
			strcpy(tempa,"x.x.x.x:x");
		    
		    /* accept the connection */
		    caddr_len = sizeof(caddr);
		    if ((csocket = psock_accept(ssocket,(struct sockaddr *)&caddr,&caddr_len))<0) {
			/* BSD, POSIX error for aborted connections, SYSV often uses EAGAIN or EPROTO*/
			if (
#ifdef PSOCK_EWOULDBLOCK
			    psock_errno()==PSOCK_EWOULDBLOCK ||
#endif
#ifdef PSOCK_ECONNABORTED
			    psock_errno()==PSOCK_ECONNABORTED ||
#endif
#ifdef PSOCK_EPROTO
			    psock_errno()==PSOCK_EPROTO ||
#endif
			    0)
			    eventlog(eventlog_level_error,"server_process","client aborted connection on %s (psock_accept: %s)",tempa,strerror(psock_errno()));
			else /* EAGAIN can mean out of resources _or_ connection aborted :( */
			    if (
#ifdef PSOCK_EINTR
				psock_errno()!=PSOCK_EINTR &&
#endif
				1)
				eventlog(eventlog_level_error,"server_process","could not accept new connection on %s (psock_accept: %s)",tempa,strerror(psock_errno()));
		    }
		    else {
			if (ipban_check(inet_ntoa(caddr.sin_addr))!=0) {
			    eventlog(eventlog_level_error,"server_process","[%d] connection from banned address %s denied (closing connection)",csocket,inet_ntoa(caddr.sin_addr));
			    psock_close(csocket);
			}
			else {
			    eventlog(eventlog_level_info,"server_process","[%d] accepted connection from %s on %s",csocket,addr_num_to_addr_str(ntohl(caddr.sin_addr.s_addr),ntohs(caddr.sin_port)),tempa);
			    
			    if (prefs_get_use_keepalive()) {
				int val=1;
				
				if (psock_setsockopt(csocket,PSOCK_SOL_SOCKET,PSOCK_SO_KEEPALIVE,(char *)&val,sizeof(val))<0)
				    eventlog(eventlog_level_error,"server_process","[%d] could not set socket option SO_KEEPALIVE (psock_setsockopt: %s)",csocket,strerror(psock_errno()));
				/* not a fatal error */
			    }
			    
			    if (psock_ctl(csocket,PSOCK_NONBLOCK)<0) {
				eventlog(eventlog_level_error,"server_process","[%d] could not set TCP socket to non-blocking mode (closing connection) (psock_ctl: %s)",csocket,strerror(psock_errno()));
				psock_close(csocket);
			    }
			    else
				if (!(c = conn_create(csocket,usocket,addr_get_ip(curr_laddr),addr_get_port(curr_laddr),ntohl(caddr.sin_addr.s_addr),ntohs(caddr.sin_port)))) {
				    eventlog(eventlog_level_error,"server_process","[%d] unable to create new connection (closing connection)",csocket);
				    psock_close(csocket);
				}
			}
		    }
		}
		
		if (PSOCK_FD_ISSET(usocket,&rfds))
		{
                    int                err;
                    int                errlen;
		    t_packet *         upacket;
		    struct sockaddr_in fromaddr;
		    int                fromlen;
		    int                len;
                    
                    errlen = sizeof(err);
                    if (psock_getsockopt(usocket,PSOCK_SOL_SOCKET,PSOCK_SO_ERROR,(char *)&err,&errlen)<0)
                        eventlog(eventlog_level_error,"server_process","[%d] unable to read socket error (psock_getsockopt: %s)",usocket,strerror(psock_errno()));
		    else
			if (err!=0) /* if it was an error, there is no packet to read */
        		    eventlog(eventlog_level_error,"server_process","[%d] async UDP socket error notification (psock_getsockopt: %s)",usocket,strerror(err));
			else
			    if (!(upacket = packet_create(packet_class_udp)))
				eventlog(eventlog_level_error,"server_process","could not allocate raw packet for input");
			    else
			    {
				fromlen = sizeof(fromaddr);
				if ((len = psock_recvfrom(usocket,packet_get_raw_data_build(upacket,0),MAX_PACKET_SIZE,0,(struct sockaddr *)&fromaddr,&fromlen))<0)
				{
				    if (
#ifdef PSOCK_EINTR
					psock_errno()!=PSOCK_EINTR &&
#endif
#ifdef PSOCK_EAGAIN
					psock_errno()!=PSOCK_EAGAIN &&
#endif
#ifdef PSOCK_EWOULDBLOCK
					psock_errno()!=PSOCK_EWOULDBLOCK &&
#endif
					1)
					eventlog(eventlog_level_error,"server_process","could not recv UDP datagram (psock_recvfrom: %s)",strerror(psock_errno()));
				}
				else
				{
				    if (fromaddr.sin_family!=AF_INET)
					eventlog(eventlog_level_error,"server_process","got UDP datagram with bad address family %d",fromaddr.sin_family);
				    else
				    {
					packet_set_size(upacket,len);
					
					if (hexstrm)
					{
					    if (addr_get_addr_str(curr_laddr,tempa,sizeof(tempa))<0)
						strcpy(tempa,"x.x.x.x:x");
					    fprintf(hexstrm,"%d: recv class=%s[0x%04hx] type=%s[0x%04hx] from=%s to=%s length=%u\n",
						    usocket,
						    packet_get_class_str(upacket),packet_get_class(upacket),
						    packet_get_type_str(upacket,packet_dir_from_client),packet_get_type(upacket),
						    addr_num_to_addr_str(ntohl(fromaddr.sin_addr.s_addr),ntohs(fromaddr.sin_port)),
						    tempa,
						    packet_get_size(upacket));
					    hexdump(hexstrm,packet_get_raw_data(upacket,0),packet_get_size(upacket));
					}
					
					handle_udp_packet(usocket,ntohl(fromaddr.sin_addr.s_addr),ntohs(fromaddr.sin_port),upacket);
				    }
				}
				packet_del_ref(upacket);
			    }
		}
	    }
	
	/* search connections for sockets that need service */
	LIST_TRAVERSE_DATA_CONST(connlist(),elem,c)
	{
	    unsigned int currsize;
	    t_packet *   packet;
	    
	    if (conn_get_state(c)==conn_state_destroy)
	    {
		conn_destroy(c);
		continue;
	    }
            csocket = conn_get_socket(c);
	    
	    if (PSOCK_FD_ISSET(csocket,&rfds))
	    {
		if (conn_get_state(c)==conn_state_initial) {
		    if (init_connection(c)<0) {
			conn_destroy(c);
			continue;
		    }
		}
		else {
		    currsize = conn_get_in_size(c);
		    
		    if (!*conn_get_in_queue(c)) {
			switch (conn_get_class(c))
			{
			case conn_class_normal:
			    if (!(packet = packet_create(packet_class_normal)))
			    {
				eventlog(eventlog_level_error,"server_process","could not allocate normal packet for input");
				continue;
			    }
			    break;
			case conn_class_file:
			    if (!(packet = packet_create(packet_class_file)))
			    {
				eventlog(eventlog_level_error,"server_process","could not allocate file packet for input");
				continue;
			    }
			    break;
			case conn_class_bits:
			    if (!(packet = packet_create(packet_class_bits)))
			    {
				eventlog(eventlog_level_error,"server_process","could not allocate BITS packet for input");
				continue;
			    }
			    break;
			case conn_class_defer:
			case conn_class_bot:
			    if (!(packet = packet_create(packet_class_raw)))
			    {
				eventlog(eventlog_level_error,"server_process","could not allocate raw packet for input");
				continue;
			    }
			    packet_set_size(packet,1); /* start by only reading one char */
			    break;
			case conn_class_auth:
			    if (!(packet = packet_create(packet_class_auth)))
			    {
				eventlog(eventlog_level_error,"server_process","could not allocate auth packet for input");
				continue;
			    }
			    break;
			    
			default:
			    eventlog(eventlog_level_error,"server_process","[%d] connection has bad class (closing connection)",conn_get_socket(c));
			    conn_destroy(c);
			    continue;
			}
			queue_push_packet(conn_get_in_queue(c),packet);
			packet_del_ref(packet);
			if (!*conn_get_in_queue(c))
			    continue; /* push failed */
			currsize = 0;
		    }
		    
		    packet = queue_peek_packet((t_queue const * const *)conn_get_in_queue(c)); /* avoid warning */
		    switch (net_recv_packet(csocket,packet,&currsize))
		    {
		    case -1:
			conn_destroy(c);
			continue;
			
		    case 0: /* still working on it */
			conn_set_in_size(c,currsize);
			break;
			
		    case 1: /* done reading */
			switch (conn_get_class(c)) 
			{

			case conn_class_defer:
			{
			    unsigned char const * const temp=packet_get_raw_data_const(packet,0);
			    eventlog(eventlog_level_debug,"server_process","[%d] got first packet byte %02x",conn_get_socket(c),(unsigned int)temp[0]);
			    if (temp[0]==0xff) 
			    {
				packet_set_class(packet,packet_class_normal);
				conn_set_class(c,conn_class_normal);
				conn_set_in_size(c,currsize);
				eventlog(eventlog_level_debug,"server_process","[%d] defered connection class is normal",conn_get_socket(c));
			    }
			    else 
			    {
				packet_set_class(packet,packet_class_auth);
				conn_set_class(c,conn_class_auth);
				conn_set_in_size(c,currsize);
				eventlog(eventlog_level_debug,"server_process","[%d] defered connection class is auth",conn_get_socket(c));
			    }
			}
			break;
	
			case conn_class_bot:

			if (currsize<MAX_PACKET_SIZE) /* if we overflow, we can't wait for the end of the line.
							 handle_conn_packet() should take care of it */
			{
			    char const * const temp=packet_get_raw_data_const(packet,0);
			    
			    if (temp[currsize-1]!='\r' && temp[currsize-1]!='\n')
			    {
				conn_set_in_size(c,currsize);
				packet_set_size(packet,currsize+1);
			        break; /* no end of line, get another char */
			    }
			    /* got a complete line... fall through */
			}

			default:
			    packet = queue_pull_packet(conn_get_in_queue(c));
			
			    if (hexstrm)
			    {
				fprintf(hexstrm,"%d: recv class=%s[0x%04hx] type=%s[0x%04hx] length=%u\n",
				        csocket,
					packet_get_class_str(packet),packet_get_class(packet),
					packet_get_type_str(packet,packet_dir_from_client),packet_get_type(packet),
					packet_get_size(packet));
			    hexdump(hexstrm,packet_get_raw_data_const(packet,0),packet_get_size(packet));
			    }
			
			    if (conn_get_class(c)==conn_class_bot) /* NUL terminate the line to make life easier */
			    {
				char * const temp=packet_get_raw_data(packet,0);
			    
				if (temp[currsize-1]=='\r' || temp[currsize-1]=='\n')
				    temp[currsize-1] = '\0'; /* have to do it here instead of above so everything
							    is intact for the hexdump */
				}
			
			    if (handle_conn_packet(c,packet)<0)
			    {
				packet_del_ref(packet);
				conn_destroy(c);
				continue;
			    }
			    packet_del_ref(packet);
			    conn_set_in_size(c,0);
			}
		    }
		}
	    }
	    
	    if (PSOCK_FD_ISSET(csocket,&wfds))
	    {
		currsize = conn_get_out_size(c);
		switch (net_send_packet(csocket,queue_peek_packet((t_queue const * const *)conn_get_out_queue(c)),&currsize)) /* avoid warning */
		{
		case -1:
		    conn_destroy(c);
		    continue;
		    
		case 0: /* still working on it */
		    conn_set_out_size(c,currsize);
		    break;
		    
		case 1: /* done sending */
		    packet = queue_pull_packet(conn_get_out_queue(c));
		    
		    if (hexstrm)
		    {
			fprintf(hexstrm,"%d: send class=%s[0x%04hx] type=%s[0x%04hx] length=%u\n",
				csocket,
				packet_get_class_str(packet),packet_get_class(packet),
				packet_get_type_str(packet,packet_dir_from_server),packet_get_type(packet),
				packet_get_size(packet));
		        hexdump(hexstrm,packet_get_raw_data(packet,0),packet_get_size(packet));
		    }
		    
		    packet_del_ref(packet);
		    conn_set_out_size(c,0);
		}
	    }
	    list_purge(connlist());
	}
    }

    LIST_TRAVERSE_DATA_CONST(virtconnlist(),elem,vc)
    {	
	virtconn_destroy(vc);
    }
    
    LIST_TRAVERSE_DATA_CONST(connlist(),elem,c)
    {
        conn_destroy(c);
    }
    
    LIST_TRAVERSE_DATA_CONST(laddrs,elem,curr_laddr)
    {
	laddr_data = addr_get_data(curr_laddr);
	laddr_info = laddr_data.p;
	
	if (laddr_info)
	{
	    psock_close(laddr_info->usocket);
	    psock_close(laddr_info->ssocket);
	    free(laddr_info);
	}
    }
    addrlist_destroy(laddrs);
    
    tracker_set_servers(NULL);
    
    return 0;
    
    /************************************************************************/
    
    /* error cleanup */
    
    error_listen:
	LIST_TRAVERSE_DATA_CONST(laddrs,elem,curr_laddr)
	{
	    laddr_data = addr_get_data(curr_laddr);
	    laddr_info = laddr_data.p;
	    
	    if (laddr_info)
	    {
		psock_close(laddr_info->usocket);
		psock_close(laddr_info->ssocket);
		free(laddr_info);
	    }
	}
	addrlist_destroy(laddrs);
	
	/*
	LIST_TRAVERSE_DATA_CONST(d2servlist(),elem,curr_taddr)
	{
	taddr_data = addr_get_data(curr_taddr);
	d2serv_info = taddr_data.p;
	
	if (d2serv_info)
	{
	    psock_close(d2serv_info->tsocket);
	    free(d2serv_info);
	}
	}	
	addrlist_destroy(d2servlist());
	*/
    
    tracker_set_servers(NULL);
	
    error_track:
	tracker_set_servers(NULL);
    
    return -1;
}

