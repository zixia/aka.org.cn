/*
 * Copyright (C) 2000  Onlyer (onlyer@263.net)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#include "config.h"
#include "setup.h"

#include "handle_normal.h"
#include "handle_file.h"
#include "handle_bot.h"
#include "handle_auth.h"

#include "connection.h"
#include "packet.h"
#include "eventlog.h"
#include "bnetd.h"


extern int handle_conn_packet(t_connection * c, t_packet const * const packet)
{
    
    int retval;

    if (!c)
    {
	eventlog(eventlog_level_error,"handle_conn_packet","[%d] got NULL connection",conn_get_socket(c));
	return -1;
    }
    if (!packet)
    {
	eventlog(eventlog_level_error,"handle_conn_packet","[%d] got NULL packet",conn_get_socket(c));
	return -1;
    }
    
    switch (conn_get_class(c))
    {
    case conn_class_normal:
	retval=handle_normal_packet(c,packet);
	break;

    case conn_class_auth:
	retval=handle_auth_packet(c,packet);
	break;

	
    case conn_class_file:
	retval=handle_file_packet(c,packet);
	break;
	
    case conn_class_bot:
	retval=handle_bot_packet(c,packet);
        break;

    default:
	eventlog(eventlog_level_error,"handle_conn_packet","[%d] unknown connection type %d",conn_get_socket(c),(int)conn_get_class(c));
	retval=0;
	break;
    }
    
    return retval;
}

