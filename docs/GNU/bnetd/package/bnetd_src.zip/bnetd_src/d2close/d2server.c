/*
 * Copyright (C) 2000  Onlyer (onlyer@263.net)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#define D2SERVER_INTERNAL_ACCESS
#include "config.h"
#include "setup.h"
#include <errno.h>

#define USE_STDC_HEADERS
#define USE_STDDEF_HEADERS
#define USE_SOCKET_HEADERS
#define USE_UNISTD_HEADERS
#define USE_FCNTL_HEADERS
#define USE_STRING_HEADERS
#define USE_TIME_HEAADERS

#include "compat.h"

#include "compat/psock.h"
#include "compat/strerror.h"
#include "addr.h"
#include "list.h"
#include "prefs.h"
#include "eventlog.h"
#include "d2server.h"

static t_addrlist * d2servlist_head=NULL;
static unsigned int d2serv_id=0;

extern t_addrlist * d2servlist(void)
{
    return d2servlist_head;
}


extern int d2servlist_create(void)
{
  if
  (!(d2servlist_head=addrlist_create(prefs_get_d2game_rservaddr(),INADDR_ANY,(unsigned short)prefs_get_d2game_rport()))) 
  {
    eventlog(eventlog_level_error,"d2servlist_create","could not create addrlist");
    return -1;
  }
  return 0;
}

extern int d2servlist_destroy(void)
{
    t_elem const *    elem;
    t_addr *	      addr;
    t_d2serv_info *   info;

    LIST_TRAVERSE_DATA_CONST(d2servlist_head,elem,addr)
    {
	if ((info=addr_get_info(addr))) {
	    psock_close(info->tsocket);
	    free(info);
	}
    }
    return addrlist_destroy(d2servlist_head);
}


extern int d2servlist_add_server(char const * servname)
{
    t_addr	  * addr;

    if (!servname) {
	eventlog(eventlog_level_error,"d2servlist_add_server","got NULL servname");
	return -1;
    }
    if (!(addr=addr_create_str(servname,INADDR_ANY,(unsigned short)prefs_get_d2game_rport()))) {
	eventlog(eventlog_level_error,"d2servlist_add_server","could not create addr");
	return -1;
    }
    if (list_append_data(d2servlist_head,addr)<0) {
	eventlog(eventlog_level_error,"d2servlist_add_server","could not add addr to list");
	addr_destroy(addr);
	return -1;
    }
    d2server_create_info(addr);
    return 0;
}

extern t_addr * d2servlist_get_server_by_id(unsigned int id)
{
      t_addr	      * addr;
      t_elem const    * elem;
      t_d2serv_info   * info;

      LIST_TRAVERSE_DATA_CONST(d2servlist_head,elem,addr)
      {
	  if (!(info=addr_get_info(addr))) {
	      eventlog(eventlog_level_debug,"d2servlist_get_server_by_id","got NULL info in list");
	      continue;
	  }
	  if (info->id==id) return addr;
      }
      return NULL;
}
	  

extern int d2servlist_del_server(unsigned int id)
{
    t_addr *	      addr;
    
    if (!(addr=d2servlist_get_server_by_id(id))) {
	eventlog(eventlog_level_debug,"d2servlist_del_server","server %d not found in list",id);
	return -1;
    }
    if (d2server_destroy(addr)<0) {
	eventlog(eventlog_level_error,"d2servlist_del_server","could not destroy addr");
	return -1;
    }
    if (list_remove_data(d2servlist_head,addr)<0) {
	eventlog(eventlog_level_error,"d2servlist_del_server","could not remove item from list");
	return -1;
    }
    return 0;
}


extern t_addr * d2servlist_choose_server(void)
{
    t_addr *		     taddr;
    t_addr *		     oaddr=NULL;
    unsigned int	     percent;
    unsigned int	     min_percent=100;
    t_elem const *	     elem;
    t_d2serv_info *	     info;

    LIST_TRAVERSE_DATA_CONST(d2servlist_head,elem,taddr)
    {
	if (addr_get_ip(taddr)==INADDR_NONE || addr_get_ip(taddr)==INADDR_ANY ) continue;
	if (!(info=addr_get_info(taddr))) continue;
	if (info->status!=d2server_status_connected) continue;
	if (info->gamenum>=info->maxgame) continue;
	if (!info->maxgame) continue;
	percent=100*info->gamenum/info->maxgame;
	if (percent<min_percent) {
	    min_percent=percent;
	    oaddr=taddr;
	}
    }
    if (!oaddr) {
	eventlog(eventlog_level_debug,"d2game_get_servaddr","no available d2game server now");
	return NULL;
    }
    return oaddr;
}

extern int d2servlist_retest(void)
{
    t_addr *		     taddr;
    t_elem const *	     elem;
    t_d2serv_info *	     info;

    LIST_TRAVERSE_DATA_CONST(d2servlist_head,elem,taddr)
    {
	  if (!(info=addr_get_info(taddr))) {
		eventlog(eventlog_level_debug,"d2servlist_retest","got NULL info");
		continue;
	  }
	  info->lasttest=0;
    }
    return 0;
}

extern unsigned int d2server_get_id(t_addr * addr)
{
    t_d2serv_info *	  info;

    if (!addr) {
	eventlog(eventlog_level_error,"d2server_get_id","got NULL addr");
	return 0;
    }
    if (!(info=addr_get_info(addr))) {
	eventlog(eventlog_level_debug,"d2server_get_id","got NULL info");
	return 0;
    }
    return info->id;
}


extern int d2server_create_info(t_addr * taddr)
{
    t_d2serv_info *	    info;
    t_addr_data		    data;

    if (!taddr) {
	eventlog(eventlog_level_error,"d2sever_create_info","got NULL addr");
	return -1;
    }
    if (addr_get_info(taddr)) {
	eventlog(eventlog_level_error,"d2server_create_info","addr already have info");
	return -1;
    }


    if (!(info=malloc(sizeof(t_d2serv_info)))) {
	eventlog(eventlog_level_debug,"d2server_create_info","could not malloc info");
	return -1;
    }
    d2serv_id++;
    if (d2serv_id==0) d2serv_id=1;

    info->id=d2serv_id;
    info->lasttest=0;
    info->tsocket=0;
    info->gamenum=0;
    info->maxgame=prefs_get_maxd2game();
    info->token=1;
    info->status=d2server_status_none;
    data=addr_get_data(taddr);
    data.p=info;
    addr_set_data(taddr,data);

    return 0;
}


extern int d2server_destroy(t_addr * addr)
{
    t_d2serv_info *   info;

    if (!addr) {
	eventlog(eventlog_level_error,"d2server_destroy","got NULL addr");
	return -1;
    }
    if (!(info=addr_get_info(addr))) {
	eventlog(eventlog_level_debug,"d2server_destroy","got NULL info");
	return -1;
    }
    psock_close(info->tsocket);
    free(info);
    return addr_destroy(addr);
}


extern int d2server_set_status(t_addr * addr, t_d2server_status status)
{
    t_d2serv_info *   info;

    if (!addr) {
	eventlog(eventlog_level_error,"d2server_set_status","got NULL addr");
	return -1;
    }
    if (!(info=addr_get_info(addr))) {
	eventlog(eventlog_level_debug,"d2server_set_status","got NULL info");
	return -1;
    }
    info->status=status;
    return 0;
}

extern t_d2server_status d2server_get_status(t_addr * addr)
{
    t_d2serv_info *   info;

    if (!addr) {
	eventlog(eventlog_level_error,"d2server_set_status","got NULL addr");
	return -1;
    }
    if (!(info=addr_get_info(addr))) {
	eventlog(eventlog_level_debug,"d2server_set_status","got NULL info");
	return -1;
    }
    return info->status;
}


extern int d2server_connect(t_addr * addr)
{
    int			tsocket;
    struct sockaddr_in	servaddr;
    t_d2serv_info *	info;
    unsigned long	ip;
    unsigned short	rport;


    if (!addr) {
	eventlog(eventlog_level_error,"d2server_connect","got NULL addr");
	return -1;
    }


    if (!(info=addr_get_info(addr))) {
        eventlog(eventlog_level_debug,"d2server_connect","got NULL server info");
        return -1;
    }

    if ((tsocket=psock_socket(PSOCK_PF_INET,PSOCK_SOCK_STREAM,0))<0)
    {
	eventlog(eventlog_level_error,"d2server_create_info","could not create testing socket(psock_socket:%s)",strerror(psock_errno()));
	return -1;
    }
    if (prefs_get_use_keepalive()) {
	int val=1;
	if (psock_setsockopt(tsocket,PSOCK_SOL_SOCKET,PSOCK_SO_KEEPALIVE,(char *)&val,sizeof(val))<0)
	eventlog(eventlog_level_error,"d2server_create_info","could not set socket option SO_KEEPALIVE (psock_setsockopt: %s)",strerror(psock_errno()));
    }
    if (psock_ctl(tsocket,PSOCK_NONBLOCK)<0)
    {
	psock_close(tsocket);
	eventlog(eventlog_level_error,"d2server_create_info","could not set NONBLOCK on socket (psock_ctl:%s)",strerror(psock_errno()));
	return -1;
    }

    ip	    = addr_get_ip(addr);
    rport   = addr_get_port(addr);

    memset(&servaddr,0,sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port	= htons(rport);
    servaddr.sin_addr.s_addr	=   htonl(ip);
    
    if (psock_connect(tsocket,(struct sockaddr *)&servaddr,sizeof(servaddr))<0) {
	if (psock_errno()!=PSOCK_EWOULDBLOCK && psock_errno()!=PSOCK_EINPROGRESS)
	{
	    eventlog(eventlog_level_error,"d2server_connect","connection error (psock_connect:%s)",strerror(psock_errno()));
	    info->status=d2server_status_none;
	    psock_close(tsocket);
	    return 0;
	}
	info->status=d2server_status_connecting;
	info->tsocket=tsocket;
	return 1;
    }
    info->status=d2server_status_connected;
    info->tsocket=tsocket;
    return 1;
}


extern int d2server_set_gamenum(t_addr * addr, unsigned int gamenum)
{
    t_d2serv_info *   info;

    if (!addr) {
	eventlog(eventlog_level_error,"d2server_set_status","got NULL addr");
	return -1;
    }
    if (!(info=addr_get_info(addr))) {
	eventlog(eventlog_level_debug,"d2server_set_status","got NULL info");
	return -1;
    }
    info->gamenum=gamenum;
    return 0;
}

extern int d2server_get_gamenum(t_addr * addr)
{
    t_d2serv_info *   info;

    if (!addr) {
	eventlog(eventlog_level_error,"d2server_set_status","got NULL addr");
	return -1;
    }
    if (!(info=addr_get_info(addr))) {
	eventlog(eventlog_level_debug,"d2server_set_status","got NULL info");
	return -1;
    }
    return info->gamenum;
}

extern int d2server_set_token(t_addr * addr, unsigned int token)
{
    t_d2serv_info *   info;

    if (!addr) {
	eventlog(eventlog_level_error,"d2server_set_status","got NULL addr");
	return -1;
    }
    if (!(info=addr_get_info(addr))) {
	eventlog(eventlog_level_debug,"d2server_set_status","got NULL info");
	return -1;
    }
    info->token=token;
    return 0;
}


extern int d2server_get_token(t_addr * addr)
{
    t_d2serv_info *  info;

    if (!addr) {
	eventlog(eventlog_level_error,"d2server_set_status","got NULL addr");
	return -1;
    }
    if (!(info=addr_get_info(addr))) {
	eventlog(eventlog_level_debug,"d2server_set_status","got NULL info");
	return -1;
    }
    return info->token;
}

extern unsigned int d2server_get_socket(t_addr * addr)
{
    t_d2serv_info *   info;

    if (!addr) {
	eventlog(eventlog_level_error,"d2server_set_status","got NULL addr");
	return 0;
    }
    if (!(info=addr_get_info(addr))) {
	eventlog(eventlog_level_debug,"d2server_set_status","got NULL info");
	return 0;
    }
    return info->tsocket;

}

extern time_t d2server_get_lasttest(t_addr * addr)
{
    t_d2serv_info *   info;

    if (!addr) {
	eventlog(eventlog_level_error,"d2server_set_status","got NULL addr");
	return 0;
    }
    if (!(info=addr_get_info(addr))) {
	eventlog(eventlog_level_debug,"d2server_set_status","got NULL info");
	return 0;
    }
    return info->lasttest;
}

extern int d2server_set_lasttest(t_addr * addr, time_t lasttest)
{
    t_d2serv_info *   info;

    if (!addr) {
	eventlog(eventlog_level_error,"d2server_set_status","got NULL addr");
	return -1;
    }
    if (!(info=addr_get_info(addr))) {
	eventlog(eventlog_level_debug,"d2server_set_status","got NULL info");
	return -1;
    }
    info->lasttest=lasttest;
    return 0;
}

extern unsigned int d2server_get_maxgame(t_addr * addr)
{
    t_d2serv_info *   info;

    if (!addr) {
	eventlog(eventlog_level_error,"d2server_set_status","got NULL addr");
	return 0;
    }
    if (!(info=addr_get_info(addr))) {
	eventlog(eventlog_level_debug,"d2server_set_status","got NULL info");
	return 0;
    }
    return info->maxgame;
}

extern int d2server_set_maxgame(t_addr * addr, unsigned int maxgame)
{
    t_d2serv_info *   info;

    if (!addr) {
	eventlog(eventlog_level_error,"d2server_set_status","got NULL addr");
	return -1;
    }
    if (!(info=addr_get_info(addr))) {
	eventlog(eventlog_level_debug,"d2server_set_status","got NULL info");
	return -1;
    }
    info->maxgame=maxgame;
    return 0;
}

