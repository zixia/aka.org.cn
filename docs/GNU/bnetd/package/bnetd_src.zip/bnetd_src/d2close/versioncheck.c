/*
 * Copyright (C) 2000 Onlyer (onlyer@263.net)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#define VERSIONCHECK_INTERNAL_ACCESS
#include "config.h"
#include "setup.h"
#include <stdio.h>
#include <errno.h>

#define USE_STDDEF_HEADERS
#define USE_STDC_HEADERS
#define USE_STRING_HEADERS

#include "compat.h"

#include "compat/strerror.h"
#include "eventlog.h"
#include "list.h"
#include "util.h"
#include "bn_type.h"
#include "packet.h"
#include "bnet_protocol.h"
#include "prefs.h"
#include "versioncheck.h"


static t_list * versioncheck_head=NULL;

extern int versioncheck_load(char const * filename)
{
    FILE *	      fp;
    unsigned int      line;
    unsigned int      len;
    unsigned int      pos;
    char *	      buff;
    char *	      temp;
    char const *      archtag;
    char const *      clienttag;
    char const *      bnversion;
    char const *      gameversion;
    char const *      checksum;
    char const *      mpqfile;
    t_versioninfo *   entry;
    
    if (!filename)
    {
	eventlog(eventlog_level_error,"versioncheck_load","got NULL filename");
	return -1;
    }
    
    if (!(versioncheck_head = list_create()))
    {
	eventlog(eventlog_level_error,"versioncheck_load","could create list");
	return -1;
    }
    if (!(fp = fopen(filename,"r")))
    {
	eventlog(eventlog_level_error,"versioncheck_load","could not open file \"%s\" for reading (fopen: %s)",filename,strerror(errno));
	list_destroy(versioncheck_head);
	versioncheck_head = NULL;
	return -1;
    }

    for (line=1; (buff = file_get_line(fp)); line++)
    {
	for (pos=0; buff[pos]=='\t' || buff[pos]==' '; pos++);
	len = strlen(buff)+1;
	if (buff[pos]=='\0' || buff[pos]=='#')
	{
	    free(buff);
	    continue;
	}
        {
            unsigned int endpos;

            if ((temp = strrchr(buff,'#'))) *temp = '\0';

            for (endpos=strlen(buff)-1;  buff[endpos]=='\t' || buff[endpos]==' '; endpos--);
            buff[endpos+1] = '\0';
            len = strlen(buff)+1;
        }

	if (!(archtag = strtok(buff," \t"))) /* strtok modifies the string it is passed */
	{
	    eventlog(eventlog_level_error,"versioncheck_load","missing archtag on line %u of file \"%s\"",line,filename);
	    free(buff);
	    continue;
	}
	if (!(clienttag = strtok(NULL," \t")))
	{
	    eventlog(eventlog_level_error,"versioncheck_load","missing clienttag on line %u of file \"%s\"",line,filename);
	    free(buff);
	    continue;
	}
	if (!(bnversion = strtok(NULL," \t")))
	{
	    eventlog(eventlog_level_error,"versioncheck_load","missing bnver on line %u of file \"%s\"",line,filename);
	    free(buff);
	    continue;
	}
	if (!(gameversion = strtok(NULL," \t")))
	{
	    eventlog(eventlog_level_error,"versioncheck_load","missing gamever on line %u of file \"%s\"",line,filename);
	    free(buff);
	    continue;
	}
	if (!(checksum = strtok(NULL," \t")))
	{
	    eventlog(eventlog_level_error,"versioncheck_load","missing checksum on line %u of file \"%s\"",line,filename);
	    free(buff);
	    continue;
	}
	if (!(mpqfile = strtok(NULL," \t")))
	{
	    eventlog(eventlog_level_error,"versioncheck_load","missing mpqfile on line %u of file \"%s\"",line,filename);
	    free(buff);
	    continue;
	}
	if (!(entry = malloc(sizeof(t_versioninfo))))
	{
	    eventlog(eventlog_level_error,"versioncheck_load","could not allocate memory for entry");
	    free(buff);
	    continue;
	}
	if (!(entry->mpqfile = strdup(mpqfile)))
	{
	    eventlog(eventlog_level_error,"versioncheck_load","could not allocate memory for mpqfile");
	    free(entry);
	    free(buff);
	    continue;
	}

	bn_int_tag_set((bn_int *)&entry->archtag,archtag);
	bn_int_tag_set((bn_int *)&entry->clienttag,clienttag);
	entry->bnversion=(unsigned int)strtoul(bnversion,NULL,0);
	entry->gameversion=(unsigned int)strtoul(gameversion,NULL,0);
	entry->checksum=(unsigned int)strtoul(checksum,NULL,0);
	/* exeinfo aren`t important,by pass it */
	entry->exeinfo=NULL;
	
	free(buff);
	
	if (list_append_data(versioncheck_head,entry)<0)
	{
	    eventlog(eventlog_level_error,"versioncheck_load","could not append item");
	    free(entry);
	    free(entry->mpqfile);
	    continue;
	}
    }
    fclose(fp);
    
    return 0;
}


extern int versioncheck_unload(void)
{
    t_elem *	      elem;
    t_versioninfo *  entry;
    
    LIST_TRAVERSE_DATA(versioncheck_head,elem,entry)
    {
	if (entry->exeinfo) free(entry->exeinfo);
	if (entry->mpqfile) free(entry->mpqfile);
	free(entry);
	list_remove_elem(versioncheck_head,elem);
    }
    
    if (list_destroy(versioncheck_head)<0)
	return -1;
    versioncheck_head = NULL;
    return 0;
}


extern int versioncheck(t_packet const * packet, char * mpqfile)
{
    t_elem const *    elem;
    t_versioninfo *   entry;
    unsigned int      archtag;
    unsigned int      clienttag;
    unsigned int      bnversion;
    unsigned int      gameversion;
    unsigned int      checksum;
    int		      reply;

    /*
    char const *      exeinfo;
    */
    
    if (!packet) {
	eventlog(eventlog_level_error,"versioncheck","got NULL packet");
	return SERVER_AUTHREPLY_MESSAGE_ERROR;
    }
    /*
    if (packet_get_size(packet)<sizeof(t_client_authreq)) {
	eventlog(eventlog_level_error,"versioncheck","got packet with bad size");
	return SERVER_AUTHREPLY_MESSAGE_ERROR;
    }
    if (!(exeinfo=packet_get_str_const(packet,sizeof(t_client_authreq),128))) {
	eventlog(eventlog_level_error,"versioncheck","got packet with bad exeinfo");
	return SERVER_AUTHREPLY_MESSAGE_ERROR;
    }
    */

    archtag=bn_int_get(packet->u.client_authreq.archtag);
    clienttag=bn_int_get(packet->u.client_authreq.clienttag);
    bnversion=bn_int_get(packet->u.client_authreq.bnversion);
    gameversion=bn_int_get(packet->u.client_authreq.gameversion);
    checksum=bn_int_get(packet->u.client_authreq.checksum);
#ifdef DEBUG_VERSIONCHECK
	eventlog(eventlog_level_debug,"versioncheck","verision check on archtag: 0x%x, clienttag: 0x%X, bnversion: 0x%X, gameversion: 0x%X, checksum: 0x%X",archtag,clienttag,bnversion,gameversion,checksum);
#endif


    if (prefs_allow_unknownversion()) reply=SERVER_AUTHREPLY_MESSAGE_OK;
    else reply=SERVER_AUTHREPLY_MESSAGE_BADVERSION;

    LIST_TRAVERSE_DATA_CONST(versioncheck_head,elem,entry)
    {
#ifdef DEBUG_VERSIONCHECK
	eventlog(eventlog_level_debug,"versioncheck","verision check entry archtag: 0x%x, clienttag: 0x%X, bnversion: 0x%X, gameversion: 0x%X, checksum: 0x%X",entry->archtag,entry->clienttag,entry->bnversion,entry->gameversion,entry->checksum);
#endif
	if (entry->archtag!=archtag) continue;
	if (entry->clienttag!=clienttag) continue;
	if (entry->bnversion!=bnversion || entry->gameversion!=gameversion) {
	    reply=SERVER_AUTHREPLY_MESSAGE_UPDATE;
	    break;
	}
	if (entry->checksum!=checksum) {
	    if (prefs_allow_version_checksum()) reply=SERVER_AUTHREPLY_MESSAGE_UPDATE;
	    break;
	}
	return SERVER_AUTHREPLY_MESSAGE_OK;
    }

    if (reply==SERVER_AUTHREPLY_MESSAGE_UPDATE) {
	strncpy(mpqfile,entry->mpqfile,BNETD_FILE_NAME_LEN);
    }
    return reply;
}

