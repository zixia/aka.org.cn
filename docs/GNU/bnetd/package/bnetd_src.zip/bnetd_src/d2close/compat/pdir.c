/*
 * Copyright (C) 2000  Onlyer (onlyer@263.net)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#include "config.h"
#include "setup.h"

#ifdef HAVE_STRING_H
# include <string.h>
#endif

#include <stdio.h>

#include "pdir.h"


PSOCK_DIR psock_findfirst(char const * path,char * filename,unsigned int nsize)
{
#ifdef WIN32
    char               sPath[_MAX_PATH];
    long               lFindHandle;
    struct _finddata_t fileinfo;
    
    strcpy(&sPath[0],path);
    strcat(&sPath[0],"/*.*");
    memset(&fileinfo, 0, sizeof(fileinfo));
    lFindHandle=_findfirst((char *)&sPath,&fileinfo);
    if (lFindHandle<0) return PSOCK_DIR_ERROR;
    else {
	strncpy(filename,fileinfo.name,nsize);
	return lFindHandle;
    }
#else
    DIR *              dir;
    struct dirent *    dentry;

    dir=opendir(path);
    if (!dir) return PSOCK_DIR_ERROR;
    else {
	dentry=readdir(dir);
	if (!dentry) return PSOCK_DIR_ERROR;
	else {
	    strncpy(filename,dentry->d_name,nsize);
	    return dir;
	}
    }
#endif
}
	
int psock_findnext(PSOCK_DIR dir,char * filename,unsigned int nsize)
{
#ifdef WIN32
    struct _finddata_t fileinfo;
    if (_findnext(dir,&fileinfo)<0) return -1;
    else {
	strncpy(filename,fileinfo.name,nsize);
	return 0;
    }
#else
    struct dirent * dentry;
    dentry=readdir(dir);
    if (!dentry) return -1;
    else {
	strncpy(filename,dentry->d_name,nsize);
	return 0;
    }
#endif
}


int psock_findclose(PSOCK_DIR dir)
{
#ifdef WIN32
    return _findclose(dir);
#else
    return closedir(dir);
#endif
}


