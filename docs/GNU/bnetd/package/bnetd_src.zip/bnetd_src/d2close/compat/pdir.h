/*
 * Copyright (C) 2000  Onlyer (onlyer@263.net)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#ifndef INCLUDED_PDIR_PROTOS
#define INCLUDED_PDIR_PROTOS

#ifdef WIN32
# include <io.h>
#endif
#ifdef HAVE_DIRENT_H
# include <dirent.h>
#else
# ifdef HAVE_SYS_NDIR_H
#  include <sys/ndir.h>
# endif
# if HAVE_SYS_DIR_H
#  include <sys/dir.h>
# endif
# if HAVE_NDIR_H
#  include <ndir.h>
# endif
# define dirent direct
#endif

#include <stdlib.h>

#ifdef WIN32

#define PSOCK_DIR			    long
#define PSOCK_DIR_ERROR			    -1
#define PSOCK_MAX_PATH			    _MAX_PATH

#else

#define PSOCK_DIR			    DIR *
#define PSOCK_DIR_ERROR			    NULL
#define PSOCK_MAX_PATH			    255

#endif



PSOCK_DIR psock_findfirst(char const * path,char * filename,unsigned int nsize);

int psock_findnext(PSOCK_DIR dir,char * filename,unsigned int nsize);

int psock_findclose(PSOCK_DIR dir);

#endif
