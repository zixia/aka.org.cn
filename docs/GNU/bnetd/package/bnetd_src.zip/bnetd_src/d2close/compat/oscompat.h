#ifndef INCLUDED_OSCOMPAT_H
#define INCLUDED_OSCOMPAT_H

#ifndef WIN32

#ifndef O_BINARY
#define O_BINARY 	0x0
#endif

#endif

#endif

