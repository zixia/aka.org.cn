/*
 * Copyright (C) 2000  Ross Combs (rocombs@cs.nmsu.edu)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#include "config.h"
#ifndef HAVE_UNAME

#include "setup.h"
#ifdef HAVE_STRING_H
# include "string.h"
#else
# ifdef HAVE_STRINGS_H
#  include "strings.h"
# endif
#endif
#include <errno.h>
#include "uname.h"

extern int uname(struct utsname * buf)
{
    if (!buf)
    {
	errno = EFAULT;
	return -1;
    }
    
#ifdef WIN32
    strcpy(buf->sysname,"Micros~1 Windows 95/95SP1/95A/95B/95B+MSIE/98/98OEM/98SE/2000 or Windows \"New Technology\" 3.1/3.5/3.51/4.0/4.0SP1/4.0SP2/4.0SP3/4.0SP4/4.0SP6");
#else
    strcpy(buf->sysname,"");
#endif
    strcpy(buf->nodename,"");
    strcpy(buf->release,"");
    strcpy(buf->version,"");
    strcpy(buf->machine,"");
    strcpy(buf->domainname,"");
    
    return 0;
}

#endif
