/*
 * Copyright (C) 1999  Philippe Dubois (pdubois1@hotmail.com)
 * Copyright (C) 1999  Ross Combs (rocombs@cs.nmsu.edu)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#ifndef INCLUDED_SOCKET_PROTOS
#define INCLUDED_SOCKET_PROTOS

/*
 * This file is like the other compat header files in that it
 * tries to hide differences between systems. It is somewhat
 * different in that it doesn't present a "normal" interface
 * to the rest of the code, but instead defines its own macros
 * and functions. This is done since Win32 uses closesocket()
 * instead of close() for sockets, but it can't be remapped
 * since it already has a close() for file descriptors. Also,
 * this allows us to hide the fact that some systems use
 * fcntl() and some use ioctl()...
 *
 * This file must be included _after_ any other socket related
 * headers and any other compat socket fixup headers.
 */

#ifdef WIN32 /* winsock2 */

#include <Winsock2.h>
/*
 * Including that file is basically equivalent to including:
 * <sys/socket.h>
 * <sys/param.h>
 * <netinet/in.h>
 * <arpa/inet.h>
 * <netdb.h>
 */

#endif

#endif
