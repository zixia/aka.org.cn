/*
 * Copyright (C) 1999  Ross Combs (rocombs@cs.nmsu.edu)
 * Copyright (C) 2000  Onlyer (onlyer@263.net)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#define VIRTCONN_INTERNAL_ACCESS
#include "config.h"
#include "setup.h"

#include <errno.h>

#define USE_STDDEF_HEADERS
#define USE_STDC_HEADERS
#define USE_UNISTD_HEADERS
#define USE_STRING_HEADERS
#define USE_SOCKET_HEADERS
#define USE_SYS_TYPES_HEADERS

#include "compat.h"

#include "compat/psock.h"
#include "queue.h"
#include "list.h"
#include "eventlog.h"
#include "packet.h"
#include "virtconn.h"
#include "connection.h"
#include "prefs.h"
#include "addr.h"
#include "d2game.h"
#include "d2server.h"
#include "game.h"


static t_list * virtconn_head=NULL;



extern int virtconn_init(t_virtconn * vc)
{
        t_packet * rpacket;
	eventlog(eventlog_level_info,"init_virtconn","[%d] client initiated d2game connection",virtconn_get_client_socket(vc));
	virtconn_set_class(vc,virtconn_class_bot);
	if ((rpacket=packet_create(packet_class_d2game))) {
	    packet_set_size(rpacket,1);
	    packet_set_type(rpacket,D2GAME_SERVER_WELCOME);
	    queue_push_packet(virtconn_get_clientout_queue(vc),rpacket);
	    packet_del_ref(rpacket);
	}
	virtconn_set_state(vc,virtconn_state_login);
	return 0;
}
	

extern int virtconn_connect(t_virtconn * vc)
{
    t_game *		   game;
    t_addr *		   addr;
    struct sockaddr_in	   servaddr;

    game=virtconn_get_game(vc);
    if (!game) {
      eventlog(eventlog_level_error,"virtconn_connect","can not connect to server without game set");
      return -1;
    }
    if (!(addr=d2servlist_get_server_by_id(game_get_d2servid(game)))) {
      eventlog(eventlog_level_error,"virtconn_connect","no server id %d",game_get_d2servid(game));
      return -1;
    }
    
    memset(&servaddr,0,sizeof(servaddr));
    servaddr.sin_family  = AF_INET;
    servaddr.sin_port    = htons(addr_get_port(addr));
    servaddr.sin_addr.s_addr = htonl(addr_get_ip(addr));
    
    /* now connect to the real server */
    if (psock_connect(virtconn_get_server_socket(vc),(struct sockaddr *)&servaddr,sizeof(servaddr))<0) {
	if (psock_errno()!=PSOCK_EWOULDBLOCK && psock_errno()!=PSOCK_EINPROGRESS) {
	    eventlog(eventlog_level_error,"init_virtconn","[%d] could not connect to server(psock_connect: %s)\n",virtconn_get_client_socket(vc),strerror(psock_errno()));
	    return -1;
	}
	    virtconn_set_state(vc,virtconn_state_connecting);
    }
    else virtconn_set_state(vc,virtconn_state_connected);
    
    return 0;
}



extern t_virtconn * virtconn_create(int csd, int ssd, unsigned int udpaddr, unsigned short udpport)
{
    t_virtconn * temp=NULL;
   
    if (csd<0)
    {
        eventlog(eventlog_level_error,"virtconn_create","got bad client socket");
        return NULL;
    }
    if (ssd<0)
    {
        eventlog(eventlog_level_error,"virtconn_create","got bad server socket");
        return NULL;
    }
   
    if (!(temp = malloc(sizeof(t_virtconn))))
    {
        eventlog(eventlog_level_error,"virtconn_create","could not allocate memory for temp");
        return NULL;
    }
   
    temp->csd                   = csd;
    temp->ssd                   = ssd;
    temp->udpport               = udpport;
    temp->udpaddr               = udpaddr;
    temp->class                 = virtconn_class_none;
    temp->state                 = virtconn_state_initial;
    temp->coutqueue             = NULL;
    temp->coutsize              = 0;
    temp->cinqueue              = NULL;
    temp->cinsize               = 0;
    temp->soutqueue             = NULL;
    temp->soutsize              = 0;
    temp->sinqueue              = NULL;
    temp->sinsize               = 0;
    temp->fileleft              = 0;
    temp->saveleft              = 0;
    temp->name			= NULL;
    temp->savedsize		= 0;
    temp->readedsize		= 0;
    temp->savefilesize	        = 0;
    temp->savefile		= NULL;
    temp->game			= NULL;
    temp->bound			= NULL;
    temp->quittime		= 0;
    
    if (list_prepend_data(virtconn_head,temp)<0)
    {
        free(temp);
        eventlog(eventlog_level_error,"virtconn_create","could not prepend temp");
        return NULL;
    }
    return temp;
}


extern void virtconn_destroy(t_virtconn * vc)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_destroy","got NULL virtconn");
        return;
    }
    if (list_remove_data(virtconn_head,vc)<0) {
            eventlog(eventlog_level_error,"virtconn_destroy","could not remove item from list");
	    return;
    }

    vc->state = virtconn_state_empty;

    if (vc->bound) {
	conn_set_virtbound(vc->bound,NULL);
	conn_set_game(vc->bound,NULL,NULL,NULL,game_type_none,0);
    }
    psock_shutdown(vc->csd,2);
    psock_shutdown(vc->ssd,1);

    psock_close(vc->csd);
    psock_close(vc->ssd);
    
    /* clear out the packet queues */
    if (vc->name)	free((void *)vc->name);
    if (vc->savefile)	free((void *)vc->savefile);

    queue_clear(&vc->sinqueue);
    queue_clear(&vc->soutqueue);
    queue_clear(&vc->cinqueue);
    queue_clear(&vc->coutqueue);
    
    eventlog(eventlog_level_info,"virtconn_destroy","[%d] closed server connection (%d) class=%d",vc->ssd,vc->csd,(int)vc->class);
    eventlog(eventlog_level_info,"virtconn_destroy","[%d] closed client connection (%d) class=%d",vc->csd,vc->ssd,(int)vc->class);
    
    free(vc);
}


extern t_virtconn_class virtconn_get_class(t_virtconn const * vc)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_get_class","got NULL virtconn");
        return virtconn_class_none;
    }

    return vc->class;
}


extern void virtconn_set_class(t_virtconn * vc, t_virtconn_class class)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_set_class","got NULL virtconn");
        return;
    }
    
    vc->class = class;
}


extern t_virtconn_state virtconn_get_state(t_virtconn const * vc)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"cvirtonn_set_state","got NULL virtconn");
        return virtconn_state_empty;
    }
    
    return vc->state;
}


extern void virtconn_set_state(t_virtconn * vc, t_virtconn_state state)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_set_state","got NULL virtconn");
        return;
    }
    
    vc->state = state;
}


extern unsigned int virtconn_get_udpaddr(t_virtconn const * vc)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_get_udpaddr","got NULL virtconn");
        return 0;
    }
    
    return vc->udpaddr;
}


extern unsigned short virtconn_get_udpport(t_virtconn const * vc)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_get_udpport","got NULL virtconn");
        return 0;
    }
    
    return vc->udpport;
}


extern t_queue * * virtconn_get_clientin_queue(t_virtconn * vc)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_get_clientin_queue","got NULL connection");
        return NULL;
    }

    return &vc->cinqueue;
}


extern int virtconn_get_clientin_size(t_virtconn const * vc)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_get_clientin_size","got NULL connection");
        return -1;
    }

    return vc->cinsize;
}


extern void virtconn_set_clientin_size(t_virtconn * vc, unsigned int size)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_set_clientin_size","got NULL connection");
        return;
    }

    vc->cinsize = size;
}


extern t_queue * * virtconn_get_clientout_queue(t_virtconn * vc)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_get_clientout_queue","got NULL connection");
        return NULL;
    }

    return &vc->coutqueue;
}


extern int virtconn_get_clientout_size(t_virtconn const * vc)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_get_clientout_size","got NULL connection");
        return -1;
    }

    return vc->coutsize;
}


extern void virtconn_set_clientout_size(t_virtconn * vc, unsigned int size)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_set_clientout_size","got NULL connection");
        return;
    }

    vc->coutsize = size;
}


extern int virtconn_get_client_socket(t_virtconn const * vc)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_get_client_socket","got NULL virtconn");
	return -1;
    }
    return vc->csd;
}


extern t_queue * * virtconn_get_serverin_queue(t_virtconn * vc)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_get_serverin_queue","got NULL connection");
        return NULL;
    }

    return &vc->sinqueue;
}


extern int virtconn_get_serverin_size(t_virtconn const * vc)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_get_serverin_size","got NULL connection");
        return -1;
    }

    return vc->sinsize;
}


extern void virtconn_set_serverin_size(t_virtconn * vc, unsigned int size)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_set_serverin_size","got NULL connection");
        return;
    }

    vc->sinsize = size;
}


extern t_queue * * virtconn_get_serverout_queue(t_virtconn * vc)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_get_serverout_queue","got NULL connection");
        return NULL;
    }

    return &vc->soutqueue;
}


extern int virtconn_get_serverout_size(t_virtconn const * vc)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_get_serverout_size","got NULL connection");
        return -1;
    }

    return vc->soutsize;
}


extern void virtconn_set_serverout_size(t_virtconn * vc, unsigned int size)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_set_serverout_size","got NULL connection");
        return;
    }

    vc->soutsize = size;
}


extern int virtconn_get_server_socket(t_virtconn const * vc)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_get_server_socket","got NULL virtconn");
	return -1;
    }
    return vc->ssd;
}


extern void virtconn_set_fileleft(t_virtconn * vc, unsigned int size)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_set_fileleft","got NULL virtconn");
	return;
    }
    vc->fileleft = size;
}


extern unsigned int virtconn_get_fileleft(t_virtconn const * vc)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_get_fileleft","got NULL virtconn");
	return -1;
    }
    return vc->fileleft;
}

extern t_list * virtconnlist(void)
{
  return virtconn_head;
}

extern int virtconnlist_create(void)
{
  if (!(virtconn_head = list_create())) return -1;
  else return 0;
}


extern int virtconnlist_destroy(void)
{
  if (list_destroy(virtconn_head)<0) return -1;
  else {
    virtconn_head = NULL;
    return 0;
  }
}

extern void virtconn_set_name(t_virtconn * vc,char const * name)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_set_name","got NULL virtconn");
        return;
    }
    if (!name)
    {
        eventlog(eventlog_level_error,"virtconn_set_name","got NULL name");
        return;
    }
    if (vc->name) {
	    free((void *)vc->name);
    }
    if (!(vc->name = strdup(name))) {
	eventlog(eventlog_level_error,"virtconn_set_name","could not allocate memory for vc->name");
    }
    return;
}

extern char const * virtconn_get_name(t_virtconn const * vc)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_get_name","got NULL virtconn");
        return NULL;
    }
    return vc->name;
}


extern void virtconn_set_savefilesize(t_virtconn * vc,unsigned int filesize)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_set_filesize","got NULL virtconn");
        return;
    }
    if (filesize==0)
    {
        eventlog(eventlog_level_error,"virtconn_set_savefilesize","got zero filesize");
    }
    vc->savefilesize=filesize;
}


extern unsigned int virtconn_get_savefilesize(t_virtconn * vc)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_get_savefilesize","got NULL virtconn");
        return 0;
    }    
    return vc->savefilesize;
}

extern void virtconn_set_savedsize(t_virtconn * vc, unsigned int size)
{
    if (!vc) {
        eventlog(eventlog_level_error,"virtconn_set_savedsize","got NULL connection");
        return;
    }

    vc->savedsize = size;
}

extern unsigned int virtconn_get_savedsize(t_virtconn * vc)
{
    if (!vc) {
        eventlog(eventlog_level_error,"virtconn_get_savedsize","got NULL connection");
        return 0;
    }

    return vc->savedsize;
}

extern void virtconn_add_savedsize(t_virtconn * vc, unsigned int size)
{
   if (!vc) {
       eventlog(eventlog_level_error,"virtconn_add_savedsize","got NULL connection");
       return;
   }
   vc->savedsize += size;
}

extern void virtconn_set_readedsize(t_virtconn * vc, unsigned int size)
{
    if (!vc) {
        eventlog(eventlog_level_error,"virtconn_set_readedsize","got NULL connection");
        return;
    }

    vc->readedsize = size;
}

extern unsigned int virtconn_get_readedsize(t_virtconn * vc)
{
    if (!vc) {
        eventlog(eventlog_level_error,"virtconn_get_readedsize","got NULL connection");
        return 0;
    }

    return vc->readedsize;
}

extern void virtconn_add_readedsize(t_virtconn * vc, unsigned int size)
{
   if (!vc) {
       eventlog(eventlog_level_error,"virtconn_add_readedsize","got NULL connection");
       return;
   }
   vc->readedsize += size;
}

extern void virtconn_set_savefile(t_virtconn * vc,char const * savefile)
{
   if (!vc) {
	eventlog(eventlog_level_error,"virtconn_set_savefile","got NULL connection");
	return;
    }
   if (!savefile)
   {
        eventlog(eventlog_level_error,"virtconn_set_savefile","got NULL savefile name");
        return;
   }
   if (vc->savefile) {
     free((void *)vc->savefile);
   }
   if (!(vc->savefile = strdup(savefile))) {
         eventlog(eventlog_level_error,"virtconn_set_name","could not allocate memory for vc->name");
   }
   return;
}

extern char * virtconn_get_savefile(t_virtconn const * vc)
{
    if (!vc) {
	eventlog(eventlog_level_error,"virtconn_get_savefile","got NULL connection");
	return NULL;
    }
    return vc->savefile;
}


extern void virtconn_set_game(t_virtconn * vc, t_game * game)
{
    if (!vc) {
	eventlog(eventlog_level_error,"virtconn_set_game","got NULL connection");
	return;
    }
    vc->game = game;
    return;
}

extern t_game * virtconn_get_game(t_virtconn const * vc)
{
    if (!vc) {
	eventlog(eventlog_level_error,"virtconn_get_game","got NULL connection");
	return NULL;
    }
    return vc->game;
}

extern void virtconn_bind(t_virtconn * vc, t_connection * c)
{
    if (!vc)
    {
	eventlog(eventlog_level_error,"virtconn_bind","got NULL virtconn");
	return;
    }
    vc->bound=c;
    return;
}

extern void virtconn_set_saveleft(t_virtconn * vc, unsigned int size)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_set_saveleft","got NULL virtconn");
	return;
    }
    vc->saveleft = size;
}


extern unsigned int virtconn_get_saveleft(t_virtconn const * vc)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_get_fileleft","got NULL virtconn");
	return -1;
    }
    return vc->saveleft;
}


extern time_t virtconn_get_quittime(t_virtconn const * vc)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_get_quittime","got NULL virtconn");
	return 0;
    }
    return vc->quittime;
}


extern void virtconn_set_quittime(t_virtconn * vc, time_t quittime)
{
    if (!vc)
    {
        eventlog(eventlog_level_error,"virtconn_get_quittime","got NULL virtconn");
	return;
    }
    vc->quittime=quittime;
    return;
}

extern void virtconn_autoquit(t_virtconn * vc)
{
    t_packet * tpacket; 
    if (virtconn_get_state(vc)==virtconn_state_in_game) {
        eventlog(eventlog_level_debug,"d2game_process","client disconnected without quit game,try use server autoquit to got save");
        tpacket=packet_create(packet_class_d2game);
        packet_set_size(tpacket,1);
        packet_set_type(tpacket,D2GAME_CLIENT_QUITGAME);
        queue_push_packet(virtconn_get_serverout_queue(vc), tpacket);
        packet_del_ref(tpacket);
        virtconn_set_state(vc,virtconn_state_quitting);
    }
    return;
}
