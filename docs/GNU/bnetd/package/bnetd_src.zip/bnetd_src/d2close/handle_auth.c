/*
 * Copyright (C) 2000  Ross Combs (rocombs@cs.nmsu.edu)
 * Copyright (C) 2000  Onlyer (onlyer@263.net)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#include "config.h"
#include "setup.h"

#define USE_STDDEF_HEADERS
#define USE_STDC_HEADERS
#define USE_STRING_HEADERS
#define USE_SOCKET_HEADERS

#include "compat.h"

#include "prefs.h"
#include "game.h"
#include "packet.h"
#include "eventlog.h"
#include "account.h"
#include "connection.h"
#include "queue.h"
#include "bnethash.h"
#include "bnethashconv.h"
#include "bn_type.h"
#include "field_sizes.h"
#include "handle_auth.h"
#include "d2charfile.h"
#include "addr.h"
#include "d2server.h"
#include "d2game.h"
#include "d2ladder.h"


extern int handle_auth_packet(t_connection * c, t_packet const * const packet)
{
    t_packet * rpacket=NULL;
    
    if (!c)
    {
	eventlog(eventlog_level_error,"handle_auth_packet","[%d] got NULL connection",conn_get_socket(c));
	return -1;
    }
    if (!packet)
    {
	eventlog(eventlog_level_error,"handle_auth_packet","[%d] got NULL packet",conn_get_socket(c));
	return -1;
    }
    if (packet_get_class(packet)!=packet_class_auth)
    {
	eventlog(eventlog_level_error,"handle_auth_packet","[%d] got bad packet (class %d)",conn_get_socket(c),(int)packet_get_class(packet));
	return -1;
    }
    
    switch (conn_get_state(c))
    {
    case conn_state_connected:
	switch (packet_get_type(packet))
	{
	case CLIENT_AUTHLOGINREQ:
	    if (packet_get_size(packet)<sizeof(t_client_authloginreq))
	    {
		eventlog(eventlog_level_error,"handle_auth_packet","[%d] got bad AUTHLOGINREQ packet (expected %u bytes, got %u)",conn_get_socket(c),sizeof(t_client_authloginreq),packet_get_size(packet));
		break;
	    }
	    
	    {
		char const   * charname;
		t_connection * normalcon;
		unsigned int   reply;
		
		if (!(charname = packet_get_str_const(packet,sizeof(t_client_authloginreq),CHAR_NAME_LEN)))
		{
		    eventlog(eventlog_level_error,"handle_auth_packet","[%d] got bad AUTHLOGINREQ packet (missing or too long charname)",conn_get_socket(c));
		    break;
		}
		eventlog(eventlog_level_debug,"handle_auth_packet","[%d] Charname = \"%s\"",conn_get_socket(c),charname);
		
		if (!(normalcon = connlist_find_connection_by_sessionkey(bn_int_get(packet->u.client_authloginreq.sessionkey))))
		{
		    eventlog(eventlog_level_info,"handle_auth_packet","[%d] auth login for \"%s\" refused (bad session key %u)",conn_get_socket(c),charname,bn_int_get(packet->u.client_authloginreq.sessionkey));
		    reply = SERVER_AUTHLOGINREPLY_REPLY_BADPASS;
		}
		else
		{
		    unsigned int   salt;
		    struct
		    {
			bn_int     salt;
			bn_int     sessionkey;
			bn_int     sessionnum;
			bn_int     secret;
		    } temp;
		    t_hash         secret_hash;
		    t_hash         try_hash;
		    
		    salt = bn_int_get(packet->u.client_authloginreq.unknown6);
		    bn_int_set(&temp.salt,salt);
		    bn_int_set(&temp.sessionkey,conn_get_sessionkey(normalcon));
		    bn_int_set(&temp.sessionnum,conn_get_sessionnum(normalcon));
		    bn_int_set(&temp.secret,conn_get_secret(normalcon));
		    bnet_hash(&secret_hash,sizeof(temp),&temp);
		    
		    bnhash_to_hash(packet->u.client_authloginreq.secret_hash,&try_hash);
		    
/* _bucky_ FIXME: Accept password no matter what for now */
#if 0
		    if (hash_eq(try_hash,secret_hash)!=1)
		    {
			eventlog(eventlog_level_info,"handle_auth_packet","[%d] auth login for \"%s\" refused (bad password)",conn_get_socket(c),charname);
/* _bucky_ FIXED */     reply = SERVER_AUTHLOGINREPLY_REPLY_BADPASS;
		    }
		    else
#endif
		    {
			eventlog(eventlog_level_info,"handle_auth_packet","[%d] auth login for \"%s\" accepted (correct password)",conn_get_socket(c),charname);
/* _bucky_ FIXED */     reply = SERVER_AUTHLOGINREPLY_REPLY_SUCCESS;
/*
			conn_set_charname(c,charname);
*/
			conn_bind(c,normalcon);

/* _bucky_ ADD */       conn_set_state(c,conn_state_loggedin);
			conn_set_clienttag(c,"D2DV");
		    }
		}
		
		if ((rpacket = packet_create(packet_class_auth)))
		{
		    packet_set_size(rpacket,sizeof(t_server_authloginreply));
		    packet_set_type(rpacket,SERVER_AUTHLOGINREPLY);
		    bn_int_set(&rpacket->u.server_authloginreply.reply,reply);
		    queue_push_packet(conn_get_out_queue(c),rpacket);
		    packet_del_ref(rpacket);
		}
	    }
	    break;
	    
	default:
	    eventlog(eventlog_level_error,"handle_auth_packet","[%d] unknown (unlogged in) auth packet type 0x%02hx, len %u",conn_get_socket(c),packet_get_type(packet),packet_get_size(packet));
	}
	break;
	
    case conn_state_loggedin:
	switch (packet_get_type(packet))
	{
	case CLIENT_DELCHARREQ: 
	    if (packet_get_size(packet)<sizeof(t_client_delcharreq))
	    {
		eventlog(eventlog_level_error,"handle_auth_packet","[%d] got bad DELCHARREQ packet (expected %u bytes, got %u)",conn_get_socket(c),sizeof(t_client_delcharreq),packet_get_size(packet));
		break;
	    }
	    {
		unsigned int reply;
		char const * charname;
		
		charname=conn_get_charname(c);
		if (!charname) {
		eventlog(eventlog_level_error,"handle_auth_packet","got NULL charname from CLIENT_DELCHARREQ");
		break;
		}
		if (d2char_delchar(conn_get_account(c),charname,0)<0) {
		    eventlog(eventlog_level_error,"handle_auth_packet","del char %s failed",charname);
		    reply = SERVER_DELCHARREPLY_ERROR;
		}
		else reply = SERVER_DELCHARREPLY_SUCCESS;
		if ((rpacket = packet_create(packet_class_auth)))
		{
		    packet_set_size(rpacket,sizeof(t_server_delcharreply));
		    packet_set_type(rpacket,SERVER_DELCHARREPLY);
		    bn_int_set(&rpacket->u.server_delcharreply.reply,reply);
		    queue_push_packet(conn_get_out_queue(c),rpacket);
		    packet_del_ref(rpacket);
		}
	    }
	    break;
	    
	case CLIENT_CREATECHARREQ:
	    if (packet_get_size(packet)<sizeof(t_client_createcharreq))
	    {
		eventlog(eventlog_level_error,"handle_auth_packet","[%d] got bad CREATECHARREQ packet (expected %u bytes, got %u)",conn_get_socket(c),sizeof(t_client_createcharreq),packet_get_size(packet));
		break;
	    }
	    
	    {
		unsigned int reply;
		char const * charname;
		unsigned short class;
		unsigned int charnum;
		unsigned int type;

		charname=packet_get_str_const(packet,sizeof(t_client_createcharreq),CHAR_NAME_LEN);
		if (!charname) {
		    eventlog(eventlog_level_error,"handle_auth_packet","got NULL charname from CLIENT_CREATECHARREQ");
		    break;
		}

		charnum=d2char_getnumber(conn_get_account(c));

		class=bn_short_get(packet->u.client_createcharreq.class);
		type=bn_short_get(packet->u.client_createcharreq.type);
		
		switch (class)
		{
		case CLIENT_CREATECHARREQ_CLASS_AMAZON:
		    reply = SERVER_CREATECHARREPLY_REPLY_SUCCESS;
		    break;
		case CLIENT_CREATECHARREQ_CLASS_SORCERESS:
		    reply = SERVER_CREATECHARREPLY_REPLY_SUCCESS;
		    break;
		case CLIENT_CREATECHARREQ_CLASS_NECRO:
		    reply = SERVER_CREATECHARREPLY_REPLY_SUCCESS;
		    break;
		case CLIENT_CREATECHARREQ_CLASS_PALADIN:
		    reply = SERVER_CREATECHARREPLY_REPLY_SUCCESS;
		    break;
		case CLIENT_CREATECHARREQ_CLASS_BARBARIAN:
		    reply = SERVER_CREATECHARREPLY_REPLY_SUCCESS;
		    break;
		default:
		    eventlog(eventlog_level_error,"handle_auth_packet","[%d] got unknown character class %u",conn_get_socket(c),bn_short_get(packet->u.client_createcharreq.class));
		    reply = SERVER_CREATECHARREPLY_REPLY_ERROR;
		}
		if (charnum>=prefs_get_realmcharmax()) {
		    eventlog(eventlog_level_error,"handle_auth_packet","char not create because max realmchar reached");
		    reply = SERVER_CREATECHARREPLY_REPLY_ERROR;
		} 
		else if (reply != SERVER_CREATECHARREPLY_REPLY_ERROR && \
		    d2char_addchar(conn_get_account(c),charname,class,type)<0) {
		    eventlog(eventlog_level_error,"handle_auth_packet","create char %s failed",charname);
		    reply = SERVER_CREATECHARREPLY_REPLY_ERROR;
		}
		else conn_set_charname(c,charname);

		if ((rpacket = packet_create(packet_class_auth)))
		{
		    packet_set_size(rpacket,sizeof(t_server_createcharreply));
		    packet_set_type(rpacket,SERVER_CREATECHARREPLY);
		    bn_int_set(&rpacket->u.server_createcharreply.reply,reply);
		    queue_push_packet(conn_get_out_queue(c),rpacket);
		    packet_del_ref(rpacket);
		}
	    }
	    break;
	    
	case CLIENT_CREATEGAMEREQ:
	    if (packet_get_size(packet)<sizeof(t_client_creategamereq))
	    {
		eventlog(eventlog_level_error,"handle_auth_packet","[%d] got bad CREATEGAMEREQ packet (expected %u bytes, got %u)",conn_get_socket(c),sizeof(t_client_creategamereq),packet_get_size(packet));
		break;
	    }
	    
	    {
		char const * gamename;
		char const * gamepass;
		char const * gameinfo;
		t_game	   * currgame=NULL;
		unsigned int difficulty;
		unsigned int leveldiff;
		unsigned int maxchar;
		int	     reply;
		unsigned int serv_id;
		t_addr	   * servaddr;

		unsigned int token;
		unsigned int hardcore;

		if (!(gamename = packet_get_str_const(packet,sizeof(t_client_creategamereq),GAME_NAME_LEN)))
		{   
		    eventlog(eventlog_level_error,"handle_auth_packet","[%d] got bad CREATEGAME packet( bad game name)",conn_get_socket(c));
		    break;
		}
		if (!(gamepass = packet_get_str_const(packet,sizeof(t_client_creategamereq)+strlen(gamename)+1,GAME_PASS_LEN)))
		{
	            eventlog(eventlog_level_error,"handle_auth_packet","[%d] got bad CREATEGAME packet (missing or too long gamepass)",conn_get_socket(c));
		    break;
		}
		if (!(gameinfo = packet_get_str_const(packet,sizeof(t_client_creategamereq)+strlen(gamename)+1+strlen(gamepass)+1,GAME_INFO_LEN)))
		{
		    eventlog(eventlog_level_error,"handle_auth_packet","[%d] got bad CREATEGAME packet (missing or too long gameinfo)",conn_get_socket(c));
		    break;
		}
		difficulty  = bn_byte_get(packet->u.client_creategamereq.difficulty);
		leveldiff   = bn_byte_get(packet->u.client_creategamereq.leveldiff);
		maxchar	    = bn_byte_get(packet->u.client_creategamereq.maxchar);
		hardcore    = d2char_gethardcore(conn_get_charname(c));
		if (hardcore==2) hardcore=0;
		eventlog(eventlog_level_debug,"handle_auth_packet","[%d] got creategame request  for game \"%s\",pass \"%s\"(leveldiff:%02x maxchar:%02x difficulty:%02x",conn_get_socket(c),gamename,gamepass,leveldiff,maxchar,difficulty);
		if (hardcore==3 || !prefs_allow_d2game() ) {
		    reply = SERVER_CREATEGAMEREPLY_REPLY_DISABLE;
		}
		else if (!(servaddr=d2servlist_choose_server())) {
		    reply = SERVER_CREATEGAMEREPLY_REPLY_DISABLE;
		}
		else {
		    if ((currgame=conn_get_game(c))) {
			    eventlog(eventlog_level_error,"handle_auth_packet","char %s already in game %s.no new game create",conn_get_charname(c),gamename);
			    reply = SERVER_CREATEGAMEREPLY_REPLY_ERROR;
		    }
		    else {
			if ((currgame=game_create(gamename,gamepass,gameinfo,game_type_d2realm,GAME_VERSION_D2REALM,conn_get_clienttag(c))))	{ 
			    reply = SERVER_CREATEGAMEREPLY_REPLY_OK;

			    token=d2server_get_token(servaddr);
			    serv_id=d2server_get_id(servaddr);

			    do { 
				token++;
			    } while (game_set_token(currgame,token)<0);
			    d2server_set_gamenum(servaddr,d2server_get_gamenum(servaddr)+1);
			    d2server_set_token(servaddr,token);
			    game_set_newgame(currgame,1);
			    game_set_created(currgame,0);
			    game_set_d2servid(currgame,serv_id);
			    game_set_leveldiff(currgame,leveldiff);
			    game_set_level(currgame,d2char_getlevel(conn_get_charname(c)));
			    game_set_maxplayers(currgame,maxchar);
			    game_set_difficulty(currgame,difficulty);
			    if (hardcore==1) game_set_hardcore(currgame,1);
			    game_set_realm(currgame,1);
			}
			else reply = SERVER_CREATEGAMEREPLY_REPLY_NAME_EXIST;
		    }
	      }
	    
	    /* FIXME: actually create game */
	    if ((rpacket = packet_create(packet_class_auth)))
	    {
		packet_set_size(rpacket,sizeof(t_server_creategamereply));
		packet_set_type(rpacket,SERVER_CREATEGAMEREPLY);
		bn_short_set(&rpacket->u.server_creategamereply.seqno,bn_short_get(packet->u.client_creategamereq.seqno));
		if (!currgame) bn_int_set(&rpacket->u.server_creategamereply.token,0);
		else bn_int_set(&rpacket->u.server_creategamereply.token,game_get_id(currgame));
		bn_int_set(&rpacket->u.server_creategamereply.reply,reply);
		queue_push_packet(conn_get_out_queue(c),rpacket);
		packet_del_ref(rpacket);
	    }
	    }
	    break;
	    
	case CLIENT_JOINGAMEREQ2:
	    if (packet_get_size(packet)<sizeof(t_client_joingamereq2))
	    {
		eventlog(eventlog_level_error,"handle_auth_packet","[%d] got bad JOINGAMEREQ2 packet (expected %u bytes, got %u)",conn_get_socket(c),sizeof(t_client_joingamereq2),packet_get_size(packet));
		break;
	    }
            {
		char const * gamename;
		char const * gamepass;
		t_game *     game;
		int	     reply;
		char const * charname;
		unsigned int hardcore;
		
		if (!(gamename = packet_get_str_const(packet,sizeof(t_client_joingamereq2),GAME_NAME_LEN)))
		{
		    eventlog(eventlog_level_error,"handle_auth_packet","[%d] got bad CLIENT_JOINGAMEREQ2 (missing or too long gamename)",conn_get_socket(c));
		    break;
		}
		if (!(gamepass = packet_get_str_const(packet,sizeof(t_client_joingamereq2)+strlen(gamename)+1,GAME_PASS_LEN)))
		{
		    eventlog(eventlog_level_error,"handle_auth_packet","[%d] got bad CLIENT_JOINGAMEREQ2 packet (missing or too long gamepass)",conn_get_socket(c));
		    break;
		}
		if (!(charname = conn_get_charname(c))) {
		    eventlog(eventlog_level_error,"handle_auth_packet","got NULL charname when client tried to join game");
		    break;
		}
		hardcore = d2char_gethardcore(charname);
		if (hardcore==2) hardcore=0;
		    eventlog(eventlog_level_debug,"handle_auth_packet","[%d] trying to join game \"%s\" pass=\"%s\"",conn_get_socket(c),gamename,gamepass);
		if (!(game = gamelist_find_game(gamename,game_type_d2realm)))
		{
		    eventlog(eventlog_level_error,"handle_auth_packet","[%d] unable to find game \"%s\" for user to join",conn_get_socket(c),gamename);
		    reply = SERVER_JOINGAMEREPLY2_REPLY_NOT_EXIST;
		}
		else if ( game_get_maxplayers(game)<=game_get_ref(game)) {
		    eventlog(eventlog_level_debug,"handle_auth_packet","can not join game for game is full (%d/%d)",game_get_ref(game),game_get_maxplayers(game));
		    reply=SERVER_JOINGAMEREPLY2_REPLY_GAME_FULL;
		}
		else if ( game_get_difficulty(game)>d2char_gettitle(charname)) {
		    eventlog(eventlog_level_debug,"handle_auth_packet","can not join game for difficulty mismatch (%d/%d)",d2char_gettitle(charname),game_get_difficulty(game));
		    reply=SERVER_JOINGAMEREPLY2_REPLY_LEVEL_LIMIT;
		}
		else if ( d2char_getlevel(charname)>game_get_maxlevel(game)) {
		    eventlog(eventlog_level_debug,"handle_auth_packet","can not join game for max level mismatch (%d/%d)",d2char_getlevel(charname),game_get_maxlevel(game));
		    reply=SERVER_JOINGAMEREPLY2_REPLY_LEVEL_LIMIT;
		}
		else if (d2char_getlevel(charname)<game_get_minlevel(game)) {
		    eventlog(eventlog_level_debug,"handle_auth_packet","can not join game for min level mismatch (%d/%d)",d2char_getlevel(charname),game_get_minlevel(game));
		    reply=SERVER_JOINGAMEREPLY2_REPLY_LEVEL_LIMIT;
		}
		else if (game_get_hardcore(game)!=hardcore) {
		    eventlog(eventlog_level_debug,"handle_auth_packet","can not join game for hardcore mismatch (%d/%d)",hardcore,game_get_hardcore(game));
		    reply=SERVER_JOINGAMEREPLY2_REPLY_LEVEL_LIMIT;
		}
		else { 
		    gamename = game_get_name(game);
		    if (conn_set_game(c,gamename,gamepass,"",game_type_d2realm,GAME_VERSION_UNKNOWN)<0)
		    {
			eventlog(eventlog_level_debug,"handle_auth_packet","could not join game %s",gamename);
			reply = SERVER_JOINGAMEREPLY2_REPLY_ERROR;
		    }
		    else {
			reply = SERVER_JOINGAMEREPLY2_REPLY_OK;
		    }
		}

		if ((rpacket = packet_create(packet_class_auth)))
	        {
		    packet_set_size(rpacket,sizeof(t_server_joingamereply2));
		    packet_set_type(rpacket,SERVER_JOINGAMEREPLY2);
		    bn_short_set(&rpacket->u.server_joingamereply2.seqno,bn_short_get(packet->u.client_joingamereq2.seqno));
		    bn_int_set(&rpacket->u.server_joingamereply2.unknown2,SERVER_JOINGAMEREPLY2_UNKNOWN2);
		    if ( reply == SERVER_JOINGAMEREPLY2_REPLY_OK ) {
		    bn_int_set(&rpacket->u.server_joingamereply2.addr,inet_addr(prefs_get_d2game_lservaddr()));
		    bn_int_set(&rpacket->u.server_joingamereply2.token,game_get_id(game));
		    }
		    else {
		    bn_int_set(&rpacket->u.server_joingamereply2.addr,0);
		    bn_int_set(&rpacket->u.server_joingamereply2.token,0);
		    }
		    bn_int_set(&rpacket->u.server_joingamereply2.reply,reply);
		    queue_push_packet(conn_get_out_queue(c),rpacket);
		    packet_del_ref(rpacket);
		}
	    }
	    break;
	    
	case CLIENT_D2GAMELISTREQ:
	    if (packet_get_size(packet)<sizeof(t_client_d2gamelistreq))
	    {
		eventlog(eventlog_level_error,"handle_auth_packet","[%d] got bad GAMELISTREQ packet (expected %u bytes, got %u)",conn_get_socket(c),sizeof(t_client_d2gamelistreq),packet_get_size(packet));
		break;
	    }
	    
	    {
		t_game * game;
		char const * charname;
		unsigned int hardcore;
		t_elem const * elem;
		
		if (!(charname = conn_get_charname(c))) {
		    eventlog(eventlog_level_error,"handle_auth_packet","got NULL charname when GAMELIST");
		    break;
		}
		hardcore=d2char_gethardcore(charname);
		if (hardcore==2) hardcore=0;
		LIST_TRAVERSE_DATA(gamelist(),elem,game)
		{
		    if (game_get_realm(game)!=1) continue;
		    if (strcmp(game_get_pass(game),"")!=0) continue;
		    if (game_get_maxplayers(game)<=game_get_ref(game)) continue;
		    if (game_get_difficulty(game)>d2char_gettitle(charname)) continue;
		    if (hardcore!=game_get_hardcore(game)) continue;
		    if (d2char_getlevel(charname)>game_get_maxlevel(game) ||
			d2char_getlevel(charname)<game_get_minlevel(game))
		    continue;
		    if ((rpacket = packet_create(packet_class_auth)))
		    {
		      packet_set_size(rpacket,sizeof(t_server_d2gamelistreply));
		      packet_set_type(rpacket,SERVER_D2GAMELISTREPLY);
		      bn_short_set(&rpacket->u.server_d2gamelistreply.seqno,bn_byte_get(packet->u.client_d2gamelistreq.seqno));
		      bn_int_set(&rpacket->u.server_d2gamelistreply.token,game_get_id(game));
		      bn_byte_set(&rpacket->u.server_d2gamelistreply.currchar,(unsigned char)game_get_ref(game));
		      bn_int_set(&rpacket->u.server_d2gamelistreply.unknown1,SERVER_D2GAMELISTREPLY_UNKNOWN1);
		      packet_append_string(rpacket,game_get_name(game)); /* game name */
		      packet_append_string(rpacket,""); /* game desc */
		      queue_push_packet(conn_get_out_queue(c),rpacket);
		      packet_del_ref(rpacket);
		    }
		}
	    }
	    if ((rpacket = packet_create(packet_class_auth)))
	    {
		packet_set_size(rpacket,sizeof(t_server_d2gamelistreply));
		packet_set_type(rpacket,SERVER_D2GAMELISTREPLY);
		bn_short_set(&rpacket->u.server_d2gamelistreply.seqno,bn_byte_get(packet->u.client_d2gamelistreq.seqno));
		bn_int_set(&rpacket->u.server_d2gamelistreply.token,0);
		bn_byte_set(&rpacket->u.server_d2gamelistreply.currchar,0);
		bn_int_set(&rpacket->u.server_d2gamelistreply.unknown1,SERVER_D2GAMELISTREPLY_UNKNOWN1_END);
		packet_append_string(rpacket,"");
		packet_append_string(rpacket,"");
		packet_append_string(rpacket,"");
		queue_push_packet(conn_get_out_queue(c),rpacket);
		packet_del_ref(rpacket);
	    }
	    break;
	    
	case CLIENT_GAMEINFOREQ:
	    if (packet_get_size(packet)<sizeof(t_client_gameinforeq))
	    {
		eventlog(eventlog_level_error,"handle_auth_packet","[%d] got bad GAMEINFOREQ packet (expected %u bytes, got %u)",conn_get_socket(c),sizeof(t_client_gameinforeq),packet_get_size(packet));
		break;
	    }
	    
	    {
		t_game * game;
		char const * gamename; 
		t_connection * * connections;
		char const * charname;
		unsigned int i,count;

	    if (!(gamename=packet_get_str_const(packet,sizeof(t_client_gameinforeq),GAME_NAME_LEN))) {
		eventlog(eventlog_level_error,"handle_auth_packet","got bad gamename");
		break;
	    }
	    if (gamename[0]=='\0') break;
	    if ((game=gamelist_find_game(gamename,game_type_d2realm)))
	    {
		if ((rpacket = packet_create(packet_class_auth)))
		{
		packet_set_size(rpacket,sizeof(t_server_gameinforeply));
		packet_set_type(rpacket,SERVER_GAMEINFOREPLY);
		bn_short_set(&rpacket->u.server_gameinforeply.seqno,(unsigned short)bn_int_get(packet->u.client_gameinforeq.seqno));
		bn_int_set(&rpacket->u.server_gameinforeply.token,game_get_id(game));
		bn_int_set(&rpacket->u.server_gameinforeply.etime,time(NULL)-game_get_create_time(game));
		bn_byte_set(&rpacket->u.server_gameinforeply.unknown1,0);

		bn_byte_set(&rpacket->u.server_gameinforeply.currchar,(unsigned char)game_get_ref(game));
		bn_byte_set(&rpacket->u.server_gameinforeply.leveldiff,(unsigned char)game_get_leveldiff(game));
		bn_byte_set(&rpacket->u.server_gameinforeply.maxchar,(unsigned char)game_get_maxplayers(game));
		bn_byte_set(&rpacket->u.server_gameinforeply.gamelevel,(unsigned char)game_get_level(game));
		connections=game_get_connections(game);

		for (i=0,count=0;i<game_get_count(game);i++)
		{
		    if (!connections[i]) {
			continue;
		    }
		    count++;
		    if (count>game_get_ref(game)) {
			eventlog(eventlog_level_error,"handle_auth_packet","players in game not match ref");
			break;
		    }
                    if (!(charname=conn_get_charname(connections[i]))) {
			eventlog(eventlog_level_debug,"handle_auth_packet","got NULL char name on connections %d of game %s",i,game_get_name(game));
			continue;
		    }
		    bn_byte_set(&rpacket->u.server_gameinforeply.level[count-1],(unsigned char)d2char_getlevel(charname));
		    bn_byte_set(&rpacket->u.server_gameinforeply.class[count-1],(unsigned char)d2char_getclass(charname));
		    packet_append_string(rpacket,charname);
		}
		queue_push_packet(conn_get_out_queue(c),rpacket);
		packet_del_ref(rpacket);
		}
	    }
	    }
	    break;
	    
	case CLIENT_CHARNAMEREQ:
	    if (packet_get_size(packet)<sizeof(t_client_charnamereq))
	    {
		eventlog(eventlog_level_error,"handle_auth_packet","[%d] got bad CHARNAMEREQ packet (expected %u bytes, got %u)",conn_get_socket(c),sizeof(t_client_charnamereq),packet_get_size(packet));
		break;
	    }

	    {	
		char const * charname;
		unsigned int reply;

		charname=packet_get_str_const(packet,sizeof(t_client_charnamereq),CHAR_NAME_LEN);
		if (!charname) {
		    eventlog(eventlog_level_error,"handle_auth_packet","got NULL charname");
		    break;
		}
		if (d2char_findcharfile(charname)!=1) {
		    eventlog(eventlog_level_error,"handle_auth_packet","char login for %s rejected(not such a player",charname);
		    conn_destroy(c);
		    break;
		    /*
		    reply=SERVER_CHARNAMEREPLY_ERROR;
		    */
		}
		else {
		    eventlog(eventlog_level_error,"handle_auth_packet","char login for %s accepted",charname);
		    conn_set_charname(c,charname);
		    reply=SERVER_CHARNAMEREPLY_SUCCESS;
		}
	    
	    if ((rpacket = packet_create(packet_class_auth)))
	    {
		packet_set_size(rpacket,sizeof(t_server_charnamereply));
		packet_set_type(rpacket,SERVER_CHARNAMEREPLY);
		bn_int_set(&rpacket->u.server_charnamereply.reply,reply);
		queue_push_packet(conn_get_out_queue(c),rpacket);
		packet_del_ref(rpacket);
	    }
	    }
	    break;
	    
	case CLIENT_LADDERINFOREQ:
	    if (packet_get_size(packet)<sizeof(t_client_ladderinforeq))
	    {
		eventlog(eventlog_level_error,"handle_auth_packet","[%d] got bad LADDERINFOREQ packet (expected %u bytes, got %u)",conn_get_socket(c),sizeof(t_client_ladderinforeq),packet_get_size(packet));
		break;
	    }
	    {
		unsigned int type,class,hardcore;
		unsigned int count;
		unsigned int total_len,cont_len,len;
		t_d2ladder * d2ladder;
		t_d2ladder_info * d2ladderinfo;
		t_server_ladderinfo_entry * data;

		type=bn_byte_get(packet->u.client_ladderinforeq.type);
                d2ladder=d2ladderlist_find_type(type);
		if (!d2ladder) {
		    eventlog(eventlog_level_error,"handle_auth_packet","could not find d2ladder for type %d",type);
		    break;
		}

		total_len=d2ladder->len*sizeof(t_server_ladderinfo_entry)+8;
		cont_len=0;

		for (count=0;count<d2ladder->len;count++)
	        {
		    d2ladderinfo=&(d2ladder->info[count]);
		    if (count%D2LADDER_PACKET_LEN==0) {
			if (count!=0) {
			    cont_len+=len;
			    queue_push_packet(conn_get_out_queue(c),rpacket);
			    packet_del_ref(rpacket);
			}
			if ((rpacket = packet_create(packet_class_auth)))
			{
			    len=(((d2ladder->len-count)/D2LADDER_PACKET_LEN)?D2LADDER_PACKET_LEN:(d2ladder->len-count))*sizeof(t_server_ladderinfo_entry);
			    packet_set_size(rpacket,sizeof(t_server_ladderinforeply));
			    packet_set_type(rpacket,SERVER_LADDERINFOREPLY);
			    if (count==0) {
				bn_int_set(&rpacket->u.server_ladderinforeply.total_count,d2ladder->len);
				bn_int_set(&rpacket->u.server_ladderinforeply.unknown3,SERVER_LADDERINFOREPLY_UNKNOWN3);
				len+=8;
			    }
			    else {
				packet_set_size(rpacket,10);
			    }
			    bn_byte_set(&rpacket->u.server_ladderinforeply.type,(unsigned char)type);
			    bn_short_set(&rpacket->u.server_ladderinforeply.total_len,(unsigned short)total_len);
			    bn_short_set(&rpacket->u.server_ladderinforeply.len,(unsigned short)len);
			    bn_short_set(&rpacket->u.server_ladderinforeply.cont_len,(unsigned short)cont_len);
			}
			else {
			    eventlog(eventlog_level_error,"handle_auth_packet","could not allocate rpacket");
			    break;
			}
		    }
		    if (!(data=malloc(sizeof(t_server_ladderinfo_entry)))) {
			eventlog(eventlog_level_error,"handle_auth_packet","could not allocate data");
			break;
		    }
		    hardcore=((d2ladderinfo->status)&0xf)/4;
		    if (hardcore==1) hardcore=0x20;
		    else if (hardcore==3) hardcore=0x30;
		    else hardcore=0;
		    class=(d2ladderinfo->class&0xf)-1+hardcore;
		    bn_int_set(&data->exp,d2ladderinfo->exp);
		    bn_int_set(&data->unknown1,0);
		    bn_byte_set(&data->class,(unsigned char)class);
		    bn_byte_set(&data->title,(unsigned char)((d2ladderinfo->title&0x1f)/2));
		    bn_byte_set(&data->level,(unsigned char)d2ladderinfo->level);
		    strncpy(data->charname,d2ladderinfo->charname,CHAR_NAME_LEN);
		    packet_append_data(rpacket,data,sizeof(t_server_ladderinfo_entry));
		    free(data);
		}
		if (rpacket) {
		    queue_push_packet(conn_get_out_queue(c),rpacket);
		    packet_del_ref(rpacket);
		}
	    }
	    break;
	
	case CLIENT_AUTHMOTDREQ:
	    if (packet_get_size(packet)<sizeof(t_client_authmotdreq)) 
	    {
		eventlog(eventlog_level_error,"handle_auth_packet","[%d] got bad AUTHMOTDREQ packet (expected %u bytes, got %u)",conn_get_socket(c),sizeof(t_client_authmotdreq),packet_get_size(packet));
		break;
	    }
	    if ((rpacket = packet_create(packet_class_auth)))
	    {
		packet_set_size(rpacket,sizeof(t_server_authmotdreply));
		packet_set_type(rpacket,SERVER_AUTHMOTDREPLY);
		bn_byte_set(&rpacket->u.server_authmotdreply.unknown1,SERVER_AUTHMOTDREPLY_UNKNOWN1);
		packet_append_string(rpacket,prefs_get_authmotd());
		queue_push_packet(conn_get_out_queue(c),rpacket);
		packet_del_ref(rpacket);
	    }
	    break;
			
	default:
	    eventlog(eventlog_level_error,"handle_auth_packet","[%d] unknown (logged in) auth packet type 0x%02hx, len %u",conn_get_socket(c),packet_get_type(packet),packet_get_size(packet));
	}
	break;
	
    default:
	eventlog(eventlog_level_error,"handle_auth_packet","[%d] unknown auth connection state %d",conn_get_socket(c),(int)conn_get_state(c));
    }
    
    return 0;
}



