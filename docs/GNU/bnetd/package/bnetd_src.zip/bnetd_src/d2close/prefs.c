/*
 * Copyright (C) 1998,1999,2000  Ross Combs (rocombs@cs.nmsu.edu)
 * Copyright (C) 1999  Rob Crittenden (rcrit@greyoak.com)
 * Copyright (C) 1999  Mark Baysinger (mbaysing@ucsd.edu)
 * Copyright (C) 2000  Onlyer (onlyer@263.net)
 * Some BITS modifications:
 *          Copyright (C) 1999,2000  Marco Ziech (mmz@gmx.net)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#define PREFS_INTERNAL_ACCESS
#include "config.h"
#include "setup.h"
#include <stdio.h>
#include <errno.h>
#include <ctype.h>

#define USE_STDDEF_HEADERS
#define USE_STDC_HEADERS
#define USE_STRING_HEADERS

#include "compat.h"

#include "compat/strdup.h"
#include "compat/strcasecmp.h"
#include "compat/strerror.h"
#include "util.h"
#include "eventlog.h"
#include "prefs.h"


static int processDirective(char const * directive, char const * value, unsigned int curLine);
static char const * get_char_conf(char const * directive);
static unsigned int get_int_conf(char const * directive);
static int get_bool_conf(char const * directive);


#define NONE 0

/*    directive             type               defcharval           defintval         actual */
static Bconf_t conf_table[] =
{
    { "filedir",            conf_type_char,    BNETD_FILE_DIR,       NONE,                NULL, 0 },
    { "logfile",            conf_type_char,    BNETD_LOG_FILE,       NONE,                NULL, 0 },
    { "userdir",            conf_type_char,    BNETD_USER_DIR,       NONE,                NULL, 0 },
    { "loglevels",          conf_type_char,    BNETD_LOG_LEVELS,     NONE,                NULL, 0 },
    { "defacct",            conf_type_char,    BNETD_TEMPLATE_FILE,  NONE,                NULL, 0 },
    { "motdfile",           conf_type_char,    BNETD_MOTD_FILE,      NONE,                NULL, 0 },
    { "newsfile",           conf_type_char,    BNETD_NEWS_DIR,       NONE,                NULL, 0 },
    { "channelfile",        conf_type_char,    BNETD_CHANNEL_FILE,   NONE,                NULL, 0 },
    { "pidfile",            conf_type_char,    BNETD_PID_FILE,       NONE,                NULL, 0 },
    { "adfile",             conf_type_char,    BNETD_AD_FILE,        NONE,                NULL, 0 },
    { "usersync",           conf_type_int,     NULL,                 BNETD_USERSYNC,      NULL, 0 },
    { "userflush",          conf_type_int,     NULL,                 BNETD_USERFLUSH,     NULL, 0 },
    { "track",              conf_type_int,     NULL,                 BNETD_TRACK_TIME,    NULL, 0 },
    { "location",           conf_type_char,    "",                   NONE,                NULL, 0 },
    { "description",        conf_type_char,    "",                   NONE,                NULL, 0 },
    { "url",                conf_type_char,    "",                   NONE,                NULL, 0 },
    { "contact_name",       conf_type_char,    "",                   NONE,                NULL, 0 },
    { "contact_email",      conf_type_char,    "",                   NONE,                NULL, 0 },
    { "latency",            conf_type_int,     NULL,                 BNETD_LATENCY,       NULL, 0 },
    { "shutdown_delay",     conf_type_int,     NULL,                 BNETD_SHUTDELAY,     NULL, 0 },
    { "shutdown_decr",      conf_type_int,     NULL,                 BNETD_SHUTDECR,      NULL, 0 },
    { "new_accounts",       conf_type_bool,    NULL,                 1,                   NULL, 0 },
    { "kick_old_login",     conf_type_bool,    NULL,                 1,                   NULL, 0 },
    { "ask_new_channel",    conf_type_bool,    NULL,                 1,                   NULL, 0 },
    { "hide_pass_games",    conf_type_bool,    NULL,                 1,                   NULL, 0 },
    { "hide_temp_channels", conf_type_bool,    NULL,                 1,                   NULL, 0 },
    { "hide_addr",          conf_type_bool,    NULL,                 1,                   NULL, 0 },
    { "enable_conn_all",    conf_type_bool,    NULL,                 0,                   NULL, 0 },
    { "extra_commands",     conf_type_bool,    NULL,                 0,                   NULL, 0 },
    { "reportdir",          conf_type_char,    BNETD_REPORT_DIR,     NONE,                NULL, 0 },
    { "report_all_games",   conf_type_bool,    NULL,                 0,                   NULL, 0 },
    { "iconfile",           conf_type_char,    BNETD_ICON_FILE,      NONE,                NULL, 0 },
    { "tosfile",            conf_type_char,    BNETD_TOS_FILE,       NONE,                NULL, 0 },
    { "versionfile",	    conf_type_char,    BNETD_VERSION_FILE,   NONE,                NULL, 0 },
    { "versionmpq",	    conf_type_char,    BNETD_VERSION_MPQ,    NONE,                NULL, 0 },
    { "mpqcalc_key",	    conf_type_char,    BNETD_MPQCALC_KEY,    NONE,                NULL, 0 },
    { "allow_versioncheck", conf_type_bool,    NULL,                 1,                   NULL, 0 },
    { "versionchecksum",    conf_type_bool,    NULL,                 0,                   NULL, 0 },
    { "allow_unknownver",   conf_type_bool,    NULL,                 1,                   NULL, 0 },
    { "preloadaccount",	    conf_type_bool,    NULL,                 1,                   NULL, 0 },
    { "allowadbanner",	    conf_type_bool,    NULL,                 1,                   NULL, 0 },
    { "trackaddrs",         conf_type_char,    BNETD_TRACK_ADDRS,    NONE,                NULL, 0 },
    { "servaddrs",          conf_type_char,    BNETD_SERV_ADDRS,     NONE,                NULL, 0 },
    { "realmservername",    conf_type_char,    BNETD_REALM_SERVER,   NONE,		  NULL, 0 },
    { "realmport",    	    conf_type_int,     NULL,   		     BNETD_REALM_PORT,	  NULL, 0 },
    { "allowrealm",    	    conf_type_bool,    NULL,   		     0,			  NULL, 0 },
    { "allowd2game",   	    conf_type_bool,    NULL,   		     0,			  NULL, 0 },
    { "allowd2localsave",   conf_type_bool,    NULL,   		     0,			  NULL, 0 },
    { "maxd2game",    	    conf_type_int,     NULL,   		     BNETD_MAX_D2GAME,	  NULL, 0 },
    { "d2servcheckinterval",conf_type_int,     NULL,   		     D2CHECK_INTERVAL,	  NULL, 0 },
    { "ladderrefreshtime",  conf_type_int,     NULL,   		     LADDER_REFRESH_TIME, NULL, 0 },
    { "realmaddr",    	    conf_type_char,    BNETD_REALM_ADDR,     NONE,		  NULL, 0 },
    { "realmdesc",	    conf_type_char,    BNETD_REALM_DESC,     NONE,		  NULL, 0 },
    { "authmotd",	    conf_type_char,    NULL,		     NONE,		  NULL, 0 },
    { "realmcharmax",	    conf_type_int,     NULL,	 	     BNETD_REALM_CHARMAX, NULL, 0 },
    { "d2localport",	    conf_type_int,     NULL,		     BNETD_D2SERV_PORT,   NULL, 0 },
    { "d2remoteport",	    conf_type_int,     NULL,		     BNETD_D2SERV_PORT,   NULL, 0 },
    { "d2localservaddr",    conf_type_char,    BNETD_DEFAULT_HOST,   NONE,		  NULL, 0 },
    { "d2remoteservaddr",   conf_type_char,    BNETD_DEFAULT_HOST,   NONE,		  NULL, 0 },
    { "d2newbiefile",	    conf_type_char,    NULL,		     NONE,		  NULL, 0 },
    { "d2savedir",	    conf_type_char,    NULL,		     NONE,		  NULL, 0 },
    { "d2removedir",	    conf_type_char,    NULL,		     NONE,		  NULL, 0 },
    { "use_keepalive",      conf_type_bool,    NULL,                 0,                   NULL, 0 },
    { "udptest_port",       conf_type_int,     NULL,                 BNETD_DEF_TEST_PORT, NULL, 0 },
    { "do_uplink",          conf_type_bool,    NULL,                 BITS_DO_UPLINK,      NULL, 0 },
    { "allow_uplink",       conf_type_bool,    NULL,                 BITS_ALLOW_UPLINK,   NULL, 0 },
    { "ipbanfile",          conf_type_char,    BITS_IPBAN_FILE,      NONE,                NULL, 0 },
    { "disc_is_loss",       conf_type_bool,    NULL,                 0,                   NULL, 0 },
    { "helpfile",           conf_type_char,    BNETD_HELP_FILE,      NONE,                NULL, 0 },
    { "fortunecmd",         conf_type_char,    BNETD_FORTUNECMD,     NONE,                NULL, 0 },
    { "transfile",          conf_type_char,    BNETD_TRANS_FILE,     NONE,                NULL, 0 },
    { "chatcmd",	    conf_type_bool,    NULL,		     0,			  NULL, 0 },
    { "chatfile",           conf_type_char,    BNETD_CHAT_FILE,      NONE,                NULL, 0 },
    { "chat_himself",       conf_type_char,    BNETD_CHAT_HIMSELF,   NONE,                NULL, 0 },
    { "ladder_init_rating", conf_type_int,     NULL,                 LADDER_INIT_RATING,  NULL, 0 },
    { "maxlogline",	    conf_type_int,     NULL,                 0,			  NULL, 0 },
    { NULL,                 conf_type_none,    NULL,                 NONE,                NULL, 0 }
};

#define BITS_UPLINK_SERVER    "localhost"
#define BITS_UPLINK_USERNAME  "anonymous"
#define BITS_ALLOW_UPLINK     0
#define BITS_PASSWORD_FILE    "conf/bits_passwd"


char const * preffile=NULL;


static int processDirective(char const * directive, char const * value, unsigned int curLine)
{
    unsigned int i;
    
    if (!directive || !value)
    {
	eventlog(eventlog_level_error,"processDirective","got NULL input(s)");
	return -1;
    }
    
    for (i=0; conf_table[i].directive; i++)
        if (strcasecmp(conf_table[i].directive,directive) == 0)
	{
            switch (conf_table[i].type)
            {
	    case conf_type_char:
		{
		    char const * temp;
		    
		    if (!(temp = strdup(value)))
		    {
			eventlog(eventlog_level_error,"processDirective","could not allocate memory for value");
			break;
		    }
		    if (conf_table[i].charval)
			free((void *)conf_table[i].charval);
		    conf_table[i].charval = temp;
		}
		break;
		
	    case conf_type_int:
		{
		    unsigned int temp;
		    
		    if (str_to_uint(value,&temp)<0)
			eventlog(eventlog_level_error,"processDirective","invalid integer value \"%s\" for element \"%s\" at line %u",value,directive,curLine);
		    else
                	conf_table[i].intval = temp;
		}
		break;
		
	    case conf_type_bool:
		switch (str_get_bool(value))
		{
		case 1:
		    conf_table[i].intval = 1;
		    break;
		case 0:
		    conf_table[i].intval = 0;
		    break;
		default:
		    eventlog(eventlog_level_error,"processDirective","invalid boolean value for element \"%s\" at line %u",directive,curLine);
		}
		break;
		
	    default:
		eventlog(eventlog_level_error,"processDirective","invalid type %d in table",(int)conf_table[i].type);
	    }
	    return 0;
	}
    
    eventlog(eventlog_level_error,"processDirective","unknown element \"%s\" at line %u",directive,curLine);
    return -1;
}


static char const * get_char_conf(char const * directive)
{
    unsigned int i;
    
    for (i=0; conf_table[i].directive; i++)
	if (conf_table[i].type==conf_type_char && strcasecmp(conf_table[i].directive,directive)==0)
	    return conf_table[i].charval;
    
    return NULL;
}


static unsigned int get_int_conf(char const * directive)
{
    unsigned int i;
    
    for (i=0; conf_table[i].directive; i++)
	if (conf_table[i].type==conf_type_int && strcasecmp(conf_table[i].directive,directive)==0)
	    return conf_table[i].intval;
    
    return 0;
}


static int get_bool_conf(char const * directive)
{
    unsigned int i;
    
    for (i=0; conf_table[i].directive; i++)
	if (conf_table[i].type==conf_type_bool && strcasecmp(conf_table[i].directive,directive)==0)
	    return conf_table[i].intval;
    
    return 0;
}


extern int prefs_load(char const * filename)
{
    /* restore defaults */
    {
	unsigned int i;
	
	for (i=0; conf_table[i].directive; i++)
	    switch (conf_table[i].type)
	    {
	    case conf_type_int:
	    case conf_type_bool:
		conf_table[i].intval = conf_table[i].defintval;
		break;
		
	    case conf_type_char:
		if (conf_table[i].charval)
		    free((void *)conf_table[i].charval);
		if (!conf_table[i].defcharval)
		    conf_table[i].charval = NULL;
		else
		    if (!(conf_table[i].charval = strdup(conf_table[i].defcharval)))
		    {
			eventlog(eventlog_level_error,"prefs_load","could not allocate memory for conf_table[i].charval");
			return -1;
		    }
		break;
		
	    default:
		eventlog(eventlog_level_error,"prefs_load","invalid type %d in table",(int)conf_table[i].type);
		return -1;
	    }
    }
    
    /* load file */
    if (filename)
    {
	FILE *       fp;
	char *       buff;
	char *       cp;
	char *       temp;
	unsigned int currline;
	unsigned int j;
	char const * directive;
	char const * value;
	char *       rawvalue;
	
        if (!(fp = fopen(filename,"r")))
        {
            eventlog(eventlog_level_error,"prefs_load","could not open file \"%s\" for reading (fopen: %s)",filename,strerror(errno));
            return -1;
        }
	
	/* Read the configuration file */
	for (currline=1; (buff = file_get_line(fp)); currline++)
	{
	    cp = buff;
	    
            while (*cp=='\t' || *cp==' ') cp++;
	    if (*cp=='\0' || *cp=='#')
	    {
		free(buff);
		continue;
	    }
	    temp = cp;
	    while (*cp!='\t' && *cp!=' ' && *cp!='\0') cp++;
	    if (*cp!='\0')
	    {
		*cp = '\0';
		cp++;
	    }
	    if (!(directive = strdup(temp)))
	    {
		eventlog(eventlog_level_error,"prefs_load","could not allocate memory for directive");
		free(buff);
		continue;
	    }
            while (*cp=='\t' || *cp==' ') cp++;
	    if (*cp!='=')
	    {
		eventlog(eventlog_level_error,"prefs_load","missing = on line %u",currline);
		free((void *)directive);
		free(buff);
		continue;
	    }
	    cp++;
	    while (*cp=='\t' || *cp==' ') cp++;
	    if (*cp=='\0')
	    {
		eventlog(eventlog_level_error,"prefs_load","missing value after = on line %u",currline);
		free((void *)directive);
		free(buff);
		continue;
	    }
	    if (!(rawvalue = strdup(cp)))
	    {
		eventlog(eventlog_level_error,"prefs_load","could not allocate memory for rawvalue");
		free((void *)directive);
		free(buff);
		continue;
	    }
	    
	    if (rawvalue[0]=='"')
	    {
		char prev;
		
		for (j=1,prev='\0'; rawvalue[j]!='\0'; j++)
		{
		    switch (rawvalue[j])
		    {
		    case '"':
			if (prev!='\\')
			    break;
			prev = '"';
			continue;
		    case '\\':
			if (prev=='\\')
			    prev = '\0';
			else
			    prev = '\\';
			continue;
		    default:
			prev = rawvalue[j];
			continue;
		    }
		    break;
		}
		if (rawvalue[j]!='"')
		{
		    eventlog(eventlog_level_error,"processDirective","missing end quote for value of element \"%s\" on line %u",directive,currline);
		    free(rawvalue);
		    free((void *)directive);
		    free(buff);
		    continue;
		}
		rawvalue[j] = '\0';
		if (rawvalue[j+1]!='\0' && rawvalue[j+1]!='#')
		{
		    eventlog(eventlog_level_error,"processDirective","extra characters after the value for element \"%s\" on line %u",directive,currline);
		    free(rawvalue);
		    free((void *)directive);
		    free(buff);
		    continue;
		}
		value = &rawvalue[1];
            }
	    else
	    {
		unsigned int k;
		
		for (j=0; rawvalue[j]!='\0' && rawvalue[j]!=' ' && rawvalue[j]!='\t'; j++);
		k = j;
		while (rawvalue[k]==' ' || rawvalue[k]=='\t') k++;
		if (rawvalue[k]!='\0' && rawvalue[k]!='#')
		{
		    eventlog(eventlog_level_error,"processDirective","extra characters after the value for element \"%s\" on line %u (%s)",directive,currline,&rawvalue[k]);
		    free(rawvalue);
		    free((void *)directive);
		    free(buff);
		    continue;
		}
		rawvalue[j] = '\0';
		value = rawvalue;
	    }
            
	    processDirective(directive,value,currline);
	    
	    free(rawvalue);
	    free((void *)directive);
	    free(buff);
	}
    fclose(fp); 
    }
    return 0;
}


extern void prefs_unload(void)
{
    unsigned int i;
    
    for (i=0; conf_table[i].directive; i++)
	switch (conf_table[i].type)
	{
	case conf_type_int:
	case conf_type_bool:
	    break;
	    
	case conf_type_char:
	    if (conf_table[i].charval)
	    {
		free((void *)conf_table[i].charval);
		conf_table[i].charval = NULL;
	    }
	    break;
	    
	default:
	    eventlog(eventlog_level_error,"prefs_unload","invalid type %d in table",(int)conf_table[i].type);
	    break;
	}
}


extern char const * prefs_get_userdir(void)
{
    return get_char_conf("userdir");
}

extern char const * prefs_get_filedir(void)
{
    return get_char_conf("filedir");
}


extern char const * prefs_get_logfile(void)
{
    return get_char_conf("logfile");
}


extern char const * prefs_get_loglevels(void)
{
    return get_char_conf("loglevels");
}


extern char const * prefs_get_defacct(void)
{
    return get_char_conf("defacct");
}


extern char const * prefs_get_motdfile(void)
{
    return get_char_conf("motdfile");
}


extern char const * prefs_get_newsfile(void)
{
    return get_char_conf("newsfile");
}


extern char const * prefs_get_adfile(void)
{
    return get_char_conf("adfile");
}


extern unsigned int prefs_get_user_sync_timer(void)
{
    return get_int_conf("usersync");
}


extern unsigned int prefs_get_user_flush_timer(void)
{
    return get_int_conf("userflush");
}


extern unsigned int prefs_get_track(void)
{
    return get_int_conf("track");
}


extern char const * prefs_get_location(void)
{
    return get_char_conf("location");
}


extern char const * prefs_get_description(void)
{
    return get_char_conf("description");
}


extern char const * prefs_get_url(void)
{
    return get_char_conf("url");
}


extern char const * prefs_get_contact_name(void)
{
    return get_char_conf("contact_name");
}


extern char const * prefs_get_contact_email(void)
{
    return get_char_conf("contact_email");
}


extern unsigned int prefs_get_latency(void)
{
    return get_int_conf("latency");
}


extern unsigned int prefs_get_shutdown_delay(void)
{
    return get_int_conf("shutdown_delay");
}


extern unsigned int prefs_get_shutdown_decr(void)
{
    return get_int_conf("shutdown_decr");
}


extern unsigned int prefs_get_allow_new_accounts(void)
{
    return get_bool_conf("new_accounts");
}


extern unsigned int prefs_get_kick_old_login(void)
{
    return get_bool_conf("kick_old_login");
}


extern char const * prefs_get_channelfile(void)
{
    return get_char_conf("channelfile");
}


extern unsigned int prefs_get_ask_new_channel(void)
{
    return get_bool_conf("ask_new_channel");
}


extern unsigned int prefs_get_hide_pass_games(void)
{
    return get_bool_conf("hide_pass_games");
}


extern unsigned int prefs_get_hide_temp_channels(void)
{
    return get_bool_conf("hide_temp_channels");
}


extern unsigned int prefs_get_hide_addr(void)
{
    return get_bool_conf("hide_addr");
}


extern unsigned int prefs_get_enable_conn_all(void)
{
    return get_bool_conf("enable_conn_all");
}


extern unsigned int prefs_get_extra_commands(void)
{
    return get_bool_conf("extra_commands");
}


extern char const * prefs_get_reportdir(void)
{
    return get_char_conf("reportdir");
}


extern unsigned int prefs_get_report_all_games(void)
{
    return get_bool_conf("report_all_games");
}


extern char const * prefs_get_pidfile(void)
{
    return get_char_conf("pidfile");
}


extern char const * prefs_get_iconfile(void)
{
    return get_char_conf("iconfile");
}


extern char const * prefs_get_tosfile(void)
{
    return get_char_conf("tosfile");
}


extern unsigned int prefs_get_allow_versioncheck(void)
{
    return get_bool_conf("allow_versioncheck");
}

extern unsigned int prefs_allow_version_checksum(void)
{
    return get_bool_conf("versionchecksum");
}

extern unsigned int prefs_allow_unknownversion(void)
{
    return get_bool_conf("allow_unknownver");
}

extern char const * prefs_get_versionfile(void)
{
    return get_char_conf("versionfile");
}

extern char const * prefs_get_version_mpq(void)
{
    return get_char_conf("versionmpq");
}

extern char const * prefs_get_mpqcalc_key(void)
{
    return get_char_conf("mpqcalc_key");
}

extern char const * prefs_get_trackserv_addrs(void)
{
    return get_char_conf("trackaddrs");
}


extern char const * prefs_get_bnetdserv_addrs(void)
{
    return get_char_conf("servaddrs");
}


extern unsigned int prefs_get_use_keepalive(void)
{
    return get_bool_conf("use_keepalive");
}


extern unsigned int prefs_get_udptest_port(void)
{
    return get_int_conf("udptest_port");
}


extern unsigned int prefs_get_do_uplink(void)
{
    return get_bool_conf("do_uplink");
}

extern char const * prefs_get_uplink_server(void)
{
    return get_char_conf("uplink_server");
}


extern unsigned int prefs_get_allow_uplink(void)
{
    return get_bool_conf("allow_uplink");
}


extern char const * prefs_get_bits_password_file(void)
{
    return get_char_conf("bits_password_file");
}


extern char const * prefs_get_uplink_username(void)
{
    return get_char_conf("uplink_username");
}


extern char const * prefs_get_ipbanfile(void)
{
    return get_char_conf("ipbanfile");
}


extern unsigned int prefs_get_bits_debug(void)
{
    return get_bool_conf("bits_debug");
}


extern unsigned int prefs_get_discisloss(void)
{
    return get_bool_conf("disc_is_loss");
}


extern char const * prefs_get_helpfile(void)
{
    return get_char_conf("helpfile");
}

extern char const * prefs_get_fortunecmd(void)
{
    return get_char_conf("fortunecmd");
}

extern char const * prefs_get_transfile(void)
{
    return get_char_conf("transfile");
}

extern unsigned int prefs_get_allow_chatcmd(void)
{
    return get_bool_conf("chatcmd");
}

extern char const * prefs_get_chatfile(void)
{
    return get_char_conf("chatfile");
}

extern char const * prefs_get_chat_himself(void)
{
    return get_char_conf("chat_himself");
}

extern char const * prefs_get_realmservername(void)
{
    return get_char_conf("realmservername");
}

extern unsigned int prefs_get_realmcharmax(void)
{
    return get_int_conf("realmcharmax");
}

extern char const * prefs_get_realmdesc(void)
{
    return get_char_conf("realmdesc");
}

extern char const * prefs_get_realmaddr(void)
{
    return get_char_conf("realmaddr");
}

extern unsigned int prefs_get_realmport(void)
{
   return get_int_conf("realmport");
}

extern unsigned int prefs_allow_realm(void)
{
   return get_bool_conf("allowrealm");
}

extern unsigned int prefs_get_d2game_lport(void)
{
   return get_int_conf("d2localport");
}

extern unsigned int prefs_get_d2game_rport(void)
{
   return get_int_conf("d2remoteport");
}

extern char const * prefs_get_d2game_lservaddr(void)
{
   return get_char_conf("d2localservaddr");
}

extern char const * prefs_get_d2newbie(void)
{
   return get_char_conf("d2newbiefile");
}

extern char const * prefs_get_authmotd(void)
{
   return get_char_conf("authmotd");
}

extern unsigned int prefs_allow_d2game(void)
{
   return get_bool_conf("allowd2game");
}

extern char const * prefs_get_d2savedir(void)
{
   return get_char_conf("d2savedir");
}	

extern char const * prefs_get_d2game_rservaddr(void)
{
   return get_char_conf("d2remoteservaddr");
}

extern char const * prefs_get_d2removedir(void)
{
   return get_char_conf("d2removedir");
}

extern unsigned int prefs_get_maxd2game(void)
{
   return get_int_conf("maxd2game");
}


extern unsigned int prefs_allow_d2localsave(void)
{
    return get_bool_conf("allowd2localsave");
}

extern unsigned int prefs_allow_adbanner(void)
{
    return get_bool_conf("allowadbanner");
}

extern unsigned int prefs_get_d2server_check_interval(void)
{
    return get_int_conf("d2servcheckinterval");
}

extern unsigned int prefs_get_ladder_refresh_time(void)
{
    return get_int_conf("ladderrefreshtime");
}

extern unsigned int prefs_allow_preload_account(void)
{
    return get_bool_conf("preloadaccount");
}

extern unsigned int prefs_get_ladder_init_rating(void)
{
    return get_int_conf("ladder_init_rating");
}

extern unsigned int prefs_get_maxlogline(void)
{
    return get_int_conf("maxlogline");
}
