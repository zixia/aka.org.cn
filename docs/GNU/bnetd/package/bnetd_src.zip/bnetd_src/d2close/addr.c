/*
 * Copyright (C) 1999,2000  Ross Combs (rocombs@cs.nmsu.edu)
 * Copyright (C) 2000 Onlyer (onlyer@263.net)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#define ADDR_INTERNAL_ACCESS
#include "config.h"
#include "setup.h"
#include <ctype.h>

#define USE_STDDEF_HEADERS
#define USE_STDC_HEADERS
#define USE_STRING_HEADERS
#define USE_MEMORY_HEADERS
#define USE_SYS_TYPES_HEADERS
#define USE_SOCKET_HEADERS

#include "compat.h"

#include "compat/memset.h"
#include "compat/memcpy.h"
#include "compat/strrchr.h"
#include "compat/strdup.h"
#include "compat/psock.h"

#include "eventlog.h"
#include "list.h"
#include "util.h"
#include "addr.h"


#define HACK_SIZE 4

/* both arguments are in host byte order */
extern char const * addr_num_to_addr_str(unsigned int ipaddr, unsigned short port)
{
    static unsigned int curr=0;
    static char         temp[HACK_SIZE][64];
    struct sockaddr_in  tsa;
    
    curr = (curr+1)%HACK_SIZE;
    
    memset(&tsa,0,sizeof(tsa));
    tsa.sin_family = AF_INET;
    tsa.sin_port = htons((unsigned short)0);
    tsa.sin_addr.s_addr = htonl(ipaddr);
    sprintf(temp[curr],"%.32s:%hu",inet_ntoa(tsa.sin_addr),port);
    
    return temp[curr];
}


#ifdef USE_CHECK_ALLOC
extern t_addr * addr_create_num_real(unsigned int ipaddr, unsigned short port, char const * fn, unsigned int ln)
#else
extern t_addr * addr_create_num(unsigned int ipaddr, unsigned short port)
#endif
{
    t_addr * temp;
    
#ifdef USE_CHECK_ALLOC
    if (!(temp = check_malloc(sizeof(t_addr),fn,ln)))
#else
    if (!(temp = malloc(sizeof(t_addr))))
#endif
    {
	eventlog(eventlog_level_error,"addr_create_num","unable to allocate memory for addr");
	return NULL;
    }
    
    temp->str    = NULL;
    temp->ip     = ipaddr;
    temp->port   = port;
    temp->data.p = NULL;
    
    return temp;
}


#ifdef USE_CHECK_ALLOC
extern t_addr * addr_create_str_real(char const * str, unsigned int defipaddr, unsigned short defport, char const * fn, unsigned int ln)
#else
extern t_addr * addr_create_str(char const * str, unsigned int defipaddr, unsigned short defport)
#endif
{
    char *             tstr;
    t_addr *           temp;
    struct sockaddr_in tsa;
    struct hostent *   hp;
    char const *       hostname;
    char *             portstr;
    unsigned short     port;
    
    if (!str)
    {
	eventlog(eventlog_level_error,"addr_create_str","got NULL str");
	return NULL;
    }
    
    if (!(tstr = strdup(str)))
    {
	eventlog(eventlog_level_error,"addr_create_str","could not allocate memory for str");
	return NULL;
    }
    
    if ((portstr = strrchr(tstr,':')))
    {
	*portstr = '\0';
	portstr++;
	
	if (portstr[0]!='\0')
	{
	    if (str_to_ushort(portstr,&port)<0)
	    {
		eventlog(eventlog_level_error,"addr_create_str","could not convert \"%s\" to a port number",portstr);
		free(tstr);
		return NULL;
	    }
	}
	else
	    port = defport;
    }
    else
	port = defport;
    
    memset(&tsa,0,sizeof(tsa));
    tsa.sin_family = AF_INET;
    tsa.sin_port = htons((unsigned short)0);
    
    if (tstr[0]!='\0')
    {
	if (!(hostname = strdup(tstr)))
	{
	    eventlog(eventlog_level_error,"addr_create_str","could not allocate memory for hostname");
	    free(tstr);
	    return NULL;
	}
	
	if (isdigit(hostname[0])) {
	      tsa.sin_addr.s_addr = inet_addr(hostname);
	}
	else {
	    hp = gethostbyname(hostname);
	    if (!hp || !hp->h_addr_list) {
	    eventlog(eventlog_level_error,"addr_create_str","could not lookup host \"%s\"",hostname);
	    free((void *)hostname);
	    free(tstr);
	    return NULL;
	    }
	memcpy(&tsa.sin_addr,(void *)hp->h_addr_list[0],sizeof(struct in_addr)); /* avoid warning */
	}
    }
    else
    {
	tsa.sin_addr.s_addr = htonl(defipaddr);
	if (!(hostname = strdup(inet_ntoa(tsa.sin_addr))))
	{
	    eventlog(eventlog_level_error,"addr_create_str","could not allocate memory for hostname");
	    free(tstr);
	    return NULL;
	}
    }
    
    free(tstr);
    
#ifdef USE_CHECK_ALLOC
    if (!(temp = check_malloc(sizeof(t_addr),fn,ln)))
#else
    if (!(temp = malloc(sizeof(t_addr))))
#endif
    {
	eventlog(eventlog_level_error,"addr_create_str","unable to allocate memory for addr");
	free((void *)hostname);
	return NULL;
    }
    
    temp->str    = hostname;
    temp->ip     = ntohl(tsa.sin_addr.s_addr);
    temp->port   = port;
    temp->data.p = NULL;
    
    return temp;
}


extern int addr_destroy(t_addr const * addr)
{
    if (!addr)
    {
	eventlog(eventlog_level_error,"addr_destroy","got NULL addr");
	return -1;
    }
    
    if (addr->str)
	free((void *)addr->str);
    free((void *)addr);
    
    return 0;
}


/* hostname or IP */
extern int addr_get_host_str(t_addr const * addr, char * str, unsigned int len)
{
    if (!addr)
    {
	eventlog(eventlog_level_error,"addr_get_host_str","got NULL addr");
	return -1;
    }
    if (!str)
    {
	eventlog(eventlog_level_error,"addr_get_host_str","got NULL str");
	return -1;
    }
    if (len<2)
    {
	eventlog(eventlog_level_error,"addr_get_host_str","str too short");
	return -1;
    }
    
    if (addr->str)
    {
	strncpy(str,addr->str,len-1);
	str[len-1] = '\0';
	
	return 0;
    }
    
    strncpy(str,addr_num_to_addr_str(addr->ip,addr->port),len-1);
    str[len-1] = '\0';
    
    return 0;
}


/* IP:port */
extern int addr_get_addr_str(t_addr const * addr, char * str, unsigned int len)
{
    if (!addr)
    {
	eventlog(eventlog_level_error,"addr_get_addr_str","got NULL addr");
	return -1;
    }
    if (!str)
    {
	eventlog(eventlog_level_error,"addr_get_addr_str","got NULL str");
	return -1;
    }
    if (len<2)
    {
	eventlog(eventlog_level_error,"addr_get_addr_str","str too short");
	return -1;
    }
    
    strncpy(str,addr_num_to_addr_str(addr->ip,addr->port),len-1);
    str[len-1] = '\0';
    
    return 0;
}


extern unsigned int addr_get_ip(t_addr const * addr)
{
    if (!addr)
    {
	eventlog(eventlog_level_error,"addr_get_ip","got NULL addr");
	return 0;
    }
    
    return addr->ip;
}


extern unsigned short addr_get_port(t_addr const * addr)
{
    if (!addr)
    {
	eventlog(eventlog_level_error,"addr_get_port","got NULL addr");
	return 0;
    }
    
    return addr->port;
}


extern int addr_set_data(t_addr * addr, t_addr_data data)
{
    if (!addr)
    {
	eventlog(eventlog_level_error,"addr_set_data","got NULL addr");
	return -1;
    }
    
    addr->data = data;
    return 0;
}


extern t_addr_data addr_get_data(t_addr const * addr)
{
    t_addr_data tdata;
    
    if (!addr)
    {
	eventlog(eventlog_level_error,"addr_get_data","got NULL addr");
	tdata.p = NULL;
	return tdata;
    }
    
    return addr->data;
}


extern t_addrlist * addrlist_create(char const * str, unsigned int defipaddr, unsigned short defport)
{
    t_addrlist * addrlist;
    t_addr *     addr;
    char *       tstr;
    char *       tok;
    
    if (!str)
    {
	eventlog(eventlog_level_error,"addrlist_create","got NULL str");
	return NULL;
    }
    
    if (!(addrlist = list_create()))
    {
	eventlog(eventlog_level_error,"addrlist_crreate","coult not create list");
	return NULL;
    }
    if (!(tstr = strdup(str)))
    {
	eventlog(eventlog_level_error,"addrlist_create","could not allocate memory for tstr");
	return NULL;
    }
    
    for (tok=strtok(tstr,","); tok; tok=strtok(NULL,",")) /* strtok modifies the string it is passed */
    {
	if (!(addr = addr_create_str(tok,defipaddr,defport)))
	{
	    eventlog(eventlog_level_error,"addrlist_create","could not create addr");
	    addrlist_destroy(addrlist);
	    free(tstr);
	    return NULL;
	}
	if (list_append_data(addrlist,addr)<0)
	{
	    eventlog(eventlog_level_error,"addrlist_create","could not add item to list");
	    addr_destroy(addr);
	    addrlist_destroy(addrlist);
	    free(tstr);
	    return NULL;
	}
    }
    free(tstr);
    
    return addrlist;
}


extern int addrlist_destroy(t_addrlist * addrlist)
{
    t_addr *	   addr;
    t_elem *	   elem;
    
    if (!addrlist)
    {
	eventlog(eventlog_level_error,"addrlist_destroy","got NULL addrlist");
	return -1;
    }
    
    LIST_TRAVERSE_DATA(addrlist,elem,addr)
    {
        addr_destroy(addr);
        list_remove_elem(addrlist,elem);
    }

    return list_destroy(addrlist);
}


extern int addrlist_get_length(t_addrlist const * addrlist)
{
    return list_get_length(addrlist);
}

/*

extern t_addr * addrlist_find_addr_by_ip(t_addrlist * addrlist, unsigned int ip)
{
    t_addr *	    curr_addr;
    t_elem const *  elem;

    LIST_TRAVERSE_DATA_CONST(addrlist,elem,curr_addr)
    {
	if (addr_get_ip(curr_addr)==ip) return curr_addr;
    }
    return NULL;
}

*/

extern void * addr_get_info(t_addr const * addr)
{
    if (!addr) {
	eventlog(eventlog_level_error,"addr_get_info","got NULL addr");
	return NULL;
    }
    return addr->data.p;
}

