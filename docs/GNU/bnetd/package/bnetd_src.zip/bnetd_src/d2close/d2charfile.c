/*
 * Copyright (C) 2000  Onlyer (onlyer@263.net)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#include "config.h"
#include "setup.h"

#include <stdio.h>
#include <errno.h>

#define USE_STDDEF_HEADERS
#define USE_STDC_HEADERS
#define USE_MEMORY_HEADERS
#define USE_STRING_HEADERS
#define USE_UNISTD_HEADERS
#define USE_FCNTL_HEADERS
#define USE_SYS_STAT_HEADERS

#include "compat.h"

#include "compat/strcasecmp.h"
#include "compat/strerror.h"

#include "account.h"
#include "connection.h"
#include "eventlog.h"
#include "prefs.h"
#include "bn_type.h"
#include "field_sizes.h"
#include "d2charfile.h"



static int d2char_create(char const * charname,unsigned short class,int type);
static int d2char_remove(char const * charname);



/* add an entry into the d2char list		    */
/* then create an newbie save file for it(depend on class to change */
extern int d2char_addchar(t_account * account,char const * charname,\
			  unsigned short class,int type)
{
    if (!account) {
	eventlog(eventlog_level_error,"d2char_addchar","got NULL account");
	return -1;
    }
    if (!charname) {
	eventlog(eventlog_level_error,"d2char_addchar","got NULL charname");
	return -1;
    }
    if (class>D2MAX_CHAR_CLASS) {
	eventlog(eventlog_level_error,"d2char_addchar","bad char class %d",class);
	return -1;
    }
    if (d2char_findcharfile(charname)==1) {
	eventlog(eventlog_level_error,"d2char_addchar","char %s already exist",charname);
	return -1;
    }
    if (d2char_findchar(account,charname)==1) {
	char const * tname;
	tname=account_get_name(account);
	eventlog(eventlog_level_error,"d2char_addchar","char %s already in account %s,no new char created",charname,tname);
	d2char_delchar(account,charname,1);
	account_unget_name(tname);
	return -1;
    }
    if (d2char_create(charname,class,type)<0) {
	eventlog(eventlog_level_error,"d2char_addchar","create char error");
	return -1;
    }
    else {
	char const * oldlist;
	char * newlist;
	oldlist=account_get_d2charlist(account);
	if (!oldlist) {
	    if (!(newlist=malloc(strlen(charname)+2))) {
	   	eventlog(eventlog_level_error,"d2char_addchar","could not allocate memory for charlist");
		d2char_remove(charname);
		return -1;
	    }
	    else sprintf (newlist,"%s ",charname);
	}
	else {
	    if (!(newlist=malloc(strlen(oldlist)+1+strlen(charname)+2))) {
	   	eventlog(eventlog_level_error,"d2char_addchar","could not allocate memory for charlist");
		d2char_remove(charname);
		return -1;
	    }
	    if (oldlist[strlen(oldlist)-1]!=' ') sprintf (newlist,"%s %s ",oldlist,charname);
	    else sprintf (newlist,"%s%s ",oldlist,charname);
	}
	account_set_d2charlist(account,newlist);
	free(newlist);
	return 0;
    }
}

/*  just del the charname from list	*/
/*  then move the deleted char file into a directory removed ? */
extern int d2char_delchar(t_account * account,char const * charname,int listonly)
{
	
    if (!account) {
	eventlog(eventlog_level_error,"d2char_delchar","got NULL account");
	return -1;
    }
    if (!charname) {
	eventlog(eventlog_level_error,"d2char_delchar","got NULL charname");
	return -1;
    }

    if (d2char_findchar(account,charname)!=1) {
	char const * tname;
	tname=account_get_name(account);
	eventlog(eventlog_level_error,"d2char_delchar","char %s not in account %s,no char deleted",charname,tname);
	account_unget_name(tname);
	return -1;
    }
    if (listonly==0)  {
	if (d2char_findcharfile(charname)!=1) {
	    eventlog(eventlog_level_error,"d2char_delchar","char file %s not exist",charname);
	    d2char_delchar(account,charname,1);
	    return -1;
	}
    }
    {
	char const * oldlist;
	char * newlist;
	char * tempname;
	char * p;
	int size;

	oldlist=account_get_d2charlist(account);
	if (!oldlist) return -1;
	if (!(tempname=malloc(strlen(charname)+2))) {
	    eventlog(eventlog_level_error,"d2char_delchar","could not allocate memory for tempname");
	    return -1;
	}
	sprintf (tempname,"%s ",charname);
	if (!(p=strstr(oldlist,tempname))) {
	    eventlog(eventlog_level_error,"d2char_delchar","no char name matched for %s",tempname);
	    free(tempname);
	    return -1;
	}
	size=p-oldlist;
	if (!(newlist=malloc(strlen(oldlist)+strlen(tempname)+1))) {
	    eventlog(eventlog_level_error,"d2char_delchar","could not allocate memory for newlist");
	    free(tempname);
	    return -1;
	}
	strncpy(newlist,oldlist,size);
	strcpy(&newlist[size],&oldlist[size+strlen(tempname)]);
	free(tempname);
	account_set_d2charlist(account,newlist);
	if (listonly) return 0;
	if (d2char_remove(charname)<0) {
	    eventlog(eventlog_level_error,"d2char_delchar","char %s remove failed",charname);
	    d2char_delchar(account,charname,1);
	    return -1;
	}
    }
    return 0;
	
}

extern int d2char_findcharfile(char const * charname)
{
    char * tempname;

    if (!charname) {
	eventlog(eventlog_level_error,"d2char_findcharfile","got NULL charname");
	return -1;
    }
    if (!prefs_get_d2savedir()) {
	eventlog(eventlog_level_error,"d2char_findcharfile","no save dir defined,bypass char create and erase");
	return -1;
    }
    if (!(tempname=malloc(strlen(prefs_get_d2savedir())+1+strlen(charname)+1)))
    {
	eventlog(eventlog_level_error,"d2char_findcharfile","could not allocate memory for tempname");
	return -1;
    }
    sprintf (tempname,"%s/%s",prefs_get_d2savedir(),charname);
    if (access(tempname,0)) {
	free(tempname);
	return 0;
    }
    else {
	free(tempname);
	return 1;
    }

}

    
extern int d2char_findchar(t_account * account,char const * charname)
{
    char const * list;
    char * temp;
    char * tok;

    if (!account) {
	eventlog(eventlog_level_error,"d2char_findchar","got NULL account");
	return -1;
    }
    if (!charname) {
	eventlog(eventlog_level_error,"d2char_findchar","got NULL charname");
	return -1;
    }
    list=account_get_d2charlist(account);
    if (!list) return 0;
    if (!(temp=strdup(list))) {
	char const * tname;
	tname=account_get_name(account);
	eventlog(eventlog_level_error,"d2char_findchar","could not allocate memory for account %s charlist",tname);
	account_unget_name(tname);
	return -1;
    }
    for (tok=strtok(temp," ");tok;tok=strtok(NULL," ")) {
	if (strcasecmp(tok,charname)==0) {
	    free(temp);
	    return 1;
	}
    }
    free(temp);
    return 0;
}


extern int d2char_getnumber(t_account * account)
{
    char const * list;
    char * temp;
    char * tok;
    int number=0;

    if (!account) {
	eventlog(eventlog_level_error,"d2char_getnumber","got NULL account");
	return -1;
    }
    list=account_get_d2charlist(account);
    if (!list) return 0;
    if (!(temp=strdup(list))) {
	char const * tname;
	tname=account_get_name(account);
	eventlog(eventlog_level_error,"d2char_findchar","could not allocate memory for account %s charlist",tname);
	account_unget_name(tname);
	return -1;
    }
    for (tok=strtok(temp," ");tok;tok=strtok(NULL," ")) {
	number++;
    }
    free(temp);
    return number;
}


/* charinfo not very small,store them in memory or not after loaded	*/
extern t_d2char_info * d2char_getcharinfo(char const * charname)
{
    t_d2char_info * info;

/*  care the returning NULL here    */
/*  never use strlen and etc on NULL string before check */
/*  or SEGV will recieved	    */

    if (!charname) {
	eventlog(eventlog_level_error,"d2char_getcharinfo","got NULL charname");
	return NULL;
    }
    if (!prefs_get_d2savedir()) {
	eventlog(eventlog_level_debug,"d2char_getcharinfo","no d2save dir set,could not get charinfo");
	return NULL;
    }
    if (!(info=malloc(sizeof(t_d2char_info)))) {
	eventlog(eventlog_level_error,"d2char_getcharinfo","could not allocate memory for info");
	return NULL;
    }
    else {
	int fd;
	char * tempname;
	t_d2save * buffer;
	unsigned int size;
	unsigned int exp;
	unsigned short i;

	if (!(tempname=malloc(strlen(prefs_get_d2savedir())+1+strlen(charname)+1)))
	{
	    eventlog(eventlog_level_error,"d2char_getcharinfo","could not allocate tempname");
	    free(info);
	    return NULL;
	}
	sprintf (tempname,"%s/%s",prefs_get_d2savedir(),charname);
	if ((fd=open(tempname,O_RDONLY|O_BINARY))==-1) {
	    eventlog(eventlog_level_error,"d2char_getcharinfo","Error open char file %s (fopen:%s)",tempname,strerror(errno));
	    free(info);
	    free(tempname);
	    return NULL;
	}
	free(tempname);
	if (!(buffer=malloc(sizeof(t_d2save)))) {
	    eventlog(eventlog_level_error,"d2char_getcharinfo","could not allocate memory for buffer");
	    free(info);
	    close(fd);
	    return NULL;
	}
	size=read(fd,buffer,D2SAVE_MIN_SIZE);
	if (size!=D2SAVE_NEWBIE_SIZE && size!=D2SAVE_MIN_SIZE)
	{
	    eventlog(eventlog_level_error,"d2char_getcharinfo","got corrupt save file or read error(read:%s)",strerror(errno));
	    free(buffer);
	    free(info);
	    close(fd);
	    return NULL;
	}
	close(fd);
	memset(info,D2CHARFILE_PADBYTE,sizeof(t_d2char_info));
        bn_byte_set(&info->unknownb1,0x82);
	bn_byte_set(&info->unknownb2,0x80);
	for (i=0;i<sizeof(t_d2save_chargfx);i++) {
	    if (((char *)&buffer->gfx)[i]==0) continue;
	    else ((char *)&info->gfx)[i]=((char *)&buffer->gfx)[i];
	}
	for (i=0;i<sizeof(t_d2save_charcolor);i++) {
	    if (((char *)&buffer->color)[i]==0) continue;
	    else ((char *)&info->color)[i]=((char *)&buffer->color)[i];
	}
        bn_byte_set(&info->emblemnum,0x80);
	bn_byte_set(&info->unknownb14,0x80);
	bn_byte_set(&info->status,(unsigned char)(bn_byte_get(buffer->status)|0x80));
	bn_byte_set(&info->title,(unsigned char)((bn_byte_get(buffer->title)/4*8)|0x80));
	if (bn_byte_get(info->level)) bn_byte_set(&info->level,(unsigned char)bn_byte_get(buffer->level));
	bn_byte_set(&info->class,(unsigned char)(bn_byte_get(buffer->class)+1));
	bn_byte_set(&info->end,0x0);

	if (size==D2SAVE_NEWBIE_SIZE) exp=0;
	else {
	    unsigned int flag;
	    char    * data;
	    unsigned int reduce;

	    data=(char *)buffer;
	    flag=bn_short_get(&data[D2SAVE_FLAG_OFFSET]);
	    reduce=4*(4-((flag&0x80)/0x80+(flag&0x40)/0x40+(flag&0x20)/0x20+(flag&0x10)/0x10));
	    if (!(flag&D2SAVE_EXPFLAG_MASK)) exp=0;
	    else exp=bn_int_get(&data[D2SAVE_EXP_OFFSET-reduce]);
#ifdef DEBUG_D2GAME
	eventlog(eventlog_level_debug,"d2char_getcharinfo","char %s`s exp is %d,flag is %x(exp:%d skill:%d stat:%d",charname,exp,flag,flag&D2SAVE_EXPFLAG_MASK,flag&D2SAVE_SKILLFLAG_MASK,flag&D2SAVE_STATFLAG_MASK);
#endif
	}
	bn_int_set(&info->exp,exp);
	free(buffer);
    }
    return info;
}

extern int d2char_setcharinfo(char const * charname, char * charinfo)
{
    /* seems no need for now	*/
    return 0;

}


extern char const * d2char_getrealmname(char const * charname)
{
    /* now just to handle one realm */
    return "zixia";
}
    

static int d2char_create(char const * charname,unsigned short class,int type)
{
    int rfd,wfd;
    int nbyte;
    char * tempname;
    t_d2save * buffer;
    int start=1;
    char const * newbiefile;
    if (!charname) {
	eventlog(eventlog_level_error,"d2char_create","got NULL charname");
	return -1;
    }
    newbiefile=prefs_get_d2newbie();
    if (!newbiefile) {
	eventlog(eventlog_level_error,"d2char_create","no newbie file,can not creat char");
	return -1;
    }
    if ((rfd=open(newbiefile,O_RDONLY|O_BINARY))==-1) {
	eventlog(eventlog_level_error,"d2char_create","error open newbie file %s,can not creat char(open:%s)",newbiefile,strerror(errno));
	return -1;
    }
    
    if (!( tempname=malloc(strlen(prefs_get_d2savedir())+1+strlen(charname)+1))) {
	eventlog(eventlog_level_error,"d2char_create","could not allocate memory for tempname");
	close(rfd);
	return -1;
    }
    sprintf(tempname,"%s/%s",prefs_get_d2savedir(),charname);
    if ((wfd=open(tempname,O_WRONLY|O_TRUNC|O_CREAT|O_BINARY,S_IREAD|S_IWRITE))==-1) {
	eventlog(eventlog_level_error,"d2char_create","error open new char %s,can not creat char(open:%s)",tempname,strerror(errno));
	free(tempname);
	close(rfd);
	return -1;
    }
    free(tempname);
    if (!(buffer=malloc(sizeof(t_d2save)))) {
        eventlog(eventlog_level_error,"d2char_getcharinfo","could not allocate memory for buffer");
        return -1;
    }
    while ((nbyte=read(rfd,buffer,1024))>0) {
	if (start) {
	    strncpy(buffer->name,charname,CHAR_NAME_LEN);
	    bn_short_set(&buffer->class,class);
	    bn_byte_set(&buffer->status,(unsigned char)(type+1));
	    start=0;
	}
	write(wfd,buffer,nbyte);
    }
    free(buffer);
    close(rfd);
    close(wfd);
    return 0;
}

static int d2char_remove(char const * charname)
{
    char * filename;
    if (!prefs_get_d2savedir()) {
	eventlog(eventlog_level_error,"d2char_remove","no save dir defined");
    }
    if (!(filename=malloc(strlen(prefs_get_d2savedir())+1+strlen(charname)+1))) {
	eventlog(eventlog_level_error,"d2char_remove","could not allocate memory for filename");
	return -1;
    }
    sprintf (filename,"%s/%s",prefs_get_d2savedir(),charname);
    if (!prefs_get_d2removedir()) {
	if (unlink(filename)==-1) {
	    eventlog(eventlog_level_error,"d2char_remove","unlink %s failed(unlink:%s)",filename,strerror(errno));
	    free(filename);
	    return -1;
	}
	free(filename);
	return 0;
    }
    else {
	char *newname;
	if (!(newname=malloc(strlen(prefs_get_d2removedir())+1+strlen(charname)+1)))
	{
	    eventlog(eventlog_level_error,"d2char_remove","could not allocate memory for newname");
	    free(filename);
	    return -1;
	}
	sprintf(newname,"%s/%s",prefs_get_d2removedir(),charname);
	unlink(newname);
	if (rename(filename,newname)==-1) {
	    eventlog(eventlog_level_error,"d2char_remove","rename %s to %s failed(rename:%s)",filename,newname,strerror(errno));
	    free(filename);
	    free(newname);
	    return -1;
	}
	else {
	    free(filename);
	    free(newname);
	    return 0;
	}
    }
	
}


extern unsigned int d2char_getlevel(char const * charname)
{
    t_connection * conn;
    t_d2char_info * info;
    unsigned int level;
    if (!charname) {
	eventlog(eventlog_level_error,"d2char_getlevel","got NULL charname");
	return 0;
    }
    if (!(conn=connlist_find_connection_by_charname(charname))) {
	eventlog(eventlog_level_error,"d2char_getlevel","got NULL connection");
	return 0;
    }
    if (!(info=(t_d2char_info *) conn_get_charinfo(conn))) {
	eventlog(eventlog_level_error,"d2char_getlevel","got NULL charinfo");
	return 0;
    }
    else {
	level=bn_byte_get(info->level);
	return level;
    }
}

extern unsigned int d2char_getclass(char const * charname)
{
    t_connection * conn;
    t_d2char_info * info;
    unsigned int class;
    if (!charname) {
	eventlog(eventlog_level_error,"d2char_getclass","got NULL class");
	return 0;
    }
    if (!(conn=connlist_find_connection_by_charname(charname))) {
	eventlog(eventlog_level_error,"d2char_getclass","got NULL connection");
	return 0;
    }
    if (!(info=(t_d2char_info *) conn_get_charinfo(conn))) {
	eventlog(eventlog_level_error,"d2char_getclass","got NULL charinfo");
	return 0;
    }
    else {
	class=bn_byte_get(info->class)-1;
	if (class>4) return 0;
	else return class;
    }
}

extern unsigned int d2char_gethardcore(char const * charname)
{
    t_connection * conn;
    t_d2char_info * info;
    unsigned int status;
    if (!charname) {
	eventlog(eventlog_level_error,"d2char_gethardcore","got NULL connection");
	return 0;
    }
    if (!(conn=connlist_find_connection_by_charname(charname))) {
	eventlog(eventlog_level_error,"d2char_gethardcore","got NULL connection");
	return 0;
    }
    if (!(info=(t_d2char_info *) conn_get_charinfo(conn))) {
	eventlog(eventlog_level_error,"d2char_gethardcore","got NULL charinfo");
	return 0;
    }
    else {
	status=bn_byte_get(info->status);
	return (status&0xf)/4;
    }
}

extern unsigned int d2char_gettitle(char const * charname)
{
    t_connection * conn;
    t_d2char_info * info;
    unsigned int title;

    if (!charname) {
	eventlog(eventlog_level_error,"d2char_gethardcore","got NULL connection");
	return 0;
    }
    if (!(conn=connlist_find_connection_by_charname(charname))) {
	eventlog(eventlog_level_error,"d2char_gethardcore","got NULL connection");
	return 0;
    }
    if (!(info=(t_d2char_info *) conn_get_charinfo(conn))) {
	eventlog(eventlog_level_error,"d2char_gethardcore","got NULL charinfo");
	return 0;
    }
    else {
	title=(bn_byte_get(info->title)&0x1f)*2;
	return title;
    }
}
