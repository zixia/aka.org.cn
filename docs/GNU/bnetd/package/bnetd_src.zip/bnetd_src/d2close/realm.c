/*
 * Copyright (C) 2000  Onlyer (onlyer@263.net)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#include "config.h"
#include "setup.h"
#include <stdio.h>
#include <ctype.h>  
#include <errno.h>      

#define USE_STDDEF_HEADERS
#define USE_STDC_HEADERS
#define USE_STRING_HEADERS
#define USE_FCNTL_HEADERS
#define USE_UNISTD_HEADERS
#define USE_SYS_TYPES_HEADERS

#include "compat.h"

#include "compat/strerror.h"
#include "compat/strcasecmp.h"
#include "message.h"        
#include "connection.h" 
#include "util.h"       
#include "eventlog.h"
#include "account.h"
#include "prefs.h"
#include "tag.h"
#include "d2charfile.h"
#include "realm.h"


extern char * realm_get_playerinfo(t_connection * c,char const * charname)
{
	char * info;
	char const * clienttag;

	if (!c) {
		eventlog(eventlog_level_error,"realm_get_playerinfo","Get NULL connection");
		return NULL;
	}
	clienttag=conn_get_clienttag(c);
	if (!clienttag || strlen(clienttag) !=4 ) {
	    eventlog(eventlog_level_debug,"realm_get_playerinfo","got bad clienttag");
	    return NULL;
	}
	if (strcmp(clienttag,CLIENTTAG_DIABLOII)==0) {
		info=(char *)d2char_getcharinfo(charname);
	}
	else {
		eventlog(eventlog_level_debug,"realm_get_playerinfo","can not get realm playerinfo for clienttag %s",conn_get_clienttag(c));
		info = NULL;
	}
	return info;
}


extern char const * realm_get_playerlist(t_connection * c)
{
    char const * list;
    char const * clienttag;

    if (!c) {
	eventlog(eventlog_level_error,"realm_get_playerlist","Get NULL connection");
	return NULL;
    }
    clienttag=conn_get_clienttag(c);
    if (!clienttag || strlen(clienttag) !=4 ) {
        eventlog(eventlog_level_debug,"realm_get_playerlist","got bad clienttag");
    return NULL;
    }
    if (strcmp(clienttag,CLIENTTAG_DIABLOII)==0) {
	    list=account_get_d2charlist(conn_get_account(c));
    }
    else {
	    eventlog(eventlog_level_debug,"realm_get_playerlist","can not get playerlist for clienttag %s",conn_get_clienttag(c));
	    list=NULL;
    }
    return list;
}
