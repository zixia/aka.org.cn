/*
 * Copyright (C) 1998  Mark Baysinger (mbaysing@ucsd.edu)
 * Copyright (C) 1998,1999,2000  Ross Combs (rocombs@cs.nmsu.edu)
 * Copyright (C) 1999  Gediminas (gediminas_lt@mailexcite.com)
 * Copyright (C) 1999  Rob Crittenden (rcrit@greyoak.com)
 * Copyright (C) 2000  Marco Ziech (mmz@gmx.net)
 * Copyright (C) 2000  Dizzy (dizzy@media2000.kappa.ro)
 * Copyright (C) 2000  Onlyer (onlyer@263.net)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#include "config.h"
#include "setup.h"
#include <stdio.h>
#include <ctype.h>
#include <errno.h>

#define USE_STDDEF_HEADERS
#define USE_STDC_HEADERS
#define USE_STRING_HEADERS
#define USE_TIME_HEADERS
#define USE_SOCKET_HEADERS

#include "compat.h"

#include "compat/strtoul.h"
#include "compat/strdup.h"
#include "compat/strcasecmp.h"
#include "compat/strerror.h"
#include "compat/strftime.h"
#include "list.h"
#include "message.h"
#include "tag.h"
#include "connection.h"
#include "channel.h"
#include "game.h"
#include "util.h"
#include "version.h"
#include "account.h"
#include "server.h"
#include "prefs.h"
#include "eventlog.h"
#include "ladder.h"
#include "timer.h"
#include "bnettime.h"
#include "addr.h"
#include "gametrans.h"
#include "helpfile.h"
#include "bnethash.h"
#include "runprog.h"
#include "command.h"
#include "chatcmd.h"
#include "handle_auth.h"
#include "d2game.h"
#include "d2server.h"


static char const * bnclass_get_str(unsigned int class);
static void do_whisper(t_connection * user_c, char const * dest, char const * text);
static void do_whois(t_connection * c, char const * dest);
static void user_timer_cb(t_connection * c, time_t now, t_timer_data str);


static char const * bnclass_get_str(unsigned int class)
{
    switch (class)
    {
    case PLAYERINFO_DRTL_CLASS_WARRIOR:
	return "warrior";
    case PLAYERINFO_DRTL_CLASS_ROGUE:
	return "rogue";
    case PLAYERINFO_DRTL_CLASS_SORCERER:
	return "sorcerer";
    default:
	return "unknown";
    }
}


static void do_whisper(t_connection * user_c, char const * dest, char const * text)
{
    t_connection * dest_c;
    char           temp[MAX_MESSAGE_LEN];
    char const *   tname;
    
    if (!(dest_c = connlist_find_connection(dest)))
    {
	message_send(user_c,MT_ERROR,user_c,"That user is not logged on.");
	return;
    }
    
    if (conn_get_dndstr(dest_c))
    {
        sprintf(temp,"%.64s is unavaliable (%.128s)",(tname = conn_get_username(dest_c)),conn_get_dndstr(dest_c));
	conn_unget_username(dest_c,tname);
        message_send(user_c,MT_WARN,user_c,temp);
        return;
    }
    
    message_send(user_c,MT_WHISPERACK,dest_c,text);
    
    if (conn_get_awaystr(dest_c))
    {
        sprintf(temp,"%.64s is away (%.128s)",(tname = conn_get_username(dest_c)),conn_get_awaystr(dest_c));
	conn_unget_username(dest_c,tname);
        message_send(user_c,MT_WARN,user_c,temp);
    }
    
    message_send(dest_c,MT_WHISPER,user_c,text);
    {
	tname=conn_get_username(user_c);
	conn_set_replyto(dest_c,tname);
	conn_unget_username(dest_c,tname);
    }
    return;
}

static void do_whois(t_connection * c, char const * dest)
{
    t_connection *    dest_c;
    char              namepart[128];
    char              temp[MAX_MESSAGE_LEN];
    char const *      verb;
    t_game const *    game;
    t_channel const * channel;
    
    if (!(dest_c = connlist_find_connection(dest)))
    {
	message_send(c,MT_ERROR,c,"That user is not logged on.");
	return;
    }
    
    if (c==dest_c)
    {
	strcpy(namepart,"You");
	verb = "are";
    }
    else
    {
	char const * tname;
	char const * charname;
	
	if ((charname=conn_get_charname(dest_c))) {
	  sprintf(namepart,"%.64s (%.64s)",(tname = conn_get_username(dest_c)),charname);
	}
	else sprintf(namepart,"%.64s",(tname = conn_get_username(dest_c)));
	conn_unget_username(dest_c,tname);
	verb = "is";
    }


    if (conn_get_bind(dest_c) && conn_get_class(dest_c)==conn_class_normal) 
	game=conn_get_game(conn_get_bind(dest_c));
    else game=conn_get_game(dest_c);
	
    
    if (game)
    {
	if (strcmp(game_get_pass(game),"")==0)
	    sprintf(temp,"%s %s logged on from account "UID_FORMAT", and %s currently in game \"%.64s\".",
		    namepart,
		    verb,
		    conn_get_userid(dest_c),
		    verb,
		    game_get_name(game));
	else
	    sprintf(temp,"%s %s logged on from account "UID_FORMAT", and %s currently in private game \"%.64s\".",
		    namepart,
		    verb,
		    conn_get_userid(dest_c),
		    verb,
		    game_get_name(game));
    }
    else if ((channel = conn_get_channel(dest_c)))
    {
	if (channel_get_permanent(channel)==1)
            sprintf(temp,"%s %s logged on from account "UID_FORMAT", and %s currently in the channel \"%.64s\".",
		    namepart,
		    verb,
		    conn_get_userid(dest_c),
		    verb,
		    channel_get_name(channel));
	else
            sprintf(temp,"%s %s logged on from account "UID_FORMAT", and %s currently in the private channel \"%.64s\".",
		    namepart,
		    verb,
		    conn_get_userid(dest_c),
		    verb,
		    channel_get_name(channel));
    }
    else
	sprintf(temp,"%s %s logged on from account "UID_FORMAT".",
		namepart,
		verb,
		conn_get_userid(dest_c));
    message_send(c,MT_WARN,c,temp);
    if (game && strcmp(game_get_pass(game),"")!=0)
	message_send(c,MT_WARN,c,"(This game is password protected.)");
    
    if (conn_get_dndstr(dest_c))
    {
        sprintf(temp,"%s %s refusing messages (%.128s)",
		namepart,
		verb,
		conn_get_dndstr(dest_c));
	message_send(c,MT_WARN,c,temp);
    }
    else
        if (conn_get_awaystr(dest_c))
        {
            sprintf(temp,"%s away (%.128s)",
		    namepart,
		    conn_get_awaystr(dest_c));
	    message_send(c,MT_WARN,c,temp);
        }
}


static void user_timer_cb(t_connection * c, time_t now, t_timer_data str)
{
    if (!c)
    {
	eventlog(eventlog_level_error,"user_timer_cb","got NULL connection");
	return;
    }
    if (!str.p)
    {
	eventlog(eventlog_level_error,"user_timer_cb","got NULL str");
	return;
    }
    
    if (now!=(time_t)0) /* zero means user logged out before expiration */
	message_send(c,MT_WARN,c,str.p);
    free(str.p);
}


extern int handle_command(t_connection * c,  char const * text)
{

    if (strstart(text,"/nt")==0)
    {
        unsigned int i;
	t_bnettime   bnt;
	
        for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
        for (; text[i]==' '; i++); /* skip spaces */
	
	bnettime_set_str(&bnt,&text[i]);
        message_send(c,MT_WARN,c,&text[i]);
	
	account_set_normal_last_time(conn_get_account(c),conn_get_clienttag(c),bnt);
	
        return 0;
    }
    if (strstart(text,"/me")==0)
    {
	t_channel const * channel;
	unsigned int      i;
	
        if (!(channel = conn_get_channel(c)))
	{
	    message_send(c,MT_ERROR,c,"You are not in a channel.");
	    return 0;
	}
        
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
	for (; text[i]==' '; i++); /* skip spaces */
	
	channel_message_send(channel,MT_EMOTE,c,&text[i]);
	return 0;
    }
    if (strstart(text,"/msg")==0 ||
	strstart(text,"/whisper")==0 ||
	strstart(text,"/w")==0 ||
	strstart(text,"/m")==0)
    {
	char         dest[USER_NAME_LEN];
	unsigned int i,j;
	
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
	for (; text[i]==' '; i++);
	for (j=0; text[i]!=' ' && text[i]!='\0'; i++) /* get dest */
	    if (j<sizeof(dest)-1) dest[j++] = text[i];
	dest[j] = '\0';
	
	if (text[i]=='\0')
	{
	    message_send(c,MT_ERROR,c,"What do you want to say?");
	    return 0;
	}
	
	for (; text[i]==' '; i++);
	do_whisper(c,dest,&text[i]);
	
	return 0;
    }
    if (strstart(text,"/reply")==0 ||
	strstart(text,"/r")==0 )
    {
	unsigned int i;
	char const * dest;
	if (!(dest=conn_get_replyto(c))) {
	    message_send(c,MT_ERROR,c,"No one messaged you,use /m instead");
	    return 0;
	}
        for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
	for (; text[i]==' '; i++);
	if (text[i]=='\0') {
	    message_send(c,MT_ERROR,c,"What do you want to reply?");
	    return 0;
	}
	do_whisper(c,dest,&text[i]);
	return 0;
    }


    if (strstart(text,"/status")==0 || strstart(text,"/users")==0)
    {
	char msgtemp[MAX_MESSAGE_LEN];
	unsigned int debug;
	
	sprintf(msgtemp,"There are currently %d users online, in %d games and %d channels.",
		connlist_login_get_length(),
		gamelist_get_length(),
		channellist_get_length());
	debug=connlist_login_get_length();
	message_send(c,MT_WARN,c,msgtemp);
	
	return 0;
    }
    if (strstart(text,"/who")==0)
    {
	char                 msgtemp[MAX_MESSAGE_LEN];
	t_connection const * conn;
	t_connection const * bound;
	t_channel const *    channel;
	unsigned int         i;
	char const *         tname;
	t_elem const *	     elem;	  


	for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
	for (; text[i]==' '; i++);
	
	if (strcasecmp(&text[i],"local")==0) {
		char		  info[CHAR_NAME_LEN+USER_NAME_LEN+3];

		message_send(c,MT_WARN,c,"Locally loggedin players:");

		i=0;
		LIST_TRAVERSE_DATA_CONST(connlist(),elem,conn)
		{
		    if (conn_get_class(conn)==conn_class_auth) continue;
		    bound=conn_get_bind(conn);
		    if (bound) {
			sprintf (info,"%s(%s)",conn_get_username(conn),conn_get_charname(bound));
		    }
		    else sprintf (info,"%s(%s)",conn_get_username(conn),conn_get_clienttag(conn));
		    if (i+strlen(info)+2>sizeof(msgtemp)) {
			message_send(c,MT_WARN,c,msgtemp);
			i=0;
		    }
		    if (i==0) sprintf(&msgtemp[i],"%s",info);
		    else sprintf(&msgtemp[i],",%s",info);
		    i += strlen(&msgtemp[i]);
		}
		if (i>0) message_send(c,MT_WARN,c,msgtemp);
		return 0;
	}	

	if (!(channel = channellist_find_channel(&text[i])))
	{
	    message_send(c,MT_ERROR,c,"That channel does not exist.");
	    message_send(c,MT_ERROR,c,"(If you are trying to search for a user, use the /whois command.)");
	    return 0;
	}
	if (channel_check_banning(channel,c)==1)
	{
	    message_send(c,MT_ERROR,c,"You are banned from that channel.");
	    return 0;
	}
	
	sprintf(msgtemp,"Users in channel %.64s:",&text[i]);
        message_send(c,MT_WARN,c,msgtemp);
	i = 0;
	for (conn=channel_get_first(channel); conn; conn=channel_get_next())
	{
	    if (i+strlen((tname = conn_get_username(conn)))+2>sizeof(msgtemp)) /* ",", name, '\0' */
	    {
		message_send(c,MT_WARN,c,msgtemp);
		i = 0;
	    }
	    if (i==0) sprintf(&msgtemp[i],"%s",tname);
	    else sprintf(&msgtemp[i],",%s",tname);
	    conn_unget_username(conn,tname);
	    i += strlen(&msgtemp[i]);
	}
	if (i>0)
	    message_send(c,MT_WARN,c,msgtemp);
	
	return 0;
    }
    if (strstart(text,"/whois")==0 || strstart(text,"/whereis")==0 || strstart(text,"/where")==0)
    {
	unsigned int i;
	
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
	for (; text[i]==' '; i++);
	
	do_whois(c,&text[i]);
	
	return 0;
    }
    if (strstart(text,"/whoami")==0)
    {
	char const * tname;
	
	if (!(tname = conn_get_username(c)))
	{
	    message_send(c,MT_ERROR,c,"Unable to obtain your account name.");
	    return 0;
	}
	
	do_whois(c,tname);
	conn_unget_username(c,tname);
	
	return 0;
    }
    if (strstart(text,"/announce")==0)
    {
	char         msgtemp[MAX_MESSAGE_LEN];
	unsigned int i;
	char const * tname;
	
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
	for (; text[i]==' '; i++);
	
	if (account_get_auth_announce(conn_get_account(c))!=1) /* default to false */
	{
	    message_send(c,MT_WARN,c,"You do not have permission to use this command.");
	    return 0;
	}
	
	sprintf(msgtemp,"Announcement from %.64s: %.128s",(tname = conn_get_username(c)),&text[i]);
	conn_unget_username(c,tname);
	message_send_all(MT_BROADCAST,c,msgtemp);
	
	return 0;
    }
    if (strstart(text,"/beep")==0)
    {
	message_send(c,MT_WARN,c,"Audible notification on."); /* FIXME: actually do something */
	return 0;
    }
    if (strstart(text,"/nobeep")==0)
    {
	message_send(c,MT_WARN,c,"Audible notification off."); /* FIXME: actually do something */
	return 0;
    }
    if (strstart(text,"/version")==0)
    {
	message_send(c,MT_WARN,c,"BNETD " BNETD_VERSION);
	
	return 0;
    }
    if (strstart(text,"/copyright")==0 || strstart(text,"/warranty")==0 || strstart(text,"/license")==0)
    {
	static char const * const info[] =
	{
	    " This program is free software; you can redistribute it and/or",
	    " modify it under the terms of the GNU General Public License",
	    " as published by the Free Software Foundation; either version 2",
	    " of the License, or (at your option) any later version.",
	    " ",
	    " This program is distributed in the hope that it will be useful,",
	    " but WITHOUT ANY WARRANTY; without even the implied warranty of",
	    " MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the",
	    " GNU General Public License for more details.",
	    " ",
	    " You should have received a copy of the GNU General Public License",
	    " along with this program; if not, write to the Free Software",
	    " Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.",
	    NULL
	};
	unsigned int i;
	
	for (i=0; info[i]; i++)
		message_send(c,MT_WARN,c,info[i]);
	
	return 0;
    }
    if (strstart(text,"/uptime")==0)
    {
	char msgtemp[MAX_MESSAGE_LEN];
	
	sprintf(msgtemp,"Uptime: %s",seconds_to_timestr(server_get_uptime()));
	message_send(c,MT_WARN,c,msgtemp);
	
	return 0;
    }
    if (strstart(text,"/stats")==0 || strstart(text,"/astat")==0)
    {
	char         msgtemp[MAX_MESSAGE_LEN];
	char         dest[USER_NAME_LEN];
	unsigned int i,j;
	t_account *  account;
	char const * clienttag;
	char const * tname;
	
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
	for (; text[i]==' '; i++);
	for (j=0; text[i]!=' ' && text[i]!='\0'; i++) /* get dest */
	    if (j<sizeof(dest)-1) dest[j++] = text[i];
	dest[j] = '\0';
	for (; text[i]==' '; i++);
	
	if (dest[0]=='\0') /* if no argument, stat ourself */
	{
	    strcpy(dest,(tname = conn_get_username(c)));
	    conn_unget_username(c,tname);
	}
	
	if (!(account = accountlist_find_account(dest)))
	{
	    message_send(c,MT_ERROR,c,"Invalid user.");
	    return 0;
	}

	if (text[i]!='\0')
	    clienttag = &text[i];
	else if (!(clienttag = conn_get_clienttag(c)))
	{
	    message_send(c,MT_ERROR,c,"Unable to determine client game.");
	    return 0;
	}
	
	if (strlen(clienttag)!=4)
	{
	    sprintf(msgtemp,"You must supply a user name and a valid program ID. (Program ID \"%.32s\" is invalid.)",clienttag);
	    message_send(c,MT_ERROR,c,msgtemp);
	    message_send(c,MT_ERROR,c,"Example: /stats joe STAR");
	    return 0;
	}
	
	if (strcasecmp(clienttag,CLIENTTAG_BNCHATBOT)==0)
	{
	    message_send(c,MT_ERROR,c,"This game does not support win/loss records.");
	    message_send(c,MT_ERROR,c,"You must supply a user name and a valid program ID.");
	    message_send(c,MT_ERROR,c,"Example: /stats joe STAR");
	    return 0;
	}
	else if (strcasecmp(clienttag,CLIENTTAG_DIABLORTL)==0 ||
	         strcasecmp(clienttag,CLIENTTAG_DIABLOSHR)==0)
	{
	    sprintf(msgtemp,"%.64s's record:",(tname = account_get_name(account)));
	    account_unget_name(tname);
	    message_send(c,MT_WARN,c,msgtemp);
	    
	    sprintf(msgtemp,"level: %u",account_get_normal_level(account,clienttag));
	    message_send(c,MT_WARN,c,msgtemp);
	    
	    sprintf(msgtemp,"class: %.16s",bnclass_get_str(account_get_normal_class(account,clienttag)));
	    
	    message_send(c,MT_WARN,c,msgtemp);
	    
	    sprintf(msgtemp,"stats: %u str  %u mag  %u dex  %u vit  %u gld",
		    account_get_normal_strength(account,clienttag),
		    account_get_normal_magic(account,clienttag),
		    account_get_normal_dexterity(account,clienttag),
		    account_get_normal_vitality(account,clienttag),
		    account_get_normal_gold(account,clienttag));
	    message_send(c,MT_WARN,c,msgtemp);
	    
	    sprintf(msgtemp,"Diablo kills: %u",account_get_normal_diablo_kills(account,clienttag));
	    message_send(c,MT_WARN,c,msgtemp);
	}
	else if (strcasecmp(clienttag,CLIENTTAG_WARCIIBNE)==0)
	{
	    sprintf(msgtemp,"%.64s's record:",(tname = account_get_name(account)));
	    account_unget_name(tname);
	    message_send(c,MT_WARN,c,msgtemp);
	    
	    sprintf(msgtemp,"Normal games: %d-%d-%d",
		    account_get_normal_wins(account,clienttag),
		    account_get_normal_losses(account,clienttag),
		    account_get_normal_disconnects(account,clienttag));
	    message_send(c,MT_WARN,c,msgtemp);
	    
	    if (account_get_ladder_rating(account,clienttag,ladder_id_normal)>0)
		sprintf(msgtemp,"Ladder games: %d-%d-%d (rating %d)",
			account_get_ladder_wins(account,clienttag,ladder_id_normal),
			account_get_ladder_losses(account,clienttag,ladder_id_normal),
			account_get_ladder_disconnects(account,clienttag,ladder_id_normal),
			account_get_ladder_rating(account,clienttag,ladder_id_normal));
	    else
		strcpy(msgtemp,"Ladder games: 0-0-0");
	    message_send(c,MT_WARN,c,msgtemp);
	    
	    if (account_get_ladder_rating(account,clienttag,ladder_id_ironman)>0)
		sprintf(msgtemp,"IronMan games: %d-%d-%d (rating %d)",
			account_get_ladder_wins(account,clienttag,ladder_id_ironman),
			account_get_ladder_losses(account,clienttag,ladder_id_ironman),
			account_get_ladder_disconnects(account,clienttag,ladder_id_ironman),
			account_get_ladder_rating(account,clienttag,ladder_id_ironman));
	    else
		strcpy(msgtemp,"IronMan games: 0-0-0");
	    message_send(c,MT_WARN,c,msgtemp);
	}
	else
	{
	    sprintf(msgtemp,"%.64s's record:",(tname = account_get_name(account)));
	    account_unget_name(tname);
	    message_send(c,MT_WARN,c,msgtemp);
	    
	    sprintf(msgtemp,"Normal games: %d-%d-%d",
		    account_get_normal_wins(account,clienttag),
		    account_get_normal_losses(account,clienttag),
		    account_get_normal_disconnects(account,clienttag));
	    message_send(c,MT_WARN,c,msgtemp);
	    
	    if (account_get_ladder_rating(account,clienttag,ladder_id_normal)>0)
		sprintf(msgtemp,"Ladder games: %d-%d-%d (rating %d)",
			account_get_ladder_wins(account,clienttag,ladder_id_normal),
			account_get_ladder_losses(account,clienttag,ladder_id_normal),
			account_get_ladder_disconnects(account,clienttag,ladder_id_normal),
			account_get_ladder_rating(account,clienttag,ladder_id_normal));
	    else
		strcpy(msgtemp,"Ladder games: 0-0-0");
	    message_send(c,MT_WARN,c,msgtemp);
	}
	
	return 0;
    }
    if (strstart(text,"/time")==0)
    {
	char        msgtemp[MAX_MESSAGE_LEN];
	time_t      now;
	struct tm * tmnow;
	
	now = time(NULL);
	
	/* Battle.net time: Wed Jun 23 15:15:29 */
	tmnow = gmtime(&now);
	strftime(msgtemp,sizeof(msgtemp),"BNETD time: %a %b %d %H:%M:%S %Z",tmnow);
	message_send(c,MT_WARN,c,msgtemp);
	if (conn_get_class(c)==conn_class_normal)
	{
	    tmnow = localtime(&now); /* FIXME: determine user's timezone */
	    strftime(msgtemp,sizeof(msgtemp),"Your local time: %a %b %d %H:%M:%S",tmnow);
	    message_send(c,MT_WARN,c,msgtemp);
	}
	
	return 0;
    }
    if (strstart(text,"/channel")==0 || strstart(text,"/join")==0)
    {
	unsigned int i;
        
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
	for (; text[i]==' '; i++);
        
        if (text[i]=='\0')
	{
	    message_send(c,MT_ERROR,c,"Please specify a channel.");
	    return 0;
	}
        
        if (conn_set_channel(c,&text[i])<0)
            conn_set_channel(c,CHANNEL_NAME_BANNED); /* should not fail */
        
	return 0;
    }
    if (strstart(text,"/rejoin")==0)
    {
	t_channel const * channel;
	char const *      temp;
	char const *      chname;
	
        if (!(channel = conn_get_channel(c)))
	{
	    message_send(c,MT_ERROR,c,"You are not in a channel.");
	    return 0;
	}
        
	if (!(temp = channel_get_name(channel)))
	    return 0;
	
	/* we need to copy the channel name because we might remove the
	   last person (ourself) from the channel and cause the string
	   to be freed in destroy_channel() */
	if ((chname = strdup(temp)))
	{
	    if (conn_set_channel(c,chname)<0)
        	conn_set_channel(c,CHANNEL_NAME_BANNED); /* should not fail */
	    free((void *)chname);
	}
	
	return 0;
    }
    if (strstart(text,"/away")==0)
    {
	unsigned int i;
	
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
	for (; text[i]==' '; i++);
	
	if (text[i]=='\0') /* back to normal */
	{
	    message_send(c,MT_WARN,c,"You are no longer marked as away.");
	    conn_set_awaystr(c,NULL);
	}
	else
	{
	    message_send(c,MT_WARN,c,"You are now marked as being away.");
	    conn_set_awaystr(c,&text[i]);
	}
	
	return 0;
    }
    if (strstart(text,"/dnd")==0)
    {
	unsigned int i;
	
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
	for (; text[i]==' '; i++);
	
	if (text[i]=='\0') /* back to normal */
	{
	    message_send(c,MT_WARN,c,"Do Not Disturb mode cancelled.");
	    conn_set_dndstr(c,NULL);
	}
	else
	{
	    message_send(c,MT_WARN,c,"Do Not Disturb mode engaged.");
	    conn_set_dndstr(c,&text[i]);
	}
	
	return 0;
    }
    if (strstart(text,"/ignore")==0 || strstart(text,"/squelch")==0)
    {
	char         msgtemp[MAX_MESSAGE_LEN];
	unsigned int i;
	t_account *  account;
	
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
	for (; text[i]==' '; i++);
	
	if (text[i]=='\0')
	{
	    message_send(c,MT_WARN,c,"Who do you want to ignore?");
	    return 0;
	}
	
	if (!(account = accountlist_find_account(&text[i])))
	{
	    message_send(c,MT_ERROR,c,"No such user.");
	    return 0;
	}
	
	if (conn_get_account(c)==account)
	{
	    message_send(c,MT_ERROR,c,"You can't squelch yourself.");
	    return 0;
	}
	
	if (conn_add_ignore(c,account)<0)
	    message_send(c,MT_ERROR,c,"Could not squelch user.");
	else
	{
	    char const * tname;
	    
	    sprintf(msgtemp,"%-.20s has been squelched.",(tname = account_get_name(account)));
	    account_unget_name(tname);
	    message_send(c,MT_WARN,c,msgtemp);
	}
	
	return 0;
    }
    if (strstart(text,"/unignore")==0 || strstart(text,"/unsquelch")==0)
    {
	unsigned int      i;
        t_account const * account;
	
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
	for (; text[i]==' '; i++);
	
	if (text[i]=='\0')
        {
	    message_send(c,MT_WARN,c,"Who don't you want to ignore?");
	    return 0;
	}
	
        if (!(account = accountlist_find_account(&text[i])))
	{
	    message_send(c,MT_WARN,c,"No such user.");
	    return 0;
	}
	
	if (conn_del_ignore(c,account)<0)
	    message_send(c,MT_WARN,c,"User was not being ignored.");
	else
	    message_send(c,MT_WARN,c,"No longer ignoring.");
	
	return 0;
    }
    if (strstart(text,"/designate")==0)
    {
	char           msgtemp[MAX_MESSAGE_LEN];
	unsigned int   i;
	t_channel *    channel;
        t_connection * noc;
	
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
	for (; text[i]==' '; i++);
	
	if (text[i]=='\0')
        {
	    message_send(c,MT_WARN,c,"Who do you want to designate?");
	    return 0;
	}
	
        if (!(channel = conn_get_channel(c)))
        {
            message_send(c,MT_ERROR,c,"This command can only be used inside a channel.");
	    return 0;
        }
	if (account_get_auth_admin(conn_get_account(c))!=1 && /* default to false */
            channel_get_operator(channel)!=c)
        {
            message_send(c,MT_ERROR,c,"You are not a channel operator.");
	    return 0;
        }
        if (!(noc = connlist_find_connection(&text[i])))
        {
            message_send(c,MT_ERROR,c,"That user is not logged in.");
	    return 0;
        }
        if (conn_get_channel(noc)!=channel)
        {
            message_send(c,MT_ERROR,c,"That user is not in this channel.");
            return 0;
        }
        
        if (channel_set_next_operator(channel,noc)<0)
            message_send(c,MT_ERROR,c,"Unable to designate that user.");
        else
        {
	    char const * tname;
	    
            sprintf(msgtemp,"%s will be the new operator when you resign.",(tname = conn_get_username(noc)));
	    conn_unget_username(noc,tname);
            message_send(c,MT_WARN,c,msgtemp);
        }
	
        return 0;
    }
    if (strstart(text,"/resign")==0)
    {
	t_channel *    channel;
	
        if (!(channel = conn_get_channel(c)))
        {
            message_send(c,MT_ERROR,c,"This command can only be used inside a channel.");
	    return 0;
        }
        if (channel_get_operator(channel)!=c)
        {
            message_send(c,MT_ERROR,c,"This command is reserved for channel operators.");
	    return 0;
        }
        
        if (channel_choose_operator(channel,NULL)<0)
            message_send(c,MT_ERROR,c,"You are unable to resign.");
        else
            message_send(c,MT_WARN,c,"You are no longer the operator.");
        
	return 0;
    }
    if (strstart(text,"/kick")==0)
    {
	char              msgtemp[MAX_MESSAGE_LEN];
	char              dest[USER_NAME_LEN];
	unsigned int      i,j;
	t_channel const * channel;
        t_connection *    kuc;
	
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
	for (; text[i]==' '; i++);
	for (j=0; text[i]!=' ' && text[i]!='\0'; i++) /* get dest */
	    if (j<sizeof(dest)-1) dest[j++] = text[i];
	dest[j] = '\0';
	for (; text[i]==' '; i++);
	
	if (dest[0]=='\0')
        {
	    message_send(c,MT_WARN,c,"Who do you want to kick off the channel?");
	    return 0;
	}
	
        if (!(channel = conn_get_channel(c)))
        {
            message_send(c,MT_ERROR,c,"This command can only be used inside a channel.");
	    return 0;
        }
	if (account_get_auth_admin(conn_get_account(c))!=1 && /* default to false */
            channel_get_operator(channel)!=c)
        {
            message_send(c,MT_ERROR,c,"You are not a channel operator.");
	    return 0;
        }
        if (!(kuc = connlist_find_connection(dest)))
        {
            message_send(c,MT_ERROR,c,"That user is not logged in.");
	    return 0;
        }
        if (conn_get_channel(kuc)!=channel)
        {
            message_send(c,MT_ERROR,c,"That user is not in this channel.");
            return 0;
        }
        
        {
	    char const * tname1;
	    char const * tname2;
	    
	    tname1 = account_get_name(conn_get_account(kuc));
	    tname2 = account_get_name(conn_get_account(c));
	    if (text[i]!='\0')
        	sprintf(msgtemp,"%-.20s has been kicked by %-.20s (%s).",tname1,tname2?tname2:"unknown",&text[i]);
	    else
        	sprintf(msgtemp,"%-.20s has been kicked by %-.20s.",tname1,tname2?tname2:"unknown");
	    if (tname2)
		account_unget_name(tname2);
	    if (tname1)
		account_unget_name(tname1);
            channel_message_send(channel,MT_WARN,c,msgtemp);
        }
        conn_set_channel(kuc,CHANNEL_NAME_KICKED); /* should not fail */
        
        return 0;
    }
    if (strstart(text,"/ban")==0)
    {
	char           msgtemp[MAX_MESSAGE_LEN];
	char           dest[USER_NAME_LEN];
	unsigned int   i,j;
	t_channel *    channel;
        t_connection * buc;
	
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
	for (; text[i]==' '; i++);
	for (j=0; text[i]!=' ' && text[i]!='\0'; i++) /* get dest */
	    if (j<sizeof(dest)-1) dest[j++] = text[i];
	dest[j] = '\0';
	for (; text[i]==' '; i++);
	
	if (dest[0]=='\0')
        {
	    message_send(c,MT_WARN,c,"Who do you want to ban from the channel?");
	    return 0;
	}
	
        if (!(channel = conn_get_channel(c)))
        {
            message_send(c,MT_ERROR,c,"This command can only be used inside a channel.");
	    return 0;
        }
	if (account_get_auth_admin(conn_get_account(c))!=1 && /* default to false */
            channel_get_operator(channel)!=c)
        {
            message_send(c,MT_ERROR,c,"You are not a channel operator.");
	    return 0;
        }
        
        if (channel_ban_user(channel,dest)<0)
	{
            sprintf(msgtemp,"Unable to ban %-.20s.",dest);
            message_send(c,MT_ERROR,c,msgtemp);
	}
        else
        {
	    char const * tname;
	    
	    tname = account_get_name(conn_get_account(c));
	    if (text[i]!='\0')
        	sprintf(msgtemp,"%-.20s has been banned by %-.20s (%s).",dest,tname?tname:"unknown",&text[i]);
	    else
        	sprintf(msgtemp,"%-.20s has been banned by %-.20s.",dest,tname?tname:"unknown");
	    if (tname)
		account_unget_name(tname);
            channel_message_send(channel,MT_WARN,c,msgtemp);
        }
        if ((buc = connlist_find_connection(dest)) &&
            conn_get_channel(buc)==channel)
            conn_set_channel(buc,CHANNEL_NAME_BANNED);
	
        return 0;
    }
    if (strstart(text,"/unban")==0)
    {
	char         msgtemp[MAX_MESSAGE_LEN];
	t_channel *  channel;
	unsigned int i;
	
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
	for (; text[i]==' '; i++);
	
	if (text[i]=='\0')
        {
	    message_send(c,MT_WARN,c,"Who do you want to unban from the channel?");
	    return 0;
	}
	
        if (!(channel = conn_get_channel(c)))
        {
            message_send(c,MT_ERROR,c,"This command can only be used inside a channel.");
	    return 0;
        }
	if (account_get_auth_admin(conn_get_account(c))!=1 && /* default to false */
            channel_get_operator(channel)!=c)
        {
            message_send(c,MT_ERROR,c,"You are not a channel operator.");
	    return 0;
        }
        
        if (channel_unban_user(channel,&text[i])<0)
            message_send(c,MT_ERROR,c,"That user is not banned.");
        else
        {
            sprintf(msgtemp,"%s is no longer banned from this channel.",&text[i]);
            message_send(c,MT_WARN,c,msgtemp);
        }
	
        return 0;
    }
    
    if (prefs_get_extra_commands()==0)
    {
	message_send(c,MT_ERROR,c,"Unknown command.");
	eventlog(eventlog_level_debug,"handle_command","got unknown standard command \"%s\"",text);
	return 0;
    }
    
    /*******************************************************************/
    
    if (strstart(text,"/ann")==0) /* same as /announce */
    {
	unsigned int i;
	char         msgtemp[MAX_MESSAGE_LEN];
	char const * tname;
	
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
	for (; text[i]==' '; i++);
	
	if (account_get_auth_announce(conn_get_account(c))!=1) /* default to false */
	{
	    message_send(c,MT_WARN,c,"You do not have permission to use this command.");
	    return 0;
	}
	
	sprintf(msgtemp,"Announcement from %.64s: %.128s",(tname = conn_get_username(c)),&text[i]);
	conn_unget_username(c,tname);
	message_send_all(MT_BROADCAST,c,msgtemp);
	
	return 0;
    }
    if (strstart(text,"/watch")==0)
    {
	unsigned int i;
	t_account *  account;
	char msgtmp[MAX_MESSAGE_LEN];	

	for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
	for (; text[i]==' '; i++);
	
	if (text[i]=='\0')
        {
	    message_send(c,MT_WARN,c,"Who do you want to watch?");
	    return 0;
	}
	if (!(account = accountlist_find_account(&text[i])))
	{
	    message_send(c,MT_WARN,c,"That user does not exist.");
	    return 0;
	}
	
        conn_add_watch(c,account); /* FIXME: adds all events for now */
	sprintf (msgtmp,"User %s added to your watchlist",&text[i]);
	message_send(c,MT_WARN,c,msgtmp);
	
        return 0;
    }
    if (strstart(text,"/unwatch")==0)
    {
	unsigned int i;
	t_account *  account;
	char msgtmp[MAX_MESSAGE_LEN];
	
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
	for (; text[i]==' '; i++);
	
	if (text[i]=='\0')
        {
	    message_send(c,MT_WARN,c,"Who do you want to unwatch?");
	    return 0;
	}
	if (!(account = accountlist_find_account(&text[i])))
	{
	    message_send(c,MT_WARN,c,"That user does not exist.");
	    return 0;
	}
	
        if (conn_del_watch(c,account)<0) /* FIXME: deletes all events for now */
	{
	    message_send(c,MT_WARN,c,"You are not watching that user.");
	    return 0;
	}
	sprintf(msgtmp,"User %s deleted from your watchlist",&text[i]);
	message_send(c,MT_WARN,c,msgtmp);
	
        return 0;
    }
    if (strstart(text,"/watchall")==0)
    {
        conn_add_watch(c,NULL); /* FIXME: adds all events for now */
	message_send(c,MT_WARN,c,"All users are in your watching now");
	
        return 0;
    }
    if (strstart(text,"/unwatchall")==0)
    {
        if (conn_del_watch(c,NULL)<0) /* FIXME: deletes all events for now */
	{
	    message_send(c,MT_WARN,c,"You are not watching all users.");
	    return 0;
	}
	message_send(c,MT_WARN,c,"Watchall removed successfully");

        return 0;
    }
    if (strstart(text,"/lusers")==0)
    {
	char         msgtemp[MAX_MESSAGE_LEN];
	char const * banned;
	t_channel *  channel;
	unsigned int i;
	t_elem const * elem;
	
	if (!(channel = conn_get_channel(c)))
        {
            message_send(c,MT_ERROR,c,"This command can only be used inside a channel.");
	    return 0;
        }
	
	strcpy(msgtemp,"Banned users:");
	i = strlen(msgtemp);
	LIST_TRAVERSE_DATA_CONST(channel_get_banlist(channel),elem,banned)
	{
	    if (i+strlen(banned)+2>sizeof(msgtemp)) /* " ", name, '\0' */
	    {
		message_send(c,MT_WARN,c,msgtemp);
		i = 0;
	    }
	    sprintf(&msgtemp[i]," %s",banned);
	    i += strlen(&msgtemp[i]);
	}
	if (i>0)
	    message_send(c,MT_WARN,c,msgtemp);
	
	return 0;
    }
    if (strstart(text,"/news")==0)
    {
	char const * filename;
	FILE *       fd;
	
	if ((filename = prefs_get_newsfile()))
	    if ((fd = fopen(filename,"r")))
	    {
		message_send_file(c,fd);
		fclose(fd);
	    }
	    else
	    {
		eventlog(eventlog_level_error,"handle_command","could not open news file \"%s\" for reading (fopen: %s)",filename,strerror(errno));
                message_send(c,MT_WARN,c,"No news today.");
	    }
	else
            message_send(c,MT_WARN,c,"No news today.");
	
	return 0;
    }
    if (strstart(text,"/games")==0)
    {
	unsigned int           i;
	char                   msgtemp[MAX_MESSAGE_LEN];
        t_game const *         game;
	char const *           tag;
	t_elem const *	       elem;
        
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
	for (; text[i]==' '; i++);
	
	if (text[i]=='\0')
	{
	    tag = conn_get_clienttag(c);
	    message_send(c,MT_WARN,c,"Currently accessable games:");
	}
	else if (strcmp(&text[i],"all")==0)
	{
	    tag = NULL;
	    message_send(c,MT_WARN,c,"All current games:");
	}
	else
	{
	    tag = &text[i];
	    message_send(c,MT_WARN,c,"Current games of that type:");
	}
	 
	sprintf(msgtemp," ------name------ --------type-------- level count maxchar");
	message_send(c,MT_WARN,c,msgtemp);

	LIST_TRAVERSE_DATA_CONST(gamelist(),elem,game)
	{
	    if ((!tag || !prefs_get_hide_pass_games() || strcmp(game_get_pass(game),"")==0) &&
		(!tag || strcasecmp(game_get_clienttag(game),tag)==0))
		{
        	    sprintf(msgtemp," %-18.18s %-19.19s %5u %5u %7u",
				game_get_name(game),
				game_get_type_str(game),
				game_get_level(game),
				game_get_ref(game),
				game_get_maxplayers(game));
                    message_send(c,MT_WARN,c,msgtemp);
		}
	}
	return 0;
    }
    if (strstart(text,"/channels")==0 || strstart(text,"/chs")==0)
    {
	unsigned int      i;
	char              msgtemp[MAX_MESSAGE_LEN];
        t_channel const * channel;
	t_elem const *    elem;
	t_connection *    opr;
	char const *      oprname;
	char const *      tag;
        
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
	for (; text[i]==' '; i++);
	
	if (text[i]=='\0')
	{
	    tag = conn_get_clienttag(c);
	    message_send(c,MT_WARN,c,"Currently accessable channels:");
	}
	else if (strcmp(&text[i],"all")==0)
	{
	    tag = NULL;
	    message_send(c,MT_WARN,c,"All current channels:");
	}
	else
	{
	    tag = &text[i];
	    message_send(c,MT_WARN,c,"Current channels of that type:");
	}
	
	sprintf(msgtemp," ----------name---------- users ----operator----");
	message_send(c,MT_WARN,c,msgtemp);
	LIST_TRAVERSE_DATA_CONST(channellist(),elem,channel)
	{
	    if ((!tag || !prefs_get_hide_temp_channels() || channel_get_permanent(channel)) &&
		(!tag || !channel_get_clienttag(channel) ||
		 strcasecmp(channel_get_clienttag(channel),tag)==0))
	    {
		if ((opr = channel_get_operator(channel)))
		    oprname = conn_get_username(opr);
		else
		    oprname = NULL;
        	sprintf(msgtemp," %-24.24s %5u %-16.16s",
			channel_get_name(channel),
			channel_get_length(channel),
			oprname?oprname:"");
		if (oprname)
		   conn_unget_username(opr,oprname);
        	message_send(c,MT_WARN,c,msgtemp);
            }
	}
        
	return 0;
    }
    if (strstart(text,"/addacct")==0)
    {
	unsigned int i,j;
	t_account  * temp;
	t_hash       passhash;
	char         username[USER_NAME_LEN];
	char         msgtemp[MAX_MESSAGE_LEN];
	char         pass[256];
	
	if (account_get_auth_admin(conn_get_account(c))!=1) /* default to false */
	{
	    message_send(c,MT_ERROR,c,"This command is only enabled for admins.");
	    return 0;
	}
	
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++);
	for (; text[i]==' '; i++);
	
	for (j=0; text[i]!=' ' && text[i]!='\0'; i++) /* get username */
    	if (j<sizeof(username)-1) username[j++] = text[i];
	username[j] = '\0';
	
	for (; text[i]==' '; i++); /* skip spaces */
	for (j=0; text[i]!='\0'; i++) /* get pass (spaces are allowed) */
	    if (j<sizeof(pass)-1) pass[j++] = text[i];
	pass[j] = '\0';
	
	if (username[0]=='\0' || pass[0]=='\0')
	{
	    message_send(c,MT_ERROR,c,"Command requires USER and PASS as arguments.");
	    return 0;
	}
	
	for (i=0; i<strlen(pass); i++)
	    if (isupper((int)pass[i])) pass[i] = tolower((int)pass[i]);
	
	bnet_hash(&passhash,strlen(pass),pass);
	
	sprintf(msgtemp,"Trying to add account \"%s\" with password \"%s\"",username,pass);
	message_send(c,MT_WARN,c,msgtemp);
	
	sprintf(msgtemp,"Hash is: %s",hash_get_str(passhash));
	message_send(c,MT_WARN,c,msgtemp);
	
	if (!(temp = account_create(username,hash_get_str(passhash))))
	{
	    message_send(c,MT_ERROR,c,"Failed to create account!");
	    eventlog(eventlog_level_info,"handle_command","[%d] account not created (failed)",conn_get_socket(c));
	    return 0;
	}
	else if (!accountlist_add_account(temp))
	{
	    account_destroy(temp);
	    message_send(c,MT_ERROR,c,"Failed to insert account (already exists?)!");
	    eventlog(eventlog_level_info,"handle_command","[%d] account not inserted",conn_get_socket(c));
        }
        else
	{
	    sprintf(msgtemp,"Account "UID_FORMAT"created.",account_get_uid(temp));
	    message_send(c,MT_WARN,c,msgtemp);
	    eventlog(eventlog_level_info,"handle_command","[%d] account created by admin.", conn_get_socket(c));
        }
        return 0;
    }
    if (strstart(text,"/connections")==0 || strstart(text,"/con")==0)
    {
	char                   msgtemp[MAX_MESSAGE_LEN];
	t_elem const *	       elem;
	t_connection const *   conn;
	char                   name[19];
        
	if (!prefs_get_enable_conn_all() && account_get_auth_admin(conn_get_account(c))!=1) /* default to false */
        {
            message_send(c,MT_ERROR,c,"This command is only enabled for admins.");
	    return 0;
        }
	
        message_send(c,MT_WARN,c,"Current connections:");

	if (prefs_get_hide_addr() && account_get_auth_admin(conn_get_account(c))!=1) /* default to false */
	    sprintf(msgtemp," -#- -class ----state--- tag- -----name------ -session-- -flag- -lat-- c g");
	else
	    sprintf(msgtemp," -#- -class ----state--- tag- -----name------ -session-- -flag- -lat-- c g ---------addr--------");
	message_send(c,MT_WARN,c,msgtemp);
	LIST_TRAVERSE_DATA_CONST(connlist(),elem,conn)
        {
	    if (conn_get_account(conn))
	    {
		char const * tname;
		
		sprintf(name,"\"%.16s\"",(tname = conn_get_username(conn)));
		conn_unget_username(conn,tname);
	    }
	    else
		strcpy(name,"(none)");
	    
	    if (prefs_get_hide_addr() && account_get_auth_admin(conn_get_account(c))!=1) /* default to false */
                sprintf(msgtemp," %3u %-6.6s %-12.12s %4.4s %-15.15s 0x%08x 0x%04x 0x%04x %1d %1d",
			conn_get_socket(conn),
			conn_class_get_str(conn_get_class(conn)),
			conn_state_get_str(conn_get_state(conn)),
			conn_get_clienttag(conn),
			name,
			conn_get_sessionkey(conn),
			conn_get_flags(conn),
			conn_get_latency(conn),
			conn_get_channel(conn)!=NULL,
			conn_get_game(conn)!=NULL);
  	    else
                sprintf(msgtemp," %3u %-6.6s %-12.12s %4.4s %-15.15s 0x%08x 0x%04x 0x%04x %1d %1d %s",
			conn_get_socket(conn),
			conn_class_get_str(conn_get_class(conn)),
			conn_state_get_str(conn_get_state(conn)),
			conn_get_clienttag(conn),
			name,
			conn_get_sessionkey(conn),
			conn_get_flags(conn),
			conn_get_latency(conn),
			conn_get_channel(conn)!=NULL,
			conn_get_game(conn)!=NULL,
			addr_num_to_addr_str(conn_get_addr(conn),conn_get_port(conn)));
            message_send(c,MT_WARN,c,msgtemp);
        }
        
	return 0;
    }
    if (strstart(text,"/finger")==0)
    {
	char           dest[USER_NAME_LEN];
	char           msgtemp[MAX_MESSAGE_LEN];
	unsigned int   i,j;
	t_account *    account;
        t_connection * conn;
	char const *   host;
	char *         tok;
	char const *   tname;
	char const *   tsex;
	char const *   tloc;
	char const *   tage;
	char const *   thost;
	char const *   tdesc;
	
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
	for (; text[i]==' '; i++);
	for (j=0; text[i]!=' ' && text[i]!='\0'; i++) /* get dest */
	    if (j<sizeof(dest)-1) dest[j++] = text[i];
	dest[j] = '\0';
	for (; text[i]==' '; i++);
	
	if (!(account = accountlist_find_account(dest)))
	{
	    message_send(c,MT_ERROR,c,"Invalid user.");
	    return 0;
	}
	
        sprintf(msgtemp,"Login: %-16.16s "UID_FORMAT" Sex: %.16s",
		(tname = account_get_name(account)),
		account_get_uid(account),
		(tsex = account_get_sex(account)));
	account_unget_name(tname);
	account_unget_sex(tsex);
        message_send(c,MT_WARN,c,msgtemp);
	
        sprintf(msgtemp,"Location: %-21.21s Age: %.16s",
		(tloc = account_get_loc(account)),
		(tage = account_get_age(account)));
	account_unget_loc(tloc);
	account_unget_age(tage);
        message_send(c,MT_WARN,c,msgtemp);
	
        if (!(host=thost = account_get_ll_host(account)))
	    host = "unknown";
        {
            time_t then;
            
            then = account_get_ll_time(account);
	    if (!(conn = connlist_find_connection(dest)))
		strftime(msgtemp,sizeof(msgtemp),"Last login %a %b %d %H:%M from ",localtime(&then)); /* FIXME: determine user's timezone */
	    else
		strftime(msgtemp,sizeof(msgtemp),"On since %a %b %d %H:%M from ",localtime(&then)); /* FIXME: determine user's timezone */
        }
	strncat(msgtemp,host,32);
	message_send(c,MT_WARN,c,msgtemp);
	if (thost)
	    account_unget_ll_host(thost);

	if (conn)
	{
	    sprintf(msgtemp,"Idle %s",seconds_to_timestr(conn_get_idletime(conn)));
 	    message_send(c,MT_WARN,c,msgtemp);
	}
        
        strncpy(msgtemp,(tdesc = account_get_desc(account)),sizeof(msgtemp));
	msgtemp[sizeof(msgtemp)-1] = '\0';
	account_unget_desc(tdesc);
        for (tok=strtok(msgtemp,"\r\n"); tok; tok=strtok(NULL,"\r\n"))
	    if (tok[0]=='\0') /* empty messages crash some clients */
        	message_send(c,MT_WARN,c," ");
	    else
		message_send(c,MT_WARN,c,tok);
        message_send(c,MT_WARN,c," ");
        
	return 0;
    }
    if (strstart(text,"/operator")==0)
    {
	char                 msgtemp[MAX_MESSAGE_LEN];
	t_connection const * opr;
	t_channel const *    channel;
	
        if (!(channel = conn_get_channel(c)))
        {
            message_send(c,MT_ERROR,c,"This command can only be used inside a channel.");
	    return 0;
        }
	
	if (!(opr = channel_get_operator(channel)))
	    strcpy(msgtemp,"There is no operator.");
	else
	{
	    char const * tname;
	    
	    sprintf(msgtemp,"%.64s is the operator.",(tname = conn_get_username(opr)));
	    conn_unget_username(opr,tname);
	}
        message_send(c,MT_WARN,c,msgtemp);
        return 0;
    }
    if (strstart(text,"/logout")==0 || strstart(text,"/quit")==0 || strstart(text,"/exit")==0)
    {
	message_send(c,MT_WARN,c,"Connection closed.");
        conn_set_state(c,conn_state_destroy);
        return 0;
    }
    if (strstart(text,"/kill")==0)
    {
	unsigned int   i;
	t_connection * user;
	
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
	for (; text[i]==' '; i++);
	
	if (text[i]=='\0')
	{
	    message_send(c,MT_ERROR,c,"Which user do you want to kill?");
	    return 0;
	}
        if (!(user = connlist_find_connection(&text[i])))
	{
	    message_send(c,MT_ERROR,c,"That user is not logged in?");
	    return 0;
	}
	if (account_get_auth_admin(conn_get_account(c))!=1) /* default to false */
        {
            message_send(c,MT_ERROR,c,"This command is reserved for admins.");
	    return 0;
        }
	message_send(user,MT_WARN,user,"Connection closed by admin.");
        conn_set_state(user,conn_state_destroy);
        return 0;
    }
    if (strstart(text,"/killsession")==0)
    {
	unsigned int   i;
	t_connection * user;
	
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
	for (; text[i]==' '; i++);
	
	if (text[i]=='\0')
	{
	    message_send(c,MT_ERROR,c,"Which session do you want to kill?");
	    return 0;
	}
	if (!isxdigit((int)text[i]))
	{
	    message_send(c,MT_ERROR,c,"That is not a valid session.");
	    return 0;
	}
	if (!(user = connlist_find_connection_by_sessionkey((unsigned int)strtoul(&text[i],NULL,16))))
	{
            message_send(c,MT_ERROR,c,"That session does not exist.");
	    return 0;
	}
	if (account_get_auth_admin(conn_get_account(c))!=1) /* default to false */
        {
            message_send(c,MT_ERROR,c,"This command is reserved for admins.");
	    return 0;
        }
	message_send(user,MT_WARN,user,"Connection closed by admin.");
        conn_set_state(user,conn_state_destroy);
        return 0;
    }
    if (strstart(text,"/gameinfo")==0)
    {
	unsigned int   i;
	char           msgtemp[MAX_MESSAGE_LEN];
	t_game const * game;
	
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
	for (; text[i]==' '; i++);
	
	if (text[i]=='\0')
	{
	    if (!(game = conn_get_game(c)))
	    {
		message_send(c,MT_ERROR,c,"You are not in a game.");
		return 0;
	    }
	}
        else
	    if (!(game = gamelist_find_game(&text[i],game_type_all)))
	    {
		message_send(c,MT_ERROR,c,"That game does not exist.");
		return 0;
	    }
	
        sprintf(msgtemp,"Name: %-20.20s    ID: "GAMEID_FORMAT" (%s)",game_get_name(game),game_get_id(game),strcmp(game_get_pass(game),"")==0?"public":"private");
        message_send(c,MT_WARN,c,msgtemp);
	
	{
	    t_account *  owner;
	    char const * tname;
	    char const * namestr;
	    
	    if (!(owner = conn_get_account(game_get_owner(game))))
	    {
		tname = NULL;
		namestr = "none";
	    }
	    else
		if (!(tname = account_get_name(owner)))
		    namestr = "unknown";
		else
		    namestr = tname;
	    
            sprintf(msgtemp,"Owner: %-20.20s",namestr);
	    
            if (tname)
		account_unget_name(tname);
	}
        message_send(c,MT_WARN,c,msgtemp);
	
	if (!prefs_get_hide_addr() || account_get_auth_admin(conn_get_account(c))==1) /* default to false */
	{
	    unsigned int   addr;
	    unsigned short port;
	    unsigned int   taddr;
	    unsigned short tport;
	    
	    taddr=addr = game_get_addr(game);
	    tport=port = game_get_port(game);
	    gametrans_net(conn_get_local_addr(c),conn_get_local_port(c),&taddr,&tport);
	    
	    if (taddr==addr && tport==port)
        	sprintf(msgtemp,"Address: %s",
		    addr_num_to_addr_str(addr,port));
	    else
        	sprintf(msgtemp,"Address: %s (trans %s)",
		    addr_num_to_addr_str(addr,port),
		    addr_num_to_addr_str(taddr,tport));
	    message_send(c,MT_WARN,c,msgtemp);
	    if (game_get_realm(game)) {
		sprintf(msgtemp,"Realm: %u Level: %u-%u",game_get_d2servid(game),\
		        game_get_minlevel(game),game_get_maxlevel(game));
		message_send(c,MT_WARN,c,msgtemp);
	    }

	}
	
        sprintf(msgtemp,"Client: %4s (%u)",game_get_clienttag(game),game_get_version(game));
	message_send(c,MT_WARN,c,msgtemp);
	
	{
	    time_t      gametime;
	    struct tm * gmgametime;
	    
	    gametime = game_get_create_time(game);
	    gmgametime = gmtime(&gametime);
	    strftime(msgtemp,sizeof(msgtemp),"Created: "GAME_TIME_FORMAT,gmgametime);
	    message_send(c,MT_WARN,c,msgtemp);
	    
	    gametime = game_get_start_time(game);
	    if (gametime!=(time_t)0)
	    {
		gmgametime = gmtime(&gametime);
		strftime(msgtemp,sizeof(msgtemp),"Started: "GAME_TIME_FORMAT,gmgametime);
	    }
	    else
		strcpy(msgtemp,"Started: ");
            message_send(c,MT_WARN,c,msgtemp);
	}
	
	sprintf(msgtemp,"Status: %s",game_status_get_str(game_get_status(game)));
	message_send(c,MT_WARN,c,msgtemp);
	
        sprintf(msgtemp,"Type: %-20.20s",game_type_get_str(game_get_type(game)));
	message_send(c,MT_WARN,c,msgtemp);
	
        sprintf(msgtemp,"Speed: %s",game_speed_get_str(game_get_speed(game)));
	message_send(c,MT_WARN,c,msgtemp);
	
        sprintf(msgtemp,"Option: %s",game_option_get_str(game_get_option(game)));
	message_send(c,MT_WARN,c,msgtemp);
	
	{
	    char const * mapname;
	    
	    if (!(mapname = game_get_mapname(game)))
		mapname = "unknown";
            sprintf(msgtemp,"Map: %-20.20s",mapname);
	    message_send(c,MT_WARN,c,msgtemp);
	}
	
        sprintf(msgtemp,"Map Size: %ux%u",game_get_mapsize_x(game),game_get_mapsize_y(game));
	message_send(c,MT_WARN,c,msgtemp);
        sprintf(msgtemp,"Map Tileset: %s",game_tileset_get_str(game_get_tileset(game)));
	message_send(c,MT_WARN,c,msgtemp);
        sprintf(msgtemp,"Map Type: %s",game_maptype_get_str(game_get_maptype(game)));
	message_send(c,MT_WARN,c,msgtemp);
	
        sprintf(msgtemp,"Players: %u current, %u total, %u max",game_get_ref(game),game_get_count(game),game_get_maxplayers(game));
	message_send(c,MT_WARN,c,msgtemp);
	{
	    unsigned int p,count;
	    t_connection * * connections;
	    char const * charname;
	    connections=game_get_connections(game);
	    for (i=0,p=0,count=0;i<game_get_count(game);i++) {
		if (!connections[i]) {
		    continue;
		}
		if (count>=game_get_ref(game)) {
		    eventlog(eventlog_level_error,"handle_auth_packet","players in game not match ref");
		    break;
		}
		count++;
		if (!(charname=conn_get_charname(connections[i]))) {
		    eventlog(eventlog_level_debug,"handle_command","got NULL char name on connections %d of game %s",i,game_get_name(game));
		    continue;
		}
		if (p==0) sprintf (&msgtemp[p],"%s",charname);
		else sprintf (&msgtemp[p],",%s",charname);
		p+=strlen(&msgtemp[p]);
	    }
	    if (p!=0) message_send(c,MT_WARN,c,msgtemp);
	}
		
	return 0;
    }
    if (strstart(text,"/ladderactivate")==0)
    {
	if (account_get_auth_admin(conn_get_account(c))!=1) /* default to false */
        {
            message_send(c,MT_ERROR,c,"This command is reserved for admins.");
	    return 0;
        }
	ladderlist_make_all_active();
	message_send(c,MT_WARN,c,"Copied current scores to active scores on all ladders.");
	return 0;
    }
    if (strstart(text,"/ladderinfo")==0)
    {
	char         dest[32];
	char         msgtemp[MAX_MESSAGE_LEN];
	unsigned int rank;
	unsigned int i,j;
	t_account *  account;
	char const * clienttag;
	char const * tname;
	
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
	for (; text[i]==' '; i++);
	for (j=0; text[i]!=' ' && text[i]!='\0'; i++) /* get dest */
	    if (j<sizeof(dest)-1) dest[j++] = text[i];
	dest[j] = '\0';
	for (; text[i]==' '; i++);
	
	if (dest[0]=='\0')
	{
	    message_send(c,MT_ERROR,c,"Which rank do you want ladder info for?");
	    return 0;
	}
	if (str_to_uint(&dest[0],&rank)<0 || rank<1)
	{
	    message_send(c,MT_ERROR,c,"Invalid rank.");
	    return 0;
	}
	
	if (text[i]!='\0')
	    clienttag = &text[i];
	else if (!(clienttag = conn_get_clienttag(c)))
	{
	    message_send(c,MT_ERROR,c,"Unable to determine client game.");
	    return 0;
	}
	
	if (strlen(clienttag)!=4)
	{
	    sprintf(msgtemp,"You must supply a rank and a valid program ID. (Program ID \"%.32s\" is invalid.)",clienttag);
	    message_send(c,MT_ERROR,c,msgtemp);
	    message_send(c,MT_ERROR,c,"Example: /ladderinfo 1 STAR");
	    return 0;
	}
	
	if (strcasecmp(clienttag,CLIENTTAG_STARCRAFT)==0)
	{
            if ((account = ladder_get_account_by_rank(rank,ladder_sort_highestrated,ladder_time_active,CLIENTTAG_STARCRAFT,ladder_id_normal)))
	    {
		sprintf(msgtemp,"Starcraft active  %5u: %-20.20s %u/%u/%u rating %u",
			rank,
			(tname = account_get_name(account)),
			account_get_ladder_active_wins(account,CLIENTTAG_STARCRAFT,ladder_id_normal),
			account_get_ladder_active_losses(account,CLIENTTAG_STARCRAFT,ladder_id_normal),
			account_get_ladder_active_disconnects(account,CLIENTTAG_STARCRAFT,ladder_id_normal),
			account_get_ladder_active_rating(account,CLIENTTAG_STARCRAFT,ladder_id_normal));
		account_unget_name(tname);
	    }
	    else
		sprintf(msgtemp,"Starcraft active  %5u: <none>",rank);
	    message_send(c,MT_WARN,c,msgtemp);
	    
	    if ((account = ladder_get_account_by_rank(rank,ladder_sort_highestrated,ladder_time_current,CLIENTTAG_STARCRAFT,ladder_id_normal)))
	    {
		sprintf(msgtemp,"Starcraft current %5u: %-20.20s %u/%u/%u rating %u",
			rank,
			(tname = account_get_name(account)),
			account_get_ladder_wins(account,CLIENTTAG_STARCRAFT,ladder_id_normal),
			account_get_ladder_losses(account,CLIENTTAG_STARCRAFT,ladder_id_normal),
			account_get_ladder_disconnects(account,CLIENTTAG_STARCRAFT,ladder_id_normal),
			account_get_ladder_rating(account,CLIENTTAG_STARCRAFT,ladder_id_normal));
		account_unget_name(tname);
	    }
	    else
		sprintf(msgtemp,"Starcraft current %5u: <none>",rank);
	    message_send(c,MT_WARN,c,msgtemp);
	}
	else if (strcasecmp(clienttag,CLIENTTAG_BROODWARS)==0)
	{
	    if ((account = ladder_get_account_by_rank(rank,ladder_sort_highestrated,ladder_time_active,CLIENTTAG_BROODWARS,ladder_id_normal)))
	    {
		sprintf(msgtemp,"Brood War active  %5u: %-20.20s %u/%u/%u rating %u",
			rank,
			(tname = account_get_name(account)),
			account_get_ladder_active_wins(account,CLIENTTAG_BROODWARS,ladder_id_normal),
			account_get_ladder_active_losses(account,CLIENTTAG_BROODWARS,ladder_id_normal),
			account_get_ladder_active_disconnects(account,CLIENTTAG_BROODWARS,ladder_id_normal),
			account_get_ladder_active_rating(account,CLIENTTAG_BROODWARS,ladder_id_normal));
		account_unget_name(tname);
	    }
	    else
		sprintf(msgtemp,"Brood War active  %5u: <none>",rank);
	    message_send(c,MT_WARN,c,msgtemp);
	    
	    if ((account = ladder_get_account_by_rank(rank,ladder_sort_highestrated,ladder_time_current,CLIENTTAG_BROODWARS,ladder_id_normal)))
	    {
		sprintf(msgtemp,"Brood War current %5u: %-20.20s %u/%u/%u rating %u",
			rank,
			(tname = account_get_name(account)),
			account_get_ladder_wins(account,CLIENTTAG_BROODWARS,ladder_id_normal),
			account_get_ladder_losses(account,CLIENTTAG_BROODWARS,ladder_id_normal),
			account_get_ladder_disconnects(account,CLIENTTAG_BROODWARS,ladder_id_normal),
			account_get_ladder_rating(account,CLIENTTAG_BROODWARS,ladder_id_normal));
		account_unget_name(tname);
	    }
	    else
		sprintf(msgtemp,"Brood War current %5u: <none>",rank);
	    message_send(c,MT_WARN,c,msgtemp);
	}
	else if (strcasecmp(clienttag,CLIENTTAG_WARCIIBNE)==0)
	{
	    if ((account = ladder_get_account_by_rank(rank,ladder_sort_highestrated,ladder_time_active,CLIENTTAG_WARCIIBNE,ladder_id_normal)))
	    {
		sprintf(msgtemp,"Warcraft II standard active  %5u: %-20.20s %u/%u/%u rating %u",
			rank,
			(tname = account_get_name(account)),
			account_get_ladder_active_wins(account,CLIENTTAG_WARCIIBNE,ladder_id_normal),
			account_get_ladder_active_losses(account,CLIENTTAG_WARCIIBNE,ladder_id_normal),
			account_get_ladder_active_disconnects(account,CLIENTTAG_WARCIIBNE,ladder_id_normal),
			account_get_ladder_active_rating(account,CLIENTTAG_WARCIIBNE,ladder_id_normal));
		account_unget_name(tname);
	    }
	    else
		sprintf(msgtemp,"Warcraft II standard active  %5u: <none>",rank);
	    message_send(c,MT_WARN,c,msgtemp);
	    
	    if ((account = ladder_get_account_by_rank(rank,ladder_sort_highestrated,ladder_time_active,CLIENTTAG_WARCIIBNE,ladder_id_ironman)))
	    {
		sprintf(msgtemp,"Warcraft II IronMan active   %5u: %-20.20s %u/%u/%u rating %u",
			rank,
			(tname = account_get_name(account)),
			account_get_ladder_active_wins(account,CLIENTTAG_WARCIIBNE,ladder_id_ironman),
			account_get_ladder_active_losses(account,CLIENTTAG_WARCIIBNE,ladder_id_ironman),
			account_get_ladder_active_disconnects(account,CLIENTTAG_WARCIIBNE,ladder_id_ironman),
			account_get_ladder_active_rating(account,CLIENTTAG_WARCIIBNE,ladder_id_ironman));
		account_unget_name(tname);
	    }
	    else
		sprintf(msgtemp,"Warcraft II IronMan active   %5u: <none>",rank);
	    message_send(c,MT_WARN,c,msgtemp);
	    
	    if ((account = ladder_get_account_by_rank(rank,ladder_sort_highestrated,ladder_time_current,CLIENTTAG_WARCIIBNE,ladder_id_normal)))
	    {
		sprintf(msgtemp,"Warcraft II standard current %5u: %-20.20s %u/%u/%u rating %u",
			rank,
			(tname = account_get_name(account)),
			account_get_ladder_wins(account,CLIENTTAG_WARCIIBNE,ladder_id_normal),
			account_get_ladder_losses(account,CLIENTTAG_WARCIIBNE,ladder_id_normal),
			account_get_ladder_disconnects(account,CLIENTTAG_WARCIIBNE,ladder_id_normal),
			account_get_ladder_rating(account,CLIENTTAG_WARCIIBNE,ladder_id_normal));
		account_unget_name(tname);
	    }
	    else
		sprintf(msgtemp,"Warcraft II standard current %5u: <none>",rank);
	    message_send(c,MT_WARN,c,msgtemp);
	    
	    if ((account = ladder_get_account_by_rank(rank,ladder_sort_highestrated,ladder_time_current,CLIENTTAG_WARCIIBNE,ladder_id_ironman)))
	    {
		sprintf(msgtemp,"Warcraft II IronMan current  %5u: %-20.20s %u/%u/%u rating %u",
			rank,
			(tname = account_get_name(account)),
			account_get_ladder_wins(account,CLIENTTAG_WARCIIBNE,ladder_id_ironman),
			account_get_ladder_losses(account,CLIENTTAG_WARCIIBNE,ladder_id_ironman),
			account_get_ladder_disconnects(account,CLIENTTAG_WARCIIBNE,ladder_id_ironman),
			account_get_ladder_rating(account,CLIENTTAG_WARCIIBNE,ladder_id_ironman));
		account_unget_name(tname);
	    }
	    else
		sprintf(msgtemp,"Warcraft II IronMan current  %5u: <none>",rank);
	    message_send(c,MT_WARN,c,msgtemp);
	}
	else
	{
	    message_send(c,MT_ERROR,c,"This game does not support win/loss records.");
	    message_send(c,MT_ERROR,c,"You must supply a rank and a valid program ID.");
	    message_send(c,MT_ERROR,c,"Example: /ladderinfo 1 STAR");
	}
	
	return 0;
    }
    if (strstart(text,"/timer")==0)
    {
	unsigned int i,j;
	unsigned int delta;
	char         deltastr[64];
	t_timer_data data;
	
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
	for (; text[i]==' '; i++);
	for (j=0; text[i]!=' ' && text[i]!='\0'; i++) /* get comm */
	    if (j<sizeof(deltastr)-1) deltastr[j++] = text[i];
	deltastr[j] = '\0';
	for (; text[i]==' '; i++);
	
	if (deltastr[0]=='\0')
	{
	    message_send(c,MT_ERROR,c,"How long do you want the timer to last?");
	    return 0;
	}
	
	if (clockstr_to_seconds(deltastr,&delta)<0)
	{
	    message_send(c,MT_ERROR,c,"Invalid duration.");
	    return 0;
	}
	
	if (text[i]=='\0')
	    data.p = strdup("Your timer has expired.");
	else
	    data.p = strdup(&text[i]);
	
	if (timerlist_add_timer(c,time(NULL)+(time_t)delta,user_timer_cb,data)<0)
	{
	    eventlog(eventlog_level_error,"handle_command","could not add timer");
	    free(data.p);
	    message_send(c,MT_ERROR,c,"Could not set timer.");
	}
	else
	{
	    char msgtemp[MAX_MESSAGE_LEN];
	    
	    sprintf(msgtemp,"Timer set for %s",seconds_to_timestr(delta));
	    message_send(c,MT_WARN,c,msgtemp);
	}
	
	return 0;
    }
    if (strstart(text,"/netinfo")==0)
    {
	char           dest[USER_NAME_LEN];
	char           msgtemp[MAX_MESSAGE_LEN];
	unsigned int   i,j;
        t_connection * conn;
	char const *   host;
	char const *   thost;
	t_game const * game;
	unsigned int   addr;
	unsigned short port;
	unsigned int   taddr;
	unsigned short tport;
	
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
	for (; text[i]==' '; i++);
	for (j=0; text[i]!=' ' && text[i]!='\0'; i++) /* get dest */
	    if (j<sizeof(dest)-1) dest[j++] = text[i];
	dest[j] = '\0';
	for (; text[i]==' '; i++);
	
	if (dest[0]=='\0')
	{
	    char const * tname;
	    
	    strcpy(dest,(tname = conn_get_username(c)));
	    conn_unget_username(c,tname);
	}
	
	if (!(conn = connlist_find_connection(dest)))
	{
	    message_send(c,MT_ERROR,c,"That user is not logged on.");
	    return 0;
	}
	
	if (conn_get_account(conn)!=conn_get_account(c) &&
	    prefs_get_hide_addr() && account_get_auth_admin(conn_get_account(c))!=1) /* default to false */
	{
	    message_send(c,MT_ERROR,c,"Address information for other users is only avaliable to admins.");
	    return 0;
	}
	
        if (!(host=thost = account_get_ll_host(conn_get_account(conn))))
	    host = "unknown";
	sprintf(msgtemp,"TCP: %s (%.32s)",addr_num_to_addr_str(conn_get_addr(conn),conn_get_port(conn)),host);
	if (thost)
	    account_unget_ll_host(thost);
	message_send(c,MT_WARN,c,msgtemp);
	
	taddr=addr = conn_get_game_addr(conn);
	tport=port = conn_get_game_port(conn);
	gametrans_net(addr,port,&taddr,&tport);
	
	if (taddr==addr && tport==port)
	    sprintf(msgtemp,"UDP: %s",
		    addr_num_to_addr_str(addr,port));
	else
	    sprintf(msgtemp,"UDP: %s (trans %s)",
		    addr_num_to_addr_str(addr,port),
		    addr_num_to_addr_str(taddr,tport));
	message_send(c,MT_WARN,c,msgtemp);
	
	if ((game = conn_get_game(conn)))
	{
	    taddr=addr = game_get_addr(game);
	    tport=port = game_get_port(game);
	    gametrans_net(addr,port,&taddr,&tport);
	    
	    if (taddr==addr && tport==port)
		sprintf(msgtemp,"Game: %s",
			addr_num_to_addr_str(addr,port));
	    else
		sprintf(msgtemp,"Game: %s (trans %s)",
			addr_num_to_addr_str(addr,port),
			addr_num_to_addr_str(taddr,tport));
	}
	else
	    strcpy(msgtemp,"Game: none");
	message_send(c,MT_WARN,c,msgtemp);
	
	return 0;
    }
#ifndef WIN32
    if (strstart(text,"/fortune")==0)
    {
	char         msgtemp[MAX_MESSAGE_LEN];
	char const * fcmd;
	FILE *       pp;
	unsigned int len;
	unsigned int i;
	
	if (!(fcmd = prefs_get_fortunecmd()) || fcmd[0]=='\0')
	{
	    message_send(c,MT_WARN,c,"Fortune not avaliable.");
	    return 0;
	}
	
	if (!(pp = runprog_open(fcmd)))
	{
	    message_send(c,MT_ERROR,c,"Fortune failed.");
	    eventlog(eventlog_level_error,"handle_command","could not open fortune process \"%s\"",fcmd);
	    return 0;
	}
	
	while (fgets(msgtemp,sizeof(msgtemp),pp))
	{
	    len = strlen(msgtemp);
	    if (len>0 && msgtemp[len-1]=='\n');
		msgtemp[len-1] = '\0';
	    for (i=0; i<len; i++)
		if (msgtemp[i]=='\t')
		    msgtemp[i] = ' ';
	    
	    if (msgtemp[0]=='\0') /* empty messages crash some clients */
        	message_send(c,MT_WARN,c," ");
	    else
		message_send(c,MT_WARN,c,msgtemp);
	}
	
	if (runprog_close(pp)!=0)
	{
	    message_send(c,MT_ERROR,c,"Fortune failed.");
	    eventlog(eventlog_level_error,"handle_command","could not close fortune process");
	}
	return 0;
    }
#endif
    if (strstart(text,"/help")==0)
    {
	handle_help_command(c,text);
	return 0;
    }
    
    if (strstart(text,"/flag")==0)
    {
	unsigned int i,newflag;
	if (account_get_auth_admin(conn_get_account(c))!=1) {
		message_send(c,MT_ERROR,c,"Only admin can do this");
		return 0;
	}
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
        for (; text[i]==' '; i++);
	if (text[i]!='\0') {
	newflag=strtoul(&text[i],NULL,0);
	conn_set_flags(c,newflag);
	message_send(c,MT_WARN,c,"Flag changed ok");
	}
	return 0;
    }
    if (strstart(text,"/tag")==0)
    {
	unsigned int i;
	char newtag[5];
        if (account_get_auth_admin(conn_get_account(c))!=1) {
                message_send(c,MT_ERROR,c,"Only admin can do this");
                return 0;
        }
        for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
        for (; text[i]==' '; i++);
	strncpy(newtag,&text[i],4);
	if (strlen(newtag)!=4 || !newtag ) {
		message_send(c,MT_WARN,c,"Bad client tag,should be 4 chars length");
		return 0;
	}
	conn_set_clienttag(c,newtag);
	channel_update_flags(c);
	message_send(c,MT_WARN,c,"Client tag setted ok");
	return 0;
    }
    if (strstart(text,"/char")==0) 
    {
	unsigned int	      i;
	char const *	      tname;
	t_connection *	      dest_c; 
	char		      msgtmp[MAX_MESSAGE_LEN];

        for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
        for (; text[i]==' '; i++);
	if (!(dest_c=connlist_find_connection_by_charname(&text[i]))) {
	      message_send(c,MT_ERROR,c,"no such a character");
	      return 0;
	}
	{
	  sprintf (msgtmp,"Character %s belongs to %s",&text[i],(tname=conn_get_username(dest_c)));
	  message_send(c,MT_WARN,c,msgtmp);
	  conn_unget_username(c,tname);
	  return 0;
	}
    }
    if (strstart(text,"/retest")==0)
    {

        if (account_get_auth_announce(conn_get_account(c))!=1) {
                message_send(c,MT_ERROR,c,"permission denied");
                return 0;
        }
	d2servlist_retest();
	message_send(c,MT_WARN,c,"servers retested ok");
	return 0;
    }
    if (strstart(text,"/gameid")==0)
    {
	unsigned int i,j;
	char gamename[GAME_NAME_LEN];
	t_game * game;
	char msgtmp[MAX_MESSAGE_LEN];

	for (i=0; text[i]!=' ' && text[i]!='\0'; i++); /* skip command */
	for (; text[i]==' '; i++);
	if (text[i]=='[') {
	    i++;
	    for (j=0; text[i]!=']' && text[i]!='\0'; i++) /* get dest */
		if (j<sizeof(gamename)-1) gamename[j++] = text[i];
	    gamename[j] = '\0';
	    i++;
	}
	else {
	    for (j=0; text[i]!=' ' && text[i]!='\0'; i++) /* get dest */
		if (j<sizeof(gamename)-1) gamename[j++] = text[i];
	    gamename[j] = '\0';
	}
        for (; text[i]==' '; i++);

	if(!(game=gamelist_find_game(gamename,game_type_d2realm))) {
	    message_send(c,MT_ERROR,c,"no such a game");
	    return 0;
	}
        if (account_get_auth_admin(conn_get_account(c))!=1) {
            message_send(c,MT_ERROR,c,"permission denied");
            return 0;
        }
	if (text[i]=='\0') {
	    sprintf(msgtmp,"game %s`s current id is %d",gamename,game_get_token(game));
	    message_send(c,MT_WARN,c,msgtmp);
	    return 0;
	}
	if (game_set_token(game,strtoul(&text[i],NULL,0))<0) {
	    message_send(c,MT_ERROR,c,"a game with this token already exist");
	    return 0;
	}
	else {
	   	message_send(c,MT_WARN,c,"game id changed ok");
		return 0;
	}
    }

    if (strstart(text,"/d2ladder")==0) 
    {
	unsigned int i;
	if (account_get_auth_admin(conn_get_account(c))!=1) {                             
               message_send(c,MT_ERROR,c,"permission denied");                              
	       return 0;                                                                    
	}  
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++);                                       
	for (; text[i]==' '; i++);                                                           
	d2ladder_refresh_time_wrapper(strtoul(&text[i],NULL,0));
	message_send(c,MT_WARN,c,"d2ladder refresh time changed ok");
	return 0;
    }

    if (strstart(text,"/token")==0)
    {
	unsigned int i;
	t_addr * addr;

        if (account_get_auth_announce(conn_get_account(c))!=1) {
                message_send(c,MT_ERROR,c,"permission denied");
                return 0;
        }
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++);
	for (; text[i]==' '; i++);

	if (!(addr=d2servlist_get_server_by_id(strtoul(&text[i],NULL,0)))) {
		message_send(c,MT_WARN,c,"Server not exist in list");
		return 0;
	}
	for (; text[i]!=' ' && text[i]!='\0'; i++);
        for (; text[i]==' '; i++);
	if (text[i]=='\0') {
	    return 0;
	}
	d2server_set_token(addr,strtoul(&text[i],NULL,0));
	message_send(c,MT_WARN,c,"server token changed ok");
	return 0;
    }

    if (strstart(text,"/add")==0) {
	unsigned int i;
	char msgtmp[MAX_MESSAGE_LEN];

        if (account_get_auth_admin(conn_get_account(c))!=1) {
                message_send(c,MT_ERROR,c,"permission denied");
                return 0;
        }
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++);
	for (; text[i]==' '; i++);
	if (text[i]=='\0') {
	    return 0;
	}
	else {
	    strncpy(msgtmp,&text[i],sizeof(msgtmp)); 
	    if (d2servlist_add_server(msgtmp)<0) {
		message_send(c,MT_ERROR,c,"bad server address");
		return 0;
	    }
	    else {
		message_send(c,MT_WARN,c,"server address added ok");
		return 0;
	    }
	}
    }

    if (strstart(text,"/del")==0) {
	unsigned int i;

        if (account_get_auth_admin(conn_get_account(c))!=1) {
                message_send(c,MT_ERROR,c,"permission denied");
                return 0;
        }
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++);
	for (; text[i]==' '; i++);
	if (text[i]=='\0') {
	    return 0;
	}
	else {
	    if (d2servlist_del_server(strtoul(&text[i],NULL,0))==-1) {
		message_send(c,MT_ERROR,c,"bad server address");
		return 0;
	    }
	    else {
		message_send(c,MT_WARN,c,"server address removed ok");
		return 0;
	    }
	}
    }

    if (strstart(text,"/maxgame")==0) {
	unsigned int	i;
	t_addr *	taddr;

        if (account_get_auth_announce(conn_get_account(c))!=1) {
                message_send(c,MT_ERROR,c,"permission denied");
                return 0;
        }
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++);
	for (; text[i]==' '; i++);
	if (text[i]=='\0') {
	    return 0;
	}
	else {
	    if (!(taddr=d2servlist_get_server_by_id(strtoul(&text[i],NULL,0)))) {
		message_send(c,MT_ERROR,c,"server not found");
		return 0;
	    }
	    for (; text[i]!=' ' && text[i]!='\0'; i++);
	    for (; text[i]==' '; i++);
	    d2server_set_maxgame(taddr,strtoul(&text[i],NULL,0));
	    message_send(c,MT_WARN,c,"server maxgame changed ok");
	    return 0;
	}
    }

    if (strstart(text,"/d2server")==0) {
        if (account_get_auth_announce(conn_get_account(c))!=1) {
                message_send(c,MT_ERROR,c,"permission denied");
                return 0;
        }
	{
	    char tempa[32];
	    t_addr * curr_taddr;
	    char msgtmp[MAX_MESSAGE_LEN];
	    t_elem const * elem;

	    message_send(c,MT_WARN,c,"Server-----------------Status----Max---Token----Games");
	    LIST_TRAVERSE_DATA_CONST(d2servlist(),elem,curr_taddr)
	    {
		addr_get_addr_str(curr_taddr,tempa,sizeof(tempa));
		if (d2server_get_status(curr_taddr)==d2server_status_connected) {
		    sprintf(msgtmp,"%u: %-24s Running %d %d %d",d2server_get_id(curr_taddr),\
			    tempa,d2server_get_maxgame(curr_taddr),d2server_get_token(curr_taddr),\
			    d2server_get_gamenum(curr_taddr));
		}
		else {
		    sprintf(msgtmp,"%u: %-24s Down %d",d2server_get_id(curr_taddr),tempa,\
			    d2server_get_maxgame(curr_taddr));
		}
		message_send(c,MT_WARN,c,msgtmp);
	    }
	    if (d2servlist_choose_server()) {
	      addr_get_addr_str(d2servlist_choose_server(),tempa,sizeof(tempa));
	      sprintf(msgtmp,"game server address now is %s",tempa);
	      message_send(c,MT_WARN,c,msgtmp);
	    }
	    else message_send(c,MT_WARN,c,"no available game server now");
	    return 0;
	}
    }

    if (strstart(text,"/shutdown")==0) {
	unsigned int i;
	unsigned int delay;

	if (account_get_auth_admin(conn_get_account(c))!=1)
	{
	    message_send(c,MT_ERROR,c,"This command is reserved for admins");
	    return 0;
	}
	for (i=0; text[i]!=' ' && text[i]!='\0'; i++);
	for (; text[i]==' '; i++);
	if (text[i]=='\0') {
	}
	else {
	delay=strtoul(&text[i],NULL,0);
	server_quit_wrapper(delay*60);
	message_send(c,MT_WARN,c,"You initialised the shutdown sequence");
	}
	return 0;
    }
  
    if (strlen(text)>=2 && strncmp(text,"//",2)==0)
    {
	handle_chat_command(c,&text[2]);
    	return 0;
    }
    message_send(c,MT_ERROR,c,"Unknown command.");
    eventlog(eventlog_level_debug,"handle_command","got unknown command \"%s\"",text);
    return 0;
}
