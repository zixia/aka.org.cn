/*
 * Copyright (C) 2000 Ross Combs (rocombs@cs.nmsu.edu)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#define GAMETRANS_INTERNAL_ACCESS
#include "config.h"
#include "setup.h"

#include <stdio.h>
#include <errno.h>

#define USE_STDDEF_HEADERS
#define USE_STDC_HEADERS
#define USE_STRING_HEADERS

#include "compat.h"

#include "compat/strerror.h"
#include "eventlog.h"
#include "list.h"
#include "addr.h"
#include "util.h"
#include "gametrans.h"


static t_list * gametrans_head=NULL;


extern int gametrans_load(char const * filename)
{
    FILE *        fp;
    unsigned int  line;
    unsigned int  len;
    unsigned int  pos;
    char *        buff;
    char *        temp;
    char *        viewer;
    char *        client;
    char *        output;
    t_gametrans * entry;
    
    if (!filename)
    {
        eventlog(eventlog_level_error,"gametrans_load","got NULL filename");
        return -1;
    }
    if (!(gametrans_head = list_create()))
    {
	eventlog(eventlog_level_error,"gametrans_load","could not create list");
	return -1;
    }
    if (!(fp = fopen(filename,"r")))
    {
        eventlog(eventlog_level_error,"gametrans_load","could not open file \"%s\" for reading (fopen: %s)",filename,strerror(errno));
	list_destroy(gametrans_head);
	gametrans_head=NULL;
        return -1;
    }
    
    for (line=1; (buff = file_get_line(fp)); line++)
    {
        for (pos=0; buff[pos]=='\t' || buff[pos]==' '; pos++);
        len = strlen(buff)+1;
        if (buff[pos]=='\0' || buff[pos]=='#')
        {
            free(buff);
            continue;
        }
        {
            unsigned int endpos;

            if ((temp = strrchr(buff,'#'))) *temp = '\0';

            for (endpos=strlen(buff)-1;  buff[endpos]=='\t' || buff[endpos]==' '; endpos--);
            buff[endpos+1] = '\0';
            len = strlen(buff)+1;
        }

	
	if (!(viewer = strtok(buff," "))) /* strtok modifies the string it is passed */
	{
	    eventlog(eventlog_level_error,"gametrans_load","missing viewer on line %u of file \"%s\"",line,filename);
	    free(buff);
	    continue;
	}
	if (!(client = strtok(NULL," ")))
	{
	    eventlog(eventlog_level_error,"gametrans_load","missing client on line %u of file \"%s\"",line,filename);
	    free(buff);
	    continue;
	}
	if (!(output = strtok(NULL," ")))
	{
	    eventlog(eventlog_level_error,"gametrans_load","missing output on line %u of file \"%s\"",line,filename);
	    free(buff);
	    continue;
	}
	
	if (!(entry = malloc(sizeof(t_gametrans))))
	{
	    eventlog(eventlog_level_error,"gametrans_load","could not allocate memory for entry");
	    free(buff);
	    continue;
	}
	if (!(entry->viewer = addr_create_str(viewer,0,0)))
	{
	    eventlog(eventlog_level_error,"gametrans_load","could not allocate memory for viewer address");
	    free(entry);
	    free(buff);
	    continue;
	}
	if (!(entry->client = addr_create_str(client,0,6112)))
	{
	    eventlog(eventlog_level_error,"gametrans_load","could not allocate memory for client address");
	    addr_destroy(entry->viewer);
	    free(entry);
	    free(buff);
	    continue;
	}
	if (!(entry->output = addr_create_str(output,0,6112)))
	{
	    eventlog(eventlog_level_error,"gametrans_load","could not allocate memory for output address");
	    addr_destroy(entry->client);
	    addr_destroy(entry->viewer);
	    free(entry);
	    free(buff);
	    continue;
	}
	
	free(buff);
	
	if (list_append_data(gametrans_head,entry)<0)
	{
	    eventlog(eventlog_level_error,"gametrans_load","could not append item");
	    addr_destroy(entry->output);
	    addr_destroy(entry->client);
	    addr_destroy(entry->viewer);
	    free(entry);
	    continue;
	}
    }
    fclose(fp); 
    return 0;
}


extern int gametrans_unload(void)
{
    t_gametrans * entry;
    t_elem *	  elem;
    
    LIST_TRAVERSE_DATA(gametrans_head,elem,entry)
    {
	addr_destroy(entry->output);
	addr_destroy(entry->client);
	addr_destroy(entry->viewer);
	free(entry);
	list_remove_elem(gametrans_head,elem);
    }
    list_destroy(gametrans_head);
    gametrans_head=NULL;
    return 0;
}


extern void gametrans_net(unsigned int laddr, unsigned short lport, unsigned int * addr, unsigned short * port)
{
    t_gametrans * entry;
    t_elem const * elem;
    
    LIST_TRAVERSE_DATA_CONST(gametrans_head,elem,entry)
    {
	if (addr_get_ip(entry->viewer)!=0 && addr_get_ip(entry->viewer)!=laddr)
	    continue;
	if (addr_get_port(entry->viewer)!=0 && addr_get_port(entry->viewer)!=lport)
	    continue;
	
	if (addr_get_ip(entry->client)!=0 && addr_get_ip(entry->client)!=*addr)
	    continue;
	if (addr_get_port(entry->client)!=0 && addr_get_port(entry->client)!=*port)
	    continue;
	
	*addr = addr_get_ip(entry->output);
	*port = addr_get_port(entry->output);
	
	return;
    }
}
