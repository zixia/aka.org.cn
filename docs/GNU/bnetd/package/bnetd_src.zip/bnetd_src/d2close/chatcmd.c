/*
 * Copyright (C) 2000  Onlyer (onlyer@263.net)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#include "setup.h"
#include "config.h"

#include <errno.h>
#include <ctype.h>

#define USE_STDDEF_HEADERS
#define USE_STDC_HEADERS
#define USE_STRING_HEADERS

#include "compat.h"

#include "compat/strcasecmp.h"

#include "message.h"
#include "eventlog.h"
#include "connection.h"
#include "prefs.h"
#include "field_sizes.h"
#include "util.h"
#include "account.h"
#include "channel.h"
#include "chatcmd.h"

static FILE * cfd = NULL;
static int list_chats(t_connection *);
static int do_chat(t_connection *,char const *,char const *);

static int list_chats(t_connection * c)
{
	unsigned int i;
	char * line;
	message_send(c,MT_WARN,c,"Emote list:");

        while( (line=file_get_line(cfd))!=NULL )
	{	
		for (i=0;line[i]==' ' && line[i]!='\0'; i++);
		if (line[i]=='@') 
		{
		char * p, *buffer;
		int al,length,position;
		length=MAX_COMMAND_LEN+1; 
		position=0;
		buffer=malloc(length+1);
		if (!buffer) {
			free(line);
			eventlog(eventlog_level_error,"list_chats","Cound not allocate memory");
			message_send(c,MT_ERROR,c,"Not enough Memory");
			return -1;
		}
		p=line+i;
		do {
			al=0;
			for (i=1;p[i]!=' ' && p[i]!='\0' && p[i]!='#';i++);
			if (p[i]==' ') al=1; 		
			p[i]='\0';
			p[0]='/';
			if (length<strlen(p)+position+1) {
				char *aux;
				length=strlen(p)+position+1;
				aux=buffer;
				buffer=realloc(buffer,length+1);
				if (!buffer) {
					eventlog(eventlog_level_error,"list_chats","Cound not allocate memory");
					message_send(c,MT_ERROR,c,"Not enough Memory");
					free(line);
					free(aux);
					return -1;
		       		 }
			}
				
			buffer[position++]=' ';
			strcpy(buffer+position,p);
			position+=strlen(p);
			if (al) {
			   for (;p[i+1]==' ' && p[i+1]!='\0' && p[i+1]!='#';i++);
			   if (p[i+1]=='\0' || p[i+1]=='#' ) {
				al=0;
				continue;
   		           }
			   p+=i;
			}
		     } while(al);
		message_send(c,MT_WARN,c,buffer);
		free(buffer);
	}
	free(line);
     }
     return 0;
}



static int do_chat(t_connection * c,char const * cmd,char const * tname)
{
	char *line;
	unsigned int i;
	while ((line=file_get_line(cfd))!=NULL)
	{
	for (i=0;line[i]==' ';i++);
	if (line[i]=='@')
	{
		char * p, * msgtmp;
		int al,length;
		unsigned int j;
		char const * uname;
		p=line+i;
		do {
		     al=0;
	   	     for (i=1;p[i]!=' ' && p[i]!='#' && p[i]!='\0';i++);
	  	     if (p[i]==' ') al=1;
		     p[i]='\0';
		     if (strcasecmp(cmd,p+1)==0) {
				free(line);
				if (tname[0]!='\0') {
					line=file_get_line(cfd);
					free(line);
				}
				line=file_get_line(cfd);	
				length=strlen(line);
				msgtmp=malloc(length+1);
				for (j=0,i=0;line[i]!='\0';) {
				
				   if (line[i]=='%') {
					char * aux;
					i++;
					aux=msgtmp;
					length+=USER_NAME_LEN;
					msgtmp=realloc(msgtmp,length+1);
					if (msgtmp==NULL) {
					   eventlog(eventlog_level_error,"do_chat","Could not realloc memory for msgtmp");
					   message_send(c,MT_ERROR,c,"Not Enough Memory");
					   free(aux);
					   free(line);
					   return 0;
					}

	   				  if (tolower(line[i])=='t') {
					   strncpy(&msgtmp[j],tname,strlen(tname));
					   j+=strlen(tname);
     				  	  }	
						
					  else if (tolower(line[i])=='u') {
					   uname=account_get_name(conn_get_account(c));
					   strncpy(&msgtmp[j],uname,strlen(uname));
					   j+=strlen(uname);
					   account_unget_name(uname);
					  }
					i++;
				    }
				    else msgtmp[j++]=line[i++];
				
				}	
				msgtmp[j]='\0';
				channel_message_send(conn_get_channel(c),MT_WARN,c,msgtmp);
				free(line);
				free(msgtmp);
				return 0;
			}
			if (al) {
			   for(;p[i+1]==' ';i++);
			   if (p[i+1]=='\0') {
				al=0;
				continue;	 
			   }
			}
			p+=i;
		   } while(al);
	    }	
	    free(line);
	}
	return -1;
}


extern int chatfile_init(char const * filename)
{
	if (filename==NULL) return -1;
	if (!(cfd=fopen(filename,"r"))) {
	     eventlog(eventlog_level_error,"chatfile_init","Error open chat file %s for reading(fopen: %s)",filename,strerror(errno));
	     return -1;
	}
	return 0;
}

extern void chatfile_unload(void)
{
	if (cfd!=NULL) fclose(cfd);
	cfd=NULL;
	return;
}


extern void handle_chat_command(t_connection * c, char const * text)
{
	unsigned int i,j;
	char cmd[MAX_COMMAND_LEN];
	char tname[USER_NAME_LEN];
	t_channel const * channel;
	

	if (prefs_get_allow_chatcmd()==0) {
		message_send(c,MT_WARN,c,"Emote is disabled");
		return;
	}
	if ( !(channel=conn_get_channel(c)) ) {
		message_send(c,MT_ERROR,c,"You are not in a channel");
		return;
	}

	if (cfd==NULL) {
		message_send(c,MT_WARN,c,"There is some problems with the emote,please contact the server admin");
		return;
	}
 	rewind(cfd);
	for (i=0;text[i]!=' ' && text[i]!='\0';i++);
		if (i>sizeof(cmd)-1) {
			eventlog(eventlog_level_debug,"handle_chat_command","Too long chat commands %s",text);
			message_send(c,MT_ERROR,c,"Too long chat commands");
			return;
		}
		strncpy(cmd,text,i);
		cmd[i]='\0';
	for (;text[i]==' ';i++);
	for (j=0;text[i]!=' ' && text[i]!='\0';i++)
		if (j<sizeof(tname)-1) tname[j++]=text[i];

	tname[j]='\0';
	if (cmd[0]=='\0') {
		list_chats(c);
		return;
	}
	if (tname[0]!='\0') {
	
	   if (channel_check_user(channel,tname)!=0) {
		message_send(c,MT_WARN,c,"This user is not in your channel.");
		return;
	   }

	   {
		char const * uname;
		uname=account_get_name(conn_get_account(c));
		if (strcasecmp(tname,uname)==0) {
		strcpy(tname,prefs_get_chat_himself());
		}
		account_unget_name(uname);
	    }
	}
	if (do_chat(c,cmd,tname)==0) return;
	message_send(c,MT_WARN,c,"No Such Chat,use // to see the list");
	return;
}
