/*
 * Copyright (C) 2000  Onlyer (onlyer@263.net)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#include "config.h"
#include "setup.h"

#include <stdio.h>
#include <errno.h>                                                                           

#define USE_STDC_HEADERS
#define USE_STRING_HEADERS
#define USE_FCNTL_HEADERS
#define USE_UNISTD_HEADERS
#define USE_SYS_TYPES_HEADERS
#define USE_SYS_STAT_HEADERS

#include "compat.h"
                                                                                             
#include "compat/strdup.h"
#include "compat/psock.h"

#include "d2game.h"
#include "game.h"
#include "connection.h"
#include "virtconn.h"
#include "packet.h"
#include "hexdump.h"
#include "queue.h"
#include "util.h"
#include "eventlog.h"
#include "prefs.h"
#include "field_sizes.h"                                                                     
#include "bn_type.h"                                                                         
#include "d2charfile.h"                                                                     



static int packet_dump_append (int socket,t_packet * packet,t_packet_dir packet_dir);
static int packet_dump_changed (int socket,t_packet * packet,t_packet_dir packet_dir);
static int d2game_sendcharinfo(t_virtconn * vc);
static t_packet * d2game_getcharinfo(t_virtconn * vc, unsigned int fd);
static int d2game_creategame(t_virtconn * vc);
static int d2game_savecharfile(t_virtconn * vc,t_packet * packet);
static int d2game_restore_charfile(char const * charname);
static int d2game_sendclientmessage(t_virtconn * vc, char const * message);
static int d2game_checksavefile(char const * charname,unsigned int fd);
static int d2game_checkfullsave(t_virtconn * vc, int fd);



extern int d2game_handle_client_packet(t_virtconn * vc,t_packet * packet)
{
    char * olddata;
    int changed;
    int csocket;
    int delpacket;

    changed=0;
    delpacket=0;
    if (!vc) {
	eventlog(eventlog_level_error,"d2game_handle_client_packet","got NULL virtconn");
	return 0;
    }
    else csocket=virtconn_get_client_socket(vc);
    if (!packet) {
        eventlog(eventlog_level_error,"d2game_handle_client_packet","got NULL packet");
	return 0;
    }
    olddata=packet_get_raw_data(packet,0);
    if (!olddata) {
    	 eventlog(eventlog_level_error,"d2game_handle_client_packet","packet have NULL data");
	 return 0;
    }

    switch (packet_get_type(packet)) 
    {
	case D2GAME_CLIENT_UNKNOWN_66:
		/*
		if (virtconn_get_state(vc) == virtconn_state_login ) {
		    t_packet * npacket;
		    npacket=packet_create(packet_class_d2game);
		    packet_set_size(npacket,sizeof(t_d2game_server_unknown_8f));
		    packet_set_type(npacket,D2GAME_SERVER_UNKNOWN_8F);
		    bn_int_set(&npacket->u.d2game_server_unknown_8f.unknown1,0);
		    bn_int_set(&npacket->u.d2game_server_unknown_8f.unknown2,0);
		    bn_int_set(&npacket->u.d2game_server_unknown_8f.unknown3,0);
		    bn_int_set(&npacket->u.d2game_server_unknown_8f.unknown4,0);
		    bn_int_set(&npacket->u.d2game_server_unknown_8f.unknown5,0);
		    bn_int_set(&npacket->u.d2game_server_unknown_8f.unknown6,0);
		    bn_int_set(&npacket->u.d2game_server_unknown_8f.unknown7,0);
		    queue_push_packet(virtconn_get_clientout_queue(vc),npacket);
		    packet_dump_append(csocket,npacket,packet_dir_from_client);
		    packet_del_ref(npacket);
		}
		*/
		break;
	
	case D2GAME_CLIENT_JOINACTREQ:	    /* 0x64 */
		if (virtconn_get_state(vc) != virtconn_state_in_game ) {
		    d2game_sendcharinfo(vc);
		}
		else delpacket=1;
		break;
	    
	case D2GAME_CLIENT_JOINGAMEREQ:	/* 0x61 */
	    {
	    char charname[CHAR_NAME_LEN];
	    unsigned int id;
	    char * tempname;
	    t_game * game;
	    t_connection * c;

	    if (virtconn_get_state(vc) == virtconn_state_login ) {
	    if (packet_get_size(packet)<sizeof(t_d2game_client_joingamereq))
	    {
		eventlog(eventlog_level_error,"d2game_handle_client_packet","[%d] got bad D2GAME_CLIENT_JOINGAMEREQ packet (expected %u bytes, got %u)",csocket,sizeof(t_d2game_client_joingamereq),packet_get_size(packet));
		virtconn_set_state(vc,virtconn_state_destroy);
		break;
	    }
	    
	    game=gamelist_find_game_by_id(bn_short_get(packet->u.d2game_client_joingamereq.token));
	    if (!game) {
		eventlog(eventlog_level_error,"d2game_handle_client_packet","got NULL game for D2GAME_CLIENT_JOINGAMEREQ packet");
		virtconn_set_state(vc,virtconn_state_destroy);
		break;
	    }

	    id=game_get_token(game);
	    bn_short_set(&packet->u.d2game_client_joingamereq.gameid,(unsigned short)id);

	    strncpy(charname,packet->u.d2game_client_joingamereq.charname,CHAR_NAME_LEN);
	    if (!charname) 
	    {
		eventlog(eventlog_level_error,"d2game_handle_client_packet","got NULL char name");
		virtconn_set_state(vc,virtconn_state_destroy);
		break;
	    }
	    if (!(c=connlist_find_connection_by_charname(charname))) {
		eventlog(eventlog_level_error,"d2game_handle_client_packet","got NULL connection for charname %s",charname);
		virtconn_set_state(vc,virtconn_state_destroy);
		break;
	    }
	    if (!(conn_get_bind(c))) {
		eventlog(eventlog_level_error,"d2game_handle_client_packet","got NULL auth connection for client");
		virtconn_set_state(vc,virtconn_state_destroy);
		break;
	    }
	    virtconn_set_name(vc,charname);
	    virtconn_set_game(vc,game); 
	    if (virtconn_connect(vc)<0) {
		virtconn_set_state(vc,virtconn_state_destroy);
		break;
	    }
	    virtconn_bind(vc,conn_get_bind(c));
	    conn_set_virtbound(conn_get_bind(c),vc);
	    if (!prefs_get_d2savedir()) return -1; 
	    if (!virtconn_get_name(vc)) return -1;
	    tempname=malloc(strlen(prefs_get_d2savedir())+1+strlen(virtconn_get_name(vc))+1);
	    if (!tempname) {
		eventlog(eventlog_level_error,"d2game_handle_client_packet","could not allocate memory for tempname");
		break;
	    }
	    sprintf(tempname,"%s/%s",prefs_get_d2savedir(),virtconn_get_name(vc));
	    virtconn_set_savefile(vc,tempname);
	    free(tempname);

	    if (game_get_created(game)==0) {
		    delpacket=1;
		    d2game_creategame(vc);
		    game_set_created(game,1);
		    eventlog(eventlog_level_info,"d2game_handle_client_packet","new game %s(%d) created for %s",game_get_name(game),id,charname);
		    break;
	    }
	    eventlog(eventlog_level_info,"d2game_handle_client_packet","user %s joined game %s(%d)",charname,game_get_name(game),id);
	    changed=1;
	    }
	    break;
	    }
	   
	case D2GAME_CLIENT_QUITGAME:	/* 0x62 */
	    virtconn_set_state(vc,virtconn_state_quitting);
	    virtconn_set_quittime(vc,time(NULL));
	    eventlog(eventlog_level_info,"d2game_handle_client_packet","user %s left game",virtconn_get_name(vc));
	    break;
	
	default:
	    break;
    
    }

    if (hexstrm && changed )
    {
	packet_dump_changed(csocket,packet,packet_dir_from_client);
    }
    if (delpacket) return 1;
    else return 0;
}

extern int d2game_handle_server_packet(t_virtconn * vc,t_packet * packet)
{
    char * olddata;
    int changed;
    int ssocket;
    int delpacket=0;
    unsigned int saveleft;

    changed=0;
    if (!vc) {
	eventlog(eventlog_level_error,"d2game_handle_server_packet","got NULL virtconn");
	return 0;
    }
    else ssocket=virtconn_get_server_socket(vc);
    if (!packet) {
        eventlog(eventlog_level_error,"d2game_handle_server_packet","got NULL packet");
	return 0;
    }
    olddata=packet_get_raw_data(packet,0);
    if (!olddata) {
    	 eventlog(eventlog_level_error,"d2game_handle_server_packet","packet have NULL data");
	 return 0;
    }
    saveleft=virtconn_get_saveleft(vc);
	
    if (saveleft!=0) {
#ifdef DEBUG_D2GAME
	eventlog(eventlog_level_debug,"d2game_handle_server_packet","found a packet (%d bytes) for continuing save file",packet_get_size(packet));
#endif
	d2game_savecharfile(vc,packet);
	virtconn_set_saveleft(vc,0);
	packet_set_size(packet,packet_get_size(packet)-saveleft);
	if (packet_get_size(packet)==0) {
	    return 1;
	}
	memmove(olddata,&olddata[saveleft],packet_get_size(packet));
	packet_dump_changed(ssocket,packet,packet_dir_from_server);
    }
	
	
    switch(packet_get_type(packet))
    {
	case D2GAME_SERVER_WELCOME:
	    delpacket=1;
	    break;

	case D2GAME_SERVER_JOINOK:
	    {
		t_game * game;
		if (!(game=virtconn_get_game(vc))) {
		    eventlog(eventlog_level_error,"d2game_handle_server_packet","got NULL game for virtconn");
		    virtconn_set_state(vc,virtconn_state_destroy);
		}
		else {
		    if (game_get_created(game)==1 && game_get_newgame(game)==1) game_set_newgame(game,0);
		}
	    }
	    break;
    
        case D2GAME_SERVER_ERROR:	/* 0x20 */
	    if (packet_get_size(packet)<sizeof(t_d2game_server_error))
	    {
		eventlog(eventlog_level_error,"d2game_handle_server_packet","[%d] got bad D2GAME_SERVER_ERROR packet (expected %u bytes, got %u)",ssocket,sizeof(t_d2game_server_error),packet_get_size(packet));
		break;
	    }
	    {
		unsigned int errorno;
		char const * charname;
		charname=virtconn_get_name(vc);
		errorno=bn_int_get(packet->u.d2game_server_error.errorno);
		if (virtconn_get_state(vc)!=virtconn_state_in_game) {
		/*
		packet_set_type(packet,D2GAME_SERVER_NOOP);
		*/
		delpacket=1;
		changed=1;
		eventlog(eventlog_level_debug,"d2game_handle_server_packet","replaced a server error packet(errorno:%d)",errorno);
		}
		else {
		    eventlog(eventlog_level_debug,"d2game_handle_server_packet","got a server error packet(errorno:%d)",errorno);
		    if ((errorno>6 && errorno<15) || (errorno>0 && errorno<6)) {
			eventlog(eventlog_level_debug,"d2game_handle_server_packet","trying to restore char %s due to error %d",charname,errorno);
			if (!d2game_restore_charfile(virtconn_get_name(vc))) {
			    eventlog(eventlog_level_debug,"d2game_handle_server_packet","character %s restored successfully",charname);
			}
			else {
			    eventlog(eventlog_level_debug,"d2game_handle_server_packet","character %s restored failed",charname);
			}

		    }
		}
	    }
	    break;


	case D2GAME_SERVER_CLOSEGAME:	    /* 0x98 */
	    eventlog(eventlog_level_info,"d2game_handle_server_packet","server closed game for user %s",virtconn_get_name(vc));
	    break;
	
	case D2GAME_SERVER_UNKNOWN_8F:		/* 0x8f */
	    break;
		    
	case D2GAME_SERVER_PLAYERSAVE:	    /* 0x9b */
	    if (packet_get_size(packet)<sizeof(t_d2game_server_playersave))
	    {
		eventlog(eventlog_level_error,"d2game_handle_server_packet","[%d] got bad D2GAME_SERVER_PLAYERSAVE packet (expected %u bytes, got %u)",ssocket,sizeof(t_d2game_server_playersave),packet_get_size(packet));
		break;
	    }
	    if (!prefs_allow_d2localsave()) delpacket=1;
	    if (d2game_savecharfile(vc,packet)==1) {
		if (virtconn_get_quittime(vc)) {
		    eventlog(eventlog_level_debug,"d2game_handle_server_packet","%s saved sucessfully after quit game",virtconn_get_name(vc));
		    virtconn_set_state(vc,virtconn_state_destroy);
		}
		else d2game_sendclientmessage(vc,"Your character saved sucessfully");
	    }
	    break;

	default:
	    break;
		
    }
	

    if (hexstrm && changed )
    {
	packet_dump_changed(ssocket,packet,packet_dir_from_server);
    }
    if (delpacket) return 1;
    else return 0;
}


static int packet_dump_changed (int socket,t_packet * packet,t_packet_dir packet_dir) 
{
	if (!hexstrm) return 0;
	if (packet_dir==packet_dir_from_client) {
	    fprintf(hexstrm,"%d: cli  class=raw[changed] type=%s[0x%04hx] length=%hu\n",
		    socket,
		    packet_get_type_str(packet,packet_dir_from_client),packet_get_type(packet),
		    packet_get_size(packet));
	}
	else if (packet_dir==packet_dir_from_server) {
	    fprintf(hexstrm,"%d: srv  class=raw[changed] type=%s[0x%04hx] length=%hu\n",
		    socket,
		    packet_get_type_str(packet,packet_dir_from_server),packet_get_type(packet),
		    packet_get_size(packet));
	}
	else return 1;
	hexdump(hexstrm,packet_get_raw_data_const(packet,0),packet_get_size(packet));
	return 0;
}



static int packet_dump_append (int socket,t_packet * packet,t_packet_dir packet_dir) 
{
	if (!hexstrm) return 0;
	if (packet_dir==packet_dir_from_client) {
	    fprintf(hexstrm,"%d: cli class=d2game[append] type=%s[0x%04hx] length=%hu\n",
		    socket,
		    packet_get_type_str(packet,packet_dir_from_client),packet_get_type(packet),
		    packet_get_size(packet));
	}
	else if (packet_dir==packet_dir_from_server) {
	    fprintf(hexstrm,"%d: srv class=d2game[append] type=%s[0x%04hx] length=%hu\n",
		    socket,
		    packet_get_type_str(packet,packet_dir_from_server),packet_get_type(packet),
		    packet_get_size(packet));
	}
	else return 1;
	hexdump(hexstrm,packet_get_raw_data_const(packet,0),packet_get_size(packet));
	return 0;
}


static int d2game_creategame(t_virtconn * vc)
{
   char const * charname;
   t_packet * npacket;
   int csocket;
   unsigned int difficulty;
   unsigned int class;
   unsigned int gameflag;
   t_game * game;
   

   if (!vc) {
	eventlog(eventlog_level_error,"d2game_creategame","got NULL virtconn");
	return -1;
   }
   csocket=virtconn_get_client_socket(vc);
   if (!(charname=virtconn_get_name(vc))) {
	eventlog(eventlog_level_error,"d2game_creategame","no charname for virtconn");
	return -1;
   }
   game=virtconn_get_game(vc);
   if (!game) {
	eventlog(eventlog_level_error,"d2game_creategame","got NULL game");
	return -1;
   }
   difficulty=game_get_difficulty(game)/0x10;
   if (difficulty > 2) difficulty=0;
   class=d2char_getclass(charname);
   gameflag=4;
   if (d2char_gethardcore(charname)==1) gameflag |= 0x800;

   if (!(npacket=packet_create(packet_class_d2game))) {
	eventlog(eventlog_level_error,"d2game_creategame","could not allocate d2game packet for create new game");
	return -1;
   }
   packet_set_size(npacket,sizeof(t_d2game_client_creategamereq));
   packet_set_type(npacket,D2GAME_CLIENT_CREATEGAMEREQ);
   bn_byte_set(&npacket->u.d2game_client_creategamereq.template,0x0);
   bn_byte_set(&npacket->u.d2game_client_creategamereq.unknownb2,0x0);
   bn_byte_set(&npacket->u.d2game_client_creategamereq.unknownb3,0x0);
   bn_short_set(&npacket->u.d2game_client_creategamereq.arena,0x0);
   bn_byte_set(&npacket->u.d2game_client_creategamereq.servertype,0x2);
   bn_byte_set(&npacket->u.d2game_client_creategamereq.class,(unsigned char)class);
   bn_byte_set(&npacket->u.d2game_client_creategamereq.difficulty,(unsigned char)difficulty);
   bn_int_set(&npacket->u.d2game_client_creategamereq.gameflag,gameflag);
   strncpy(npacket->u.d2game_client_creategamereq.charname,charname,16);
   strncpy(npacket->u.d2game_client_creategamereq.gamename,game_get_name(game),16);
   queue_push_packet(virtconn_get_serverout_queue(vc),npacket);
   packet_dump_append(csocket,npacket,packet_dir_from_client);
   if (game_get_newgame(game)==1) game_set_newgame(game,0);
   packet_del_ref(npacket);
   virtconn_set_readedsize(vc,0);
   return 0;

}



static t_packet * d2game_getcharinfo(t_virtconn * vc,unsigned int fd)
{
    unsigned int file_size;
    unsigned int readedsize;
    unsigned int i;
    char buffer[MAX_SAVE_PACKET_SIZE];
    t_packet * npacket;

    
    file_size=lseek(fd,0,SEEK_END);
    readedsize=virtconn_get_readedsize(vc);
    if (readedsize>=file_size) {
	    close(fd);
	    return NULL;
    }

    lseek(fd,readedsize,SEEK_SET);
    i=read(fd,buffer,MAX_SAVE_PACKET_SIZE);
    if (i==0) {
	close(fd);
	return NULL;
    }
    virtconn_add_readedsize(vc,i);
    if (!(npacket=packet_create(packet_class_d2game))) {
	eventlog(eventlog_level_error,"d2game_getcharinfo","could not allocate npacket");
	return NULL;
    }
    packet_set_size(npacket,sizeof(t_d2game_client_playersave));
    packet_set_type(npacket,D2GAME_CLIENT_PLAYERSAVE);
    bn_byte_set((bn_byte *)npacket->u.d2game_client_playersave.size,(unsigned char)i);
    bn_int_set((bn_int *)npacket->u.d2game_client_playersave.total_size,file_size);
    packet_append_data(npacket,buffer,i);
    packet_append_data(npacket,"\x00",1);
    return npacket;
}

static int d2game_sendcharinfo(t_virtconn * vc)
{
    t_packet * npacket;
    unsigned int ssocket;
    int fd;
    char * tempname;

    ssocket=virtconn_get_server_socket(vc);
    if (!(tempname=virtconn_get_savefile(vc))) return -1;
    if ((fd=open(tempname,O_RDONLY|O_BINARY))==-1) {
	    eventlog(eventlog_level_debug,"d2game_handle_server_packet","no user file %s(open:%s) ",tempname,strerror(errno));
	    return -1;
    }
    while ((npacket=d2game_getcharinfo(vc,fd))) {
        queue_push_packet(virtconn_get_serverout_queue(vc),npacket);
        packet_dump_append(ssocket,npacket,packet_dir_from_client);
        packet_del_ref(npacket);
    }
    close(fd);
    virtconn_set_state(vc,virtconn_state_in_game);

    eventlog(eventlog_level_debug,"d2game_handle_server_packet","sending user %s info to server", virtconn_get_name(vc));
    return 0;

}


static int d2game_sendclientmessage(t_virtconn * vc, char const * message)
{
    t_packet * npacket;
    int	csocket;

    if (!vc) {
       eventlog(eventlog_level_error,"d2game_sendclientmessage","got NULL connection");
       return -1;
    }

    if (!message) {
	eventlog(eventlog_level_error,"d2game_sendclientmessage","got NULL message");
	return -1;
    }
    csocket=virtconn_get_client_socket(vc);
    npacket=packet_create(packet_class_d2game);
    packet_set_size(npacket,sizeof(t_d2game_server_chat_message));
    packet_set_type(npacket,D2GAME_SERVER_CHAT_MESSAGE);
    bn_short_set(&npacket->u.d2game_server_chat_message.unknown1,D2GAME_SERVER_CHAT_MESSAGE_UNKNOWN1);
    bn_int_set(&npacket->u.d2game_server_chat_message.unknown2,D2GAME_SERVER_CHAT_MESSAGE_UNKNOWN2);
    bn_short_set(&npacket->u.d2game_server_chat_message.unknown3,D2GAME_SERVER_CHAT_MESSAGE_UNKNOWN3);
    bn_byte_set(&npacket->u.d2game_server_chat_message.unknown4,D2GAME_SERVER_CHAT_MESSAGE_UNKNOWN4);
    packet_append_string(npacket,"SERVER");
    packet_append_string(npacket,message);
    packet_dump_append(csocket,npacket,packet_dir_from_client);
    queue_push_packet(virtconn_get_clientout_queue(vc),npacket);
    packet_del_ref(npacket);
    return 0;
}



static int d2game_savecharfile(t_virtconn * vc,t_packet * packet)
{
    char * tempfile;
    int start;
    unsigned int file_size;
    unsigned int i=0,j=0;
    int fd;
    char * olddata;
    unsigned int saveleft;

    if (!vc) {
	eventlog(eventlog_level_error,"d2game_savecharfile","got NULL connection");
	return -1;
    }
    if (!packet) {
	eventlog(eventlog_level_error,"d2game_savecharfile","got NULL packet");
	return -1;
    }
    olddata=packet_get_raw_data(packet,0);
    if (!olddata) {
    	 eventlog(eventlog_level_error,"d2game_handle_server_packet","packet have NULL data");
	 return 0;
    }
    if (!prefs_get_d2savedir()) {
	eventlog(eventlog_level_debug,"d2game_savecharfile","no d2 save dir set,could not save char");
	return -1;
    }
    if (!virtconn_get_name(vc)) {
	eventlog(eventlog_level_error,"d2game_savecharfile","got NULL charname");
	return -1;
    }
    if (!(tempfile=malloc(strlen(prefs_get_d2savedir())+6+strlen(virtconn_get_name(vc))+1))) {
	eventlog(eventlog_level_error,"d2game_savecharfile","could not allocate tempfile");
	return -1;
    }
    sprintf(tempfile,"%s/temp/%s",prefs_get_d2savedir(),virtconn_get_name(vc));
    if (virtconn_get_saveleft(vc)!=0) {
	file_size=virtconn_get_savefilesize(vc);
	if (packet_get_size(packet)<virtconn_get_saveleft(vc)) {
	    eventlog(eventlog_level_error,"d2game_savecharfile","continuing save info have bad size");
	    free(tempfile);
	    return -1;
	}
	fd=open(tempfile,O_RDWR|O_APPEND|O_BINARY);
	free(tempfile);
	if (fd==-1) {
	    eventlog(eventlog_level_debug,"d2game_savecharfile","Error save user file %s(open:%s)",tempfile,strerror(errno));
	    return -1;
	}
	write(fd,olddata,virtconn_get_saveleft(vc));
	virtconn_add_savedsize(vc,virtconn_get_saveleft(vc));
	d2game_checkfullsave(vc,fd);
	return 0;
    }
    start=bn_byte_get(packet->u.d2game_server_playersave.start);
    if (start==1) {
	 if (virtconn_get_savedsize(vc)!=0) {
	     eventlog(eventlog_level_error,"d2game_savecharfile","last time save for %s is not complete,left size is (%d/%d)",virtconn_get_name(vc),virtconn_get_savedsize(vc),virtconn_get_savefilesize(vc));
	     virtconn_set_savedsize(vc,0);
	 }
	 file_size=bn_int_get(packet->u.d2game_server_playersave.total_size);
	 virtconn_set_savefilesize(vc,file_size);
	 eventlog(eventlog_level_debug,"d2game_savecharfile","got user %s starting save info(%d bytes)",virtconn_get_name(vc),file_size);
	 fd=open(tempfile,O_RDWR|O_TRUNC|O_CREAT|O_BINARY,S_IREAD|S_IWRITE);
    }
    else {
	file_size=virtconn_get_savefilesize(vc);
	if (file_size!=bn_int_get(packet->u.d2game_server_playersave.total_size)) {
	eventlog(eventlog_level_error,"d2game_savecharfile","continuing save info size(%d) for user %s not match the starting one(%d)",bn_int_get(packet->u.d2game_server_playersave.total_size),virtconn_get_name(vc),file_size);
	return -1;
	}
	fd=open(tempfile,O_RDWR|O_APPEND|O_BINARY);
    }
    free(tempfile);
    if (fd==-1) {
	eventlog(eventlog_level_debug,"d2game_savecharfile","Error save user file %s(open:%s)",tempfile,strerror(errno));
	return -1;
   }
   while (1) {
	i=bn_byte_get(&olddata[1+j]);
	if ((j+sizeof(t_d2game_server_playersave)+i)>packet_get_size(packet)) {
	    i=packet_get_size(packet)-j-sizeof(t_d2game_server_playersave);
	    saveleft=bn_byte_get(&olddata[1+j])-i;
	    virtconn_set_saveleft(vc,saveleft);
#ifdef DEBUG_D2GAME
	    eventlog(eventlog_level_debug,"d2game_savecharfile","j=%d i=%d",j,i);
	    eventlog(eventlog_level_error,"d2game_savecharfile","save info not ended,%d bytes left",saveleft);
#endif
	}
	if (file_size!=bn_int_get(&olddata[3+j])) {
	    eventlog(eventlog_level_error,"d2game_savecharfile","continuing save info size(%d) for user %s not match the starting one(%d)",bn_int_get(&olddata[3+j]),virtconn_get_name(vc),file_size);
	    break;
	}
	write(fd,&olddata[j+sizeof(t_d2game_server_playersave)],i);
	j+=sizeof(t_d2game_server_playersave)+i;
	virtconn_add_savedsize(vc,i);
#ifdef	DEBUG_D2GAME
	eventlog(eventlog_level_debug,"debug","user %s current saved size is %d",virtconn_get_name(vc),virtconn_get_savedsize(vc));
#endif

	if ( j==packet_get_size(packet) || bn_byte_get(&olddata[j])!=D2GAME_SERVER_PLAYERSAVE)	{
	    if (d2game_checkfullsave(vc,fd)==1) {
		return 1;
	    }
	    else return 0;
	}
    }
    close(fd);
    return 0;
}

static int d2game_checksavefile(char const * charname,unsigned int fd)
{
    t_d2save * buffer;
    int size;

    size=lseek(fd,0,SEEK_END);
    
    if (size<D2SAVE_NEWBIE_SIZE) {
	eventlog(eventlog_level_error,"d2game_checksavefile","bad save file size %d for %s\n",size,charname);
	return -1;
    }
    if (!(buffer=malloc(sizeof(t_d2save)))) {
	eventlog(eventlog_level_error,"d2game_checksavefile","could not allocate memory for buffer");
	return -1;
    }
    lseek(fd,0,SEEK_SET);
    if (read(fd,buffer,D2SAVE_NEWBIE_SIZE)!=D2SAVE_NEWBIE_SIZE) {
	eventlog(eventlog_level_error,"d2game_checksavefile","got bad save file or read error(read:%s)",strerror(errno));
	free(buffer);
	return -1;
    }
    if (memcmp(buffer->h,D2SAVE_HEADER,8)!=0) {
	eventlog(eventlog_level_error,"d2game_checksavefile","got bad save save file mismatch D2SAVE_HEADER");
	free(buffer);
	return -1;
    }
    if (strncmp(buffer->name,charname,CHAR_NAME_LEN)!=0) {
	eventlog(eventlog_level_error,"d2game_checksavefile","got bad save save file mismatch charname");
	free(buffer);
	return -1;
    }
    if (size>D2SAVE_NEWBIE_SIZE) {
	lseek(fd,D2SAVE_NEWBIE_SIZE,SEEK_SET);
	if (read(fd,buffer,D2SAVE_GAMEDATA_LEN)!=D2SAVE_GAMEDATA_LEN) {
	    eventlog(eventlog_level_error,"d2game_checksavefile","read gamedata for char file %s error,(read:%s)\n",charname,strerror(errno));
	    free(buffer);
	    return -1;
	}
	if (memcmp(buffer,D2SAVE_GAMEDATA_HEADER,D2SAVE_GAMEDATA_LEN)!=0) {
	    eventlog(eventlog_level_error,"d2game_checksavefile","gamedata header for %s mismatch\n",charname);
	    free(buffer);
	    return -1;
	}
    }
    free(buffer);
    return 0;
}

static int d2game_checkfullsave(t_virtconn * vc, int fd)
{
	char * savefile;
	char * backfile;
	char * tempfile;
	unsigned int file_size;

	file_size=virtconn_get_savefilesize(vc);
	if (virtconn_get_savedsize(vc)==file_size && file_size!=0 ) {
	    eventlog(eventlog_level_debug,"d2game_savecharfile","got a full user file %s",virtconn_get_name(vc));
	    if (d2game_checksavefile(virtconn_get_name(vc),fd)<0) {
	       eventlog(eventlog_level_error,"d2game_savecharinfo","save file check failed,ingnore it");
	       close(fd);
	       return -1;
	    }	
	    close(fd);
	    savefile=virtconn_get_savefile(vc);
	    if (!savefile) {
	       eventlog(eventlog_level_error,"d2game_savecharfile","got NULL savefile");
	       return -1;
	    }
	    if (!(backfile=malloc(strlen(prefs_get_d2savedir())+5+strlen(virtconn_get_name(vc))+1))) {
		eventlog(eventlog_level_error,"d2game_savecharfile","could not allocate backfile");
		return -1;
	    }
	    sprintf(backfile,"%s/bak/%s",prefs_get_d2savedir(),virtconn_get_name(vc));
	    unlink(backfile);
	    if (rename(savefile,backfile)==-1) {
		eventlog(eventlog_level_error,"d2game_savecharfile","error backup char %s(rename:%s)",savefile,strerror(errno));
		free(backfile);
		return -1;
	    }
	    if (!(tempfile=malloc(strlen(prefs_get_d2savedir())+6+strlen(virtconn_get_name(vc))+1))) {
		eventlog(eventlog_level_error,"d2game_savecharfile","could not allocate tempfile");
		free(backfile);
		return -1;
	    }
	    sprintf(tempfile,"%s/temp/%s",prefs_get_d2savedir(),virtconn_get_name(vc));
	    if (rename(tempfile,savefile)==-1) {
		eventlog(eventlog_level_error,"d2game_savecharfile","error save char %s(rename:%s)",savefile,strerror(errno));
		free(backfile);
		free(tempfile);
		return -1;
	    }
	    free(tempfile);
	    free(backfile);
	    eventlog(eventlog_level_error,"d2game_savecharfile","Successfully saved %s(%d bytes)",virtconn_get_name(vc),file_size);
	    virtconn_set_savedsize(vc,0);
	    return 1;
	}
	close(fd);
	return 0;
}

static int d2game_restore_charfile(char const * charname)
{
    char * savefile;
    char * backfile;
    int fd;
    if (!charname) {
	eventlog(eventlog_level_error,"d2game_restore_charfile","got NULL charname");
	return -1;
    }
    if (d2char_findcharfile(charname)!=1) {
	eventlog(eventlog_level_error,"d2game_restore_charfile","no such a character %s",charname);
	return -1;
    }
    if (!(backfile=malloc(strlen(prefs_get_d2savedir())+5+strlen(charname)+1))) {
	eventlog(eventlog_level_error,"d2game_restore_charfile","could not allocate backfile");
	return -1;
    }
    sprintf(backfile,"%s/bak/%s",prefs_get_d2savedir(),charname);
    if ((fd=open(backfile,O_RDONLY|O_BINARY))==-1) {
	eventlog(eventlog_level_error,"d2game_restore_charfile","no backup file for char %s,skippint retore",charname);
	free(backfile);
	return -1;
    }
    else close(fd);
    if (!(savefile=malloc(strlen(prefs_get_d2savedir())+1+strlen(charname)+1))) {
	eventlog(eventlog_level_error,"d2game_restore_charfile","could not allocate charfile");
	free(backfile);
	return -1;
    }
    sprintf(savefile,"%s/%s",prefs_get_d2savedir(),charname);
    unlink(savefile);
    if (rename(backfile,savefile)==-1) {
	eventlog(eventlog_level_error,"d2game_restore_charfile","rename %s to %s failed(rename:%s",backfile,savefile,strerror(errno));
    }
    free(savefile);
    free(backfile);
    return 0;
}


