/*
 * Copyright (C) 1998,1999,2000  Ross Combs (rocombs@cs.nmsu.edu)
 * Copyright (C) 2000  Marco Ziech (mmz@gmx.net)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#define ACCOUNT_INTERNAL_ACCESS
#include "config.h"
#include "setup.h"

#include <stdio.h>
#include <ctype.h>
#include <errno.h>


#define USE_STDDEF_HEADERS
#define USE_STDC_HEADERS
#define USE_STRING_HEADERS
#define USE_TIME_HEADERS
#define USE_UNISTD_HEADERS
#define USE_SYS_TYPES_HEADERS

#include "compat.h"

#include "compat/strtoul.h"
#include "compat/strchr.h"
#include "compat/strdup.h"
#include "compat/strcasecmp.h"
#include "compat/strerror.h"

#include "compat/pdir.h"
#include "eventlog.h"
#include "prefs.h"
#include "util.h"
#include "field_sizes.h"
#include "bnethash.h"
#include "list.h"
#include "account.h"


static t_list * accountlist_head=NULL;

static t_account * default_acct=NULL;
static unsigned int maxuserid=0;


static char * escape_chars(char const * in, unsigned int len);
static char * unescape_chars(char const * in);
static unsigned int account_hash(char const * username);
static int account_insert_attr(t_account * account, char const * key, char const * val);
static int account_load_attrs(t_account * account);
static void account_unload_attrs(t_account * account);
static t_account * account_load(char const * filename);



static char * escape_chars(char const * in, unsigned int len)
{
    char *       out;
    unsigned int inpos;
    unsigned int outpos;
    
    if (!in)
    {
	eventlog(eventlog_level_error,"escape_chars","got NULL input string");
	return NULL;
    }
    if (!(out = malloc(len*4+1))) /* if all turn into \xxx */
    {
	eventlog(eventlog_level_error,"escape_chars","could not allocate memory for string");
	return NULL;
    }
    
    for (inpos=0,outpos=0; inpos<len; inpos++)
    {
	if (in[inpos]=='\\')
	{
	    out[outpos++] = '\\';
	    out[outpos++] = '\\';
	}
	else if (in[inpos]=='"')
	{
	    out[outpos++] = '\\';
	    out[outpos++] = '"';
	}
        else if (isprint((int)in[inpos]))
	    out[outpos++] = in[inpos];
        else if (in[inpos]=='\a')
	{
	    out[outpos++] = '\\';
	    out[outpos++] = 'a';
	}
        else if (in[inpos]=='\b')
	{
	    out[outpos++] = '\\';
	    out[outpos++] = 'b';
	}
        else if (in[inpos]=='\t')
	{
	    out[outpos++] = '\\';
	    out[outpos++] = 't';
	}
        else if (in[inpos]=='\n')
	{
	    out[outpos++] = '\\';
	    out[outpos++] = 'n';
	}
        else if (in[inpos]=='\v')
	{
	    out[outpos++] = '\\';
	    out[outpos++] = 'v';
	}
        else if (in[inpos]=='\f')
	{
	    out[outpos++] = '\\';
	    out[outpos++] = 'f';
	}
        else if (in[inpos]=='\r')
	{
	    out[outpos++] = '\\';
	    out[outpos++] = 'r';
	}
	else
	{
	    out[outpos++] = '\\';
	    /* always 001 through 377 octal */
	    sprintf(&out[outpos],"%03o",(unsigned int)(unsigned char)in[inpos]);
	    outpos += 3;
	}
    }
    if (outpos>=len*4+1)
        eventlog(eventlog_level_error,"escape_chars","overflowed buffer!!! (outpos=%u len=%u)",outpos,len*4+1);
    out[outpos] = '\0';
    
    return out;
}


static char * unescape_chars(char const * in)
{
    char *       out;
    unsigned int inpos;
    unsigned int outpos;
    
    if (!in)
    {
	eventlog(eventlog_level_error,"unescape_chars","got NULL input string");
	return NULL;
    }
    if (!(out = malloc(strlen(in)+1)))
    {
	eventlog(eventlog_level_error,"unescape_chars","could not allocate memory for string");
	return NULL;
    }
    
    for (inpos=0,outpos=0; inpos<strlen(in); inpos++)
    {
        if (in[inpos]!='\\')
	    out[outpos++] = in[inpos];
        else
	    switch (in[++inpos])
	    {
	    case '\\':
		out[outpos++] = '\\';
		break;
	    case '"':
		out[outpos++] = '"';
		break;
	    case 'a':
		out[outpos++] = '\a';
		break;
	    case 'b':
		out[outpos++] = '\b';
		break;
	    case 't':
		out[outpos++] = '\t';
		break;
	    case 'n':
		out[outpos++] = '\n';
		break;
	    case 'v':
		out[outpos++] = '\v';
		break;
	    case 'f':
		out[outpos++] = '\f';
		break;
	    case 'r':
		out[outpos++] = '\r';
		break;
	    default:
	    {
		char         temp[4];
		unsigned int i;
		unsigned int num;
		
		for (i=0; i<3; i++)
		{
		    if (in[inpos]!='0' &&
		        in[inpos]!='1' &&
		        in[inpos]!='2' &&
		        in[inpos]!='3' &&
		        in[inpos]!='4' &&
		        in[inpos]!='5' &&
		        in[inpos]!='6' &&
		        in[inpos]!='7')
			break;
		    temp[i] = in[inpos++];
		}
		temp[i] = '\0';
		inpos--;
		
		num = strtoul(temp,NULL,8);
		if (i<3 || num<1 || num>255) /* bad escape (including \000), leave it as-is */
		{
		    out[outpos++] = '\\';
		    strcpy(&out[outpos],temp);
		    outpos += strlen(temp);
		}
		else
		    out[outpos++] = (unsigned char)num;
	    }
	}
    }
    out[outpos] = '\0';
    
    return out;
}


#define BITS_PER_BYTE 8
#define ROL(x,n) (((x)<<(n)) | ((x)>>((sizeof(unsigned int)*BITS_PER_BYTE)-(n))))

static unsigned int account_hash(char const * username)
{
    unsigned int i;
    unsigned int pos;
    unsigned int hash;
    
    if (!username)
    {
	eventlog(eventlog_level_error,"account_hash","got NULL username");
	return 0;
    }
    
    for (hash=0,pos=0,i=0; i<strlen(username); i++)
    {
	hash ^= ROL(((unsigned int)tolower((int)username[i])),
		    (pos%(sizeof(unsigned int)*BITS_PER_BYTE)));
	pos += BITS_PER_BYTE-1;
    }
    
    return hash;
}


extern t_account * account_create(char const * username, char const * passhash1)
{
    t_account * account;
    
    if (!(account = malloc(sizeof(t_account))))
    {
	eventlog(eventlog_level_error,"account_create","could not allocate memory for account");
	return NULL;
    }
    
    account->filename = NULL;
    account->attrs    = NULL;
    account->dirty    = 0;
    account->accessed = 0;
    account->age      = 0;
    
    account->namehash = 0; /* hash it later before inserting */
    account->uid      = 0; /* hash it later before insterting */
    
    if (username) /* actually making a new account */
    {
	char * temp;
	
	if (username[0]=='\0')
	{
	    eventlog(eventlog_level_error,"account_create","got empty username");
	    account_destroy(account);
	    return NULL;
	}
	if (username[0]=='#')
	{
	    eventlog(eventlog_level_error,"account_create","username starts with '#'");
	    account_destroy(account);
	    return NULL;
	}
	if (strchr(username,' '))
	{
	    eventlog(eventlog_level_error,"account_create","username contains spaces");
	    account_destroy(account);
	    return NULL;
	}
	if (strchr(username,','))
	{
	    eventlog(eventlog_level_error,"account_create","username contains ,");
	    account_destroy(account);
	    return NULL;
	}
	if (strlen(username)>=USER_NAME_LEN)
	{
	    eventlog(eventlog_level_error,"account_create","username is too long (%u chars)",strlen(username));
	    account_destroy(account);
	    return NULL;
	}
	if (!passhash1)
	{
	    eventlog(eventlog_level_error,"account_create","got NULL passhash1");
	    account_destroy(account);
	    return NULL;
	}
	
	if (!(temp = malloc(strlen(prefs_get_userdir())+1+8+1))) /* dir + / + uid  + NUL */
	{
	    eventlog(eventlog_level_error,"account_create","could not allocate memory for temp");
	    account_destroy(account);
	    return NULL;
	}
	/* sprintf(temp,"%s/%06u",prefs_get_userdir(),maxuserid+1); FIXME: hmm, maybe up the %06 to %08... */
	sprintf(temp,"%s/%s",prefs_get_userdir(),username);
	account->filename = temp;
	
        account->loaded = 1;
	
	account_set_strattr(account,"BNET\\acct\\username",username);
	account_set_numattr(account,"BNET\\acct\\userid",maxuserid+1);
	account_set_strattr(account,"BNET\\acct\\passhash1",passhash1);
	
    }
    else /* empty account to be filled in later */
    {
	account->filename = NULL;
	account->loaded   = 0;
    }
    
    return account;
}

static void account_unload_attrs(t_account * account)
{
    t_attribute const * attr;
    t_attribute const * temp;
    
/*    eventlog(eventlog_level_debug,"account_unload_attrs","unloading \"%s\"",account->filename);*/
    for (attr=account->attrs; attr; attr=temp)
    {
	if (attr->key)
	    free((void *)attr->key);
	if (attr->val)
	    free((void *)attr->val);
        temp = attr->next;
	free((void *)attr);
    }
    account->attrs = NULL;
    account->loaded = 0;
}


extern void account_destroy(t_account * account)
{
    if (!account)
    {
	eventlog(eventlog_level_error,"account_destroy","got NULL account");
	return;
    }
    account_unload_attrs(account);
    if (account->filename)
	free((void *)account->filename);
    free(account);
}


extern unsigned int account_get_uid(t_account const * account)
{
    if (!account)
    {
	eventlog(eventlog_level_error,"account_get_uid","got NULL account");
	return -1;
    }
    
    return account->uid;
}


extern int account_match(t_account * account, char const * username)
{
    unsigned int userid=0;
    unsigned int namehash;
    char const * tname;
    
    if (!account)
    {
	eventlog(eventlog_level_error,"account_match","got NULL account");
	return -1;
    }
    if (!username)
    {
	eventlog(eventlog_level_error,"account_match","got NULL username");
	return -1;
    }
    
    if (username[0]=='#')
        if (str_to_uint(&username[1],&userid)<0)
            userid = 0;
    
    if (userid)
    {
        if (account->uid==userid)
            return 1;
    }
    else
    {
	namehash = account_hash(username);
        if (account->namehash==namehash &&
	    (tname = account_get_name(account))) {
	    if (strcasecmp(tname,username)==0)
	    {
		account_unget_name(tname);
		return 1;
	    }
	    else
		account_unget_name(tname);
	}
    }
    
    return 0;
}


extern int account_save(t_account * account, unsigned int delta)
{
    FILE *        accountfile;
    t_attribute * attr;
    char const *  key;
    char const *  val;
    char *        tempname;
    
    if (!account)
    {
	eventlog(eventlog_level_error,"account_save","got NULL account");
	return -1;
    }

    
    /* account aging logic */
    if (account->accessed)
	account->age >>= 1;
    else
	account->age += delta;
    if (account->age>( (3*prefs_get_user_flush_timer()) >>1))
        account->age = ( (3*prefs_get_user_flush_timer()) >>1);
    account->accessed = 0;

    if (!account->filename)
    {
	eventlog(eventlog_level_error,"account_save","account "UID_FORMAT" has NULL filename",account->uid);
	return -1;
    }    
    if (!account->loaded)
	return 0;
    
    if (!account->dirty)
    {
	if (account->age>=prefs_get_user_flush_timer())
	    account_unload_attrs(account);
	return 0;
    }
    
    if (!(tempname = malloc(strlen(prefs_get_userdir())+1+strlen(BNETD_ACCOUNT_TMP)+1)))
    {
	eventlog(eventlog_level_error,"account_save","uable to allocate memory for tempname");
	return -1;
    }
    
    sprintf(tempname,"%s/%s",prefs_get_userdir(),BNETD_ACCOUNT_TMP);
    
    if (!(accountfile = fopen(tempname,"w")))
    {
	eventlog(eventlog_level_error,"account_save","unable to open file \"%s\" for writing (fopen: %s)",tempname,strerror(errno));
	free(tempname);
	return -1;
    }
    
    for (attr=account->attrs; attr; attr=attr->next)
    {
	if (attr->key)
	    key = escape_chars(attr->key,strlen(attr->key));
	else
	{
	    eventlog(eventlog_level_error,"account_save","attribute with NULL key in list");
	    key = NULL;
	}
	if (attr->val)
	    val = escape_chars(attr->val,strlen(attr->val));
	else
	{
	    eventlog(eventlog_level_error,"account_save","attribute with NULL val in list");
	    val = NULL;
	}
	if (key && val)
	    fprintf(accountfile,"\"%s\"=\"%s\"\n",key,val);
	else
	    eventlog(eventlog_level_error,"account_save","could not save attribute key=\"%s\"",attr->key);
	if (key)
	    free((void *)key);
	if (val)
	    free((void *)val);
    }
    
    if (fclose(accountfile)<0)
    {
	eventlog(eventlog_level_error,"account_save","could not close account file \"%s\" after writing (fclose: %s)",tempname,strerror(errno));
	free(tempname);
	return -1;
    }
    
#ifdef WIN32
    /* We are about to rename the temporary file
    * to replace the existing account.  In Windows,
    * we have to remove the previous file or the
    * rename function will fail saying the file
    * already exists.
    */
    if (access(account->filename, 0) == 0)
    {
       if (remove(account->filename)<0)
       {
           eventlog(eventlog_level_error,"account_save","could not delete account file \"%s\" (remove: %s)",account->filename,strerror(errno));
           free(tempname);
           return -1;
       }
    }
#endif
    
    if (rename(tempname,account->filename)<0)
    {
	eventlog(eventlog_level_error,"account_save","could not rename account file to \"%s\" (rename: %s)",account->filename,strerror(errno));
	free(tempname);
	return -1;
    }
    
    account->dirty = 0;
    
    free(tempname);
    return 1;
}


static int account_insert_attr(t_account * account, char const * key, char const * val)
{
    t_attribute * nattr;
    char *        nkey;
    char *        nval;
    
    if (!(nattr = malloc(sizeof(t_attribute))))
    {
	eventlog(eventlog_level_error,"account_insert_attr","could not allocate attribute");
	return -1;
    }
    if (!(nkey = strdup(key)))
    {
	eventlog(eventlog_level_error,"account_insert_attr","could not allocate attribute key");
	free(nattr);
	return -1;
    }
    if (!(nval = strdup(val)))
    {
	eventlog(eventlog_level_error,"account_insert_attr","could not allocate attribute value");
	free(nkey);
	free(nattr);
	return -1;
    }
    nattr->key  = nkey;
    nattr->val  = nval;
    nattr->next = account->attrs;
    
    account->attrs = nattr;
    
    return 0;
}


extern char const * account_get_strattr(t_account * account, char const * key)
{
    t_attribute const * curr;
    
    if (!account)
    {
	eventlog(eventlog_level_error,"account_get_strattr","got NULL account");
	return NULL;
    }
    if (!key)
    {
	eventlog(eventlog_level_error,"account_get_strattr","got NULL key");
	return NULL;
    }
    
    account->accessed = 1;
    
    if (!account->loaded)
        if (account_load_attrs(account)<0)
	{
	    eventlog(eventlog_level_error,"account_get_strattr","could not load attributes");
	    return NULL;
	}
    
    if (account->attrs)
	for (curr=account->attrs; curr; curr=curr->next)
	    if (strcasecmp(curr->key,key)==0)
	    {
#ifdef TESTUNGET
		return strdup(curr->val);
#else
                return curr->val;
#endif
	    }
    
    if (account==default_acct) /* don't recurse infinitely */
	return NULL;

    return account_get_strattr(default_acct,key); /* FIXME: this is sorta dangerous because this pointer can go away if we re-read the config files... verify that nobody caches non-username, userid strings */
}


extern void account_unget_strattr(char const * val)
{
    if (!val)
    {
	eventlog(eventlog_level_error,"account_unget_strattr","got NULL val");
	return;
    }
#ifdef TESTUNGET
    free((void *)val);
#endif
}

extern int account_set_strattr(t_account * account, char const * key, char const * val)
{
    t_attribute * curr;
    
    if (!account)
    {
	eventlog(eventlog_level_error,"account_set_strattr","got NULL account");
	return -1;
    }
    if (!key)
    {
	eventlog(eventlog_level_error,"account_set_strattr","got NULL key");
	return -1;
    }
    
    if (!account->loaded)
        if (account_load_attrs(account)<0)
	{
	    eventlog(eventlog_level_error,"account_set_strattr","could not load attributes");
	    return -1;
	}
    account->dirty = 1; /* will need to be saved */
    
    curr = account->attrs;
    if (!curr)
    {
	if (val)
	    return account_insert_attr(account,key,val);
	return 0;
    }
    
    if (strcasecmp(curr->key,key)==0) /* if key is already the first in the attr list */
    {
	if (val)
	{
	    char * temp;
	    
	    if (!(temp = strdup(val)))
	    {
		eventlog(eventlog_level_error,"account_set_strattr","could not allocate attribute value");
		return -1;
	    }
	    
	    free((void *)curr->val);
	    curr->val = temp;
	}
	else
	{
	    t_attribute * temp;
	    
	    temp = curr->next;
	    
	    free((void *)curr->key);
	    free((void *)curr->val);
	    free((void *)curr);
	    
	    account->attrs = temp;
	}
	return 0;
    }
    
    for (; curr->next; curr=curr->next)
	if (strcasecmp(curr->next->key,key)==0)
	    break;
    
    if (curr->next) /* if key is already in the attr list */
    {
	if (val)
	{
	    char * temp;
	    
	    if (!(temp = strdup(val)))
	    {
		eventlog(eventlog_level_error,"account_set_strattr","could not allocate attribute value");
		return -1;
	    }
	    
	    free((void *)curr->next->val);
	    curr->next->val = temp;
	}
	else
	{
	    t_attribute * temp;
	    
	    temp = curr->next->next;
	    
	    free((void *)curr->next->key);
	    free((void *)curr->next->val);
	    free(curr->next);
	    
	    curr->next = temp;
	}
	return 0;
    }
    
    if (val)
	return account_insert_attr(account,key,val);
    return 0;
}


static int account_load_attrs(t_account * account)
{
    FILE *       accountfile;
    unsigned int line;
    char const * buff;
    unsigned int len;
    char *       esckey;
    char *       escval;
    char const * key;
    char const * val;
    
    if (!account)
    {
	eventlog(eventlog_level_error,"account_load_attrs","got NULL account");
	return -1;
    }
    if (!account->filename)
    {
	eventlog(eventlog_level_error,"account_load_attrs","account has NULL filename");
	return -1;
    }
    
    if (account->loaded) /* already done */
	return 0;
    if (account->dirty) /* if not loaded, how dirty? */
    {
	eventlog(eventlog_level_error,"account_load_attrs","can not load modified account");
	return -1;
    }
    /* 
    eventlog(eventlog_level_debug,"account_load_attrs","loading \"%s\"",account->filename);
    */

    if (!(accountfile = fopen(account->filename,"r")))
    {
	eventlog(eventlog_level_error,"account_load_attrs","could not open account file \"%s\" for reading (fopen: %s)",account->filename,strerror(errno));
	return -1;
    }
    
    account->loaded = 1; /* set now so set_strattr works */
    for (line=1; (buff=file_get_line(accountfile)); line++)
    {
	if (buff[0]=='#' || buff[0]=='\0')
	{
	    free((void *)buff);
	    continue;
	}
	
	len = strlen(buff)-5+1; /* - ""="" + NUL */
	if (!(esckey = malloc(len)))
	{
	    eventlog(eventlog_level_error,"account_load_attrs","could not allocate memory for esckey on line %d of account file \"%s\"",line,account->filename);
	    free((void *)buff);
	    continue;
	}
	if (!(escval = malloc(len)))
	{
	    eventlog(eventlog_level_error,"account_load_attrs","could not allocate memory for escval on line %d of account file \"%s\"",line,account->filename);
	    free((void *)buff);
	    free(esckey);
	    continue;
	}
	
	if (sscanf(buff,"\"%[^\"]\" = \"%[^\"]\"",esckey,escval)!=2)
	{
	    if (sscanf(buff,"\"%[^\"]\" = \"\"",esckey)!=1) /* hack for an empty value field */
	    {
		eventlog(eventlog_level_error,"account_load_attrs","malformed entry on line %d of account file \"%s\"",line,account->filename);
		free(escval);
		free(esckey);
		free((void *)buff);
		continue;
	    }
	    escval[0] = '\0';
	}
	free((void *)buff);
	
	key = unescape_chars(esckey);
	val = unescape_chars(escval);
	
/* eventlog(eventlog_level_debug,"account_load_attrs","strlen(esckey)=%u (%c), len=%u",strlen(esckey),esckey[0],len);*/
	free(esckey);
	free(escval);
	
	if (key && val)
	    account_set_strattr(account,key,val);

	if (key)
	    free((void *)key);
	if (val)
	    free((void *)val);
    }
    
    fclose(accountfile);
    account->dirty = 0;

    return 0;
}


extern t_account * account_load_wrapper(char const * username)
{
    char * filename;
    t_account * account;
    if (!username)
    {
	eventlog(eventlog_level_error,"account_load_wrapper","got NULL username");
	return NULL;
    }
    if (!(filename=malloc(strlen(prefs_get_userdir())+1+strlen(username)+1))) {
	eventlog(eventlog_level_error,"account_load_wrapper","could not allocate memory for filename");
	return NULL;
    }
    sprintf(filename,"%s/%s",prefs_get_userdir(),username);
    if (access(filename,0)!=0) {
	eventlog(eventlog_level_error,"account_load_wrapper","account file %s not exist",filename);
	free(filename);
	return NULL;
    }
    if (!(account=account_load(filename))) {
	eventlog(eventlog_level_error,"account_load_wrapper","could not load account from file \"%s\"",filename
    );
	free(filename);
	return NULL;
    }
    if (!accountlist_add_account(account)) {
	eventlog(eventlog_level_error,"account_load_wrapper","could not add account from file \"%s\" to list",filename);
	free(filename);
	account_destroy(account);
	return NULL;
    }
    free(filename);
    return account;
}
    

extern int account_unload_wrapper(t_account * account)
{
    if (!account) {
	eventlog(eventlog_level_error,"account_unload_wrapper","got NULL account");
	return -1;
    }
    account_save(account,0);
    accountlist_remove_account(account);
    account_destroy(account);
    return 0;
}



static t_account * account_load(char const * filename)
{
    t_account * account;
    
    if (!filename)
    {
	eventlog(eventlog_level_error,"account_load","got NULL filename");
	return NULL;
    }
    
    if (!(account = account_create(NULL,NULL)))
    {
	eventlog(eventlog_level_error,"account_load","could not load account from file \"%s\"",filename);
	return NULL;
    }
    if (!(account->filename = strdup(filename)))
    {
	eventlog(eventlog_level_error,"account_load","could not allocate memory for account->filename");
	account_destroy(account);
	return NULL;
    }
    
    return account;
}


extern int accountlist_load_default(void)
{
    if (default_acct)
	account_destroy(default_acct);
    
    if (!(default_acct = account_load(prefs_get_defacct())))
    {
        eventlog(eventlog_level_error,"accountlist_load_default","could not load default account template from file \"%s\"",prefs_get_defacct());
	return -1;
    }
    if (account_load_attrs(default_acct)<0)
    {
	eventlog(eventlog_level_error,"accountlist_load_default","could not load default account template attributes");
	return -1;
    }
    
    eventlog(eventlog_level_debug,"accountlist_load_default","loaded default account template");
    return 0;
}

extern int accountlist_create_empty(void)
{
    if (!(accountlist_head=list_create())) {
      eventlog(eventlog_level_error,"accountlist_create_empty","could not create account list");
      return -1;
    }
    else return 0;
}

    
extern int accountlist_create(void)
{
    char *             filename;
    t_account *        account;
    unsigned int       count;
    char               name[PSOCK_MAX_PATH];
    PSOCK_DIR	       dir;
    

    if (accountlist_head)
    {
        eventlog(eventlog_level_error,"accountlist_load","accountlist is not empty before load");
	return -1;
    }
    else if (!(accountlist_head=list_create())) {
	eventlog(eventlog_level_error,"accountlist_load","counld not create accountlist_head");
	return -1;
    }
    
    dir = psock_findfirst(prefs_get_userdir(), name,PSOCK_MAX_PATH);

    if (dir==PSOCK_DIR_ERROR)
    {
	eventlog(eventlog_level_error,"accountlist_load","unable to open directory \"%s\" for reading (psock_findfirst: %s)",prefs_get_userdir(),strerror(errno));
	return -1;
    }

    count = 0;
    do 
    {
	if (name[0]=='.') continue;

	if (!(filename = malloc(strlen(prefs_get_userdir())+1+strlen(name)+1)))
	{
	    eventlog(eventlog_level_error,"accountlist_load","could not allocate memory for filename");
	    continue;
	}
	sprintf(filename,"%s/%s",prefs_get_userdir(),name);
	
	if (!(account = account_load(filename)))
	{
	    eventlog(eventlog_level_error,"accountlist_load","could not load account from file \"%s\"",filename);
	    free(filename);
	    continue;
	}
	
	if (!accountlist_add_account(account))
	{
	    eventlog(eventlog_level_error,"accountlist_load","could not add account from file \"%s\" to list",filename);
	    free(filename);
	    account_destroy(account);
	    continue;
	}
	
	free(filename);
	
	/* might as well free up the memory since we probably won't need it */
	account->accessed = 0; /* lie */
	account_save(account,1000); /* big delta to force unload */
	
        count++;
	
    } while (psock_findnext(dir,name,PSOCK_MAX_PATH)==0);
    
    psock_findclose(dir);
    
    eventlog(eventlog_level_info,"accountlist_load","loaded %u user accounts",count);
    
    return 0;
}


extern int accountlist_destroy(void)
{
    t_account * account;
    t_elem    * elem;
    
    LIST_TRAVERSE_DATA(accountlist_head,elem,account)
    {
	if (account_save(account,0)<0) {
	  eventlog(eventlog_level_error,"accountlist_destroy","could not save account");
	}
	account_destroy(account);

	if (list_remove_elem(accountlist_head,elem)<0) {
	  eventlog(eventlog_level_error,"accountlist_destroy","count not remove account from list");
	  return -1;
	}
    }
    if (list_destroy(accountlist_head)<0) return -1;
    else {
      accountlist_head=NULL;
      return 0;
    }
}

extern t_list * accountlist(void)
{
  return accountlist_head;
}

extern void accountlist_unload_default(void)
{
    account_destroy(default_acct);
}


extern int accountlist_get_length(void)
{
    return list_get_length(accountlist_head);
}


extern int accountlist_save(unsigned int delta)
{
    t_account *            account;
    unsigned int           scount;
    unsigned int           tcount;
    t_elem const *	   elem;
    
    scount=tcount = 0;
    LIST_TRAVERSE_DATA_CONST(accountlist_head,elem,account)
    {
	switch (account_save(account,delta))
	{
	case -1:
	    eventlog(eventlog_level_error,"accountlist_save","could not save account");
	    break;
	case 1:
	    scount++;
	    break;
	case 0:
	default:
	    break;
	}
    }

    if (scount>0)
	eventlog(eventlog_level_debug,"accountlist_save","saved %u of %u user accounts",scount,tcount);
    return 0;
}


extern t_account * accountlist_find_account(char const * username)
{
    unsigned int           userid=0;
    t_account *            account;
    t_elem const *	   elem;
    
    if (!username)
    {
	eventlog(eventlog_level_error,"accountlist_find_account","got NULL username");
	return NULL;
    }
    
    if (username[0]=='#')
        if (str_to_uint(&username[1],&userid)<0)
            userid = 0;
    
    /* all accounts in list must be hashed already, no need to check */
    
    if (userid)
    {
	LIST_TRAVERSE_DATA_CONST(accountlist_head,elem,account)
	{
	    if (account->uid==userid) return account;
	}
    }
    else
    {
	unsigned int namehash;
	char const * tname;
	
	namehash = account_hash(username);
	LIST_TRAVERSE_DATA_CONST(accountlist_head,elem,account)
	{
            if (account->namehash==namehash &&
		(tname = account_get_name(account))) {
		if (strcasecmp(tname,username)==0)
		{
		    account_unget_name(tname);
		    return account;
		}
		else
		    account_unget_name(tname);
	    }
	}
    }

    return NULL;
}


extern t_account * accountlist_add_account(t_account * account)
{
    unsigned int uid;
    char const * username;
    
    if (!account)
    {
        eventlog(eventlog_level_error,"accountlist_add_account","got NULL account");
        return NULL;
    }
    
    username = account_get_strattr(account,"BNET\\acct\\username");
    uid = account_get_numattr(account,"BNET\\acct\\userid");
    
    if (!username || strlen(username)<1)
    {
        eventlog(eventlog_level_error,"accountlist_add_account","got bad account (empty username)");
        return NULL;
    }
    if (uid<1)
    {
        eventlog(eventlog_level_error,"accountlist_add_account","got bad account (bad uid)");
	account_unget_name(username);
	return NULL;
    }
    
    /* delayed hash, do it before inserting account into the list */
    account->namehash = account_hash(username);
    account->uid = uid;
    
    /* mini version of accountlist_find_account() */
    {
	t_account *            curraccount;
	char const *           tname;
	t_elem const *	       elem;
	
	LIST_TRAVERSE_DATA_CONST(accountlist_head,elem,curraccount)
	{
	    if (curraccount->uid==uid)
	    {
		eventlog(eventlog_level_error,"accountlist_add_account","user \"%s\":"UID_FORMAT" already has an account (\"%s\":"UID_FORMAT")",username,uid,(tname = account_get_name(curraccount)),curraccount->uid);
		account_unget_name(tname);
		account_unget_strattr(username);
		return NULL;
	    }
	    
	    if (curraccount->namehash==account->namehash &&
		(tname = account_get_name(curraccount))) {
		if (strcasecmp(tname,username)==0)
		{
		    eventlog(eventlog_level_error,"accountlist_add_account","user \"%s\":"UID_FORMAT" already has an account (\"%s\":"UID_FORMAT")",username,uid,tname,curraccount->uid);
		    account_unget_name(tname);
		    account_unget_strattr(username);
		    return NULL;
		}
		else
		    account_unget_name(tname);
	    }
	}
    }
    account_unget_strattr(username);
    
    if (list_prepend_data(accountlist_head,account)<0)
    {
	eventlog(eventlog_level_error,"accountlist_add_account","could not add account to list");
	return NULL;
    }
    
    if (uid>maxuserid)
        maxuserid = uid;
    
    return account;
}


extern int accountlist_remove_account(t_account const * account)
{
    t_account * ac;
    t_elem    * elem;
    
    LIST_TRAVERSE_DATA(accountlist_head,elem,ac)
    {
	if (ac == account) {
 	   	list_remove_elem(accountlist_head,elem);
 	   	return 0;
	}
    }

    return -1;
}

