/*
 * Copyright (C) 1999  Mark Baysinger (mbaysing@ucsd.edu)
 * Copyright (C) 1999  Ross Combs (rocombs@cs.nmsu.edu)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#define TRACKER_INTERNAL_ACCESS
#define SERVER_INTERNAL_ACCESS
#include "config.h"
#include "setup.h"
#include <errno.h>

#define USE_STDDEF_HEADERS
#define USE_STRING_HEADERS
#define USE_MEMORY_HEADERS
#define USE_TIME_HEADERS
#define USE_UNAME_HEADERS
#define USE_SOCKET_HEADERS
#define USE_SYS_TYPES_HEADERS

#include "compat.h"

#include "compat/memset.h"
#include "compat/strerror.h"
#include "compat/send.h"
#include "compat/psock.h"
#include "eventlog.h"
#include "connection.h"
#include "channel.h"
#include "prefs.h"
#include "game.h"
#include "version.h"
#include "server.h"
#include "addr.h"
#include "list.h"
#include "tracker.h"


static t_addrlist * track_servers=NULL;


extern int tracker_set_servers(char const * servers)
{
    t_addr const * addr;
    t_elem const * elem;
    char           temp[32];
    
    if (track_servers && addrlist_destroy(track_servers)<0)
        eventlog(eventlog_level_error,"tracker_set_servers","unable to destroy tracker list");
    
    if (!servers)
	return 0;
    
    if (!(track_servers = addrlist_create(servers,INADDR_LOOPBACK,BNETD_TRACK_PORT)))
    {
	eventlog(eventlog_level_error,"tracker_set_servers","could not create tracking server list");
	return -1;
    }
    
    LIST_TRAVERSE_DATA_CONST(track_servers,elem,addr)
    {
	if (!addr_get_addr_str(addr,temp,sizeof(temp)))
	    strcpy(temp,"x.x.x.x:x");
	eventlog(eventlog_level_info,"tracker_set_servers","tracking packets will be sent to %s",temp);
    }
    
    return 0;
}


extern int tracker_send_report(t_addrlist const * laddrs)
{
    t_addr const *     addrl;
    t_elem const *     eleml;
    t_addr const *     addrt;
    t_elem const *     elemt;
    t_trackpacket      packet;
    struct utsname     utsbuf;
    struct sockaddr_in tempaddr;
    t_laddr_info *     laddr_info;
    char               tempa[64];
    char               tempb[64];
    
    if (addrlist_get_length(track_servers)>0)
    {
	packet.packet_version = htons((unsigned short)TRACK_VERSION);
	/* packet.port is set below */
	packet.flags = 0;
	strncpy(packet.server_location,
		prefs_get_location(),
		sizeof(packet.server_location));
	packet.server_location[sizeof(packet.server_location)-1] = '\0';
	strncpy(packet.software,
		"bnetd",
		sizeof(packet.software));
	strncpy(packet.version,
		BNETD_VERSION,
		sizeof(packet.version));
	strncpy(packet.server_desc,
		prefs_get_description(),
		sizeof(packet.server_desc));
	packet.server_desc[sizeof(packet.server_desc)-1] = '\0';
	strncpy(packet.server_url,
		prefs_get_url(),
		sizeof(packet.server_url));
	packet.server_url[sizeof(packet.server_url)-1] = '\0';
	strncpy(packet.contact_name,
		prefs_get_contact_name(),
		sizeof(packet.contact_name));
	packet.contact_name[sizeof(packet.contact_name)-1] = '\0';
	strncpy(packet.contact_email,
		prefs_get_contact_email(),
		sizeof(packet.contact_email));
	packet.contact_email[sizeof(packet.contact_email)-1] = '\0';
	packet.users = htonl(connlist_login_get_length());
	packet.channels = htonl(channellist_get_length());
	packet.games = htonl(gamelist_get_length());
	packet.uptime = htonl(server_get_uptime());
	packet.total_logins = htonl(connlist_total_logins());
	packet.total_games = htonl(gamelist_total_games());
	
	if (uname(&utsbuf)<0)
	{
	    eventlog(eventlog_level_warn,"tracker_send_report","could not get platform info (uname: %s)",strerror(errno));
	    strncpy(packet.platform,"",sizeof(packet.platform));
	}
	else
	{
	    strncpy(packet.platform,
		    utsbuf.sysname,
		    sizeof(packet.platform));
	    packet.platform[sizeof(packet.platform)-1] = '\0';
	}
	
	LIST_TRAVERSE_DATA_CONST(laddrs,eleml,addrl)
	{
	    if (!(laddr_info = addr_get_data(addrl).p))
	    {
		eventlog(eventlog_level_error,"tracker_send_report","address data is NULL");
		continue;
	    }
	    packet.port = htons(addr_get_port(addrl));
	    
	    LIST_TRAVERSE_DATA_CONST(track_servers,elemt,addrt)
	    {
		memset(&tempaddr,0,sizeof(tempaddr));
		tempaddr.sin_family = AF_INET;
		tempaddr.sin_port = htons(addr_get_port(addrt));
		tempaddr.sin_addr.s_addr = htonl(addr_get_ip(addrt));
		
		if (!addr_get_addr_str(addrl,tempa,sizeof(tempa)))
		    strcpy(tempa,"x.x.x.x:x");
		if (!addr_get_addr_str(addrt,tempb,sizeof(tempb)))
		    strcpy(tempa,"x.x.x.x:x");
		/* eventlog(eventlog_level_debug,"tracker_send_report","sending tracking info from %s to %s",tempa,tempb); */
		
		if (psock_sendto(laddr_info->usocket,&packet,sizeof(packet),0,(struct sockaddr *)&tempaddr,(psock_t_socklen)sizeof(tempaddr))<0)
		    eventlog(eventlog_level_warn,"tracker_send_report","could not send tracking information from %s to %s (psock_sendto: %s)",tempa,tempb,strerror(errno));
	    }
	}
    }
    
    return 0;
}
