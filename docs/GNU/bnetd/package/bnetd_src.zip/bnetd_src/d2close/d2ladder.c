/*
 * Copyright (C) 2000  Onlyer (onlyer@263.net)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#include "config.h"
#include "setup.h"

#include <stdio.h>
#include <errno.h>

#define USE_STDC_HEADERS
#define USE_STRING_HEADERS
#define USE_SYS_TYPES_HEADERS
#define USE_UNISTD_HEADERS

#include "compat.h"


#include "compat/strerror.h"
#include "compat/pdir.h"
#include "list.h"
#include "d2ladder.h"
#include "auth_protocol.h"
#include "eventlog.h"
#include "prefs.h"
#include "d2charfile.h"
#include "bn_type.h"
#include "field_sizes.h"


static int d2ladder_compare_exp(void const * info1, void const * info2);

static  char    d2ladder_type[12]={0,1,2,3,4,5,9,10,11,12,13,14};

t_d2ladderlist    * d2ladderlist;


extern t_d2ladderlist * d2ladder_getlist(void)
{
    return d2ladderlist;
}

extern int d2ladder_init(void)
{
    t_d2ladder * d2ladder;
    unsigned int    i;


    if (!(d2ladderlist=list_create())) {
	eventlog(eventlog_level_error,"d2ladder_init","could not create d2ladderlist");
	return -1;
    }

    for (i=0;i<sizeof(d2ladder_type);i++) {
	if (!(d2ladder=malloc(sizeof(t_d2ladder)))) {
	    eventlog(eventlog_level_error,"d2ladder_init","could not allocate d2ladder");
	    return -1;
	}
	d2ladder->type=d2ladder_type[i];
	d2ladder->info=NULL;
	d2ladder->len=0;
	list_append_data(d2ladderlist,d2ladder);
    }
    return 0;
}
    
extern int d2ladder_create(void)
{
    unsigned int i;
    d2ladder_loadinfo();
    for (i=0;i<sizeof(d2ladder_type);i++) {
	d2ladder_sort(d2ladder_type[i]);
	d2ladder_limit(d2ladder_type[i]);
    }
    return 0;
}


extern int d2ladder_limit(unsigned int type)
{
    t_d2ladder * d2ladder;

    d2ladder=d2ladderlist_find_type(type);
    switch (type) 
    {
        case D2LADDERINFO_STD_OVERALL:
        case D2LADDERINFO_HC_OVERALL:
	    if (d2ladder->len>D2LADDER_OVERALL_LEN) {
	        d2ladder->info=realloc(d2ladder->info,D2LADDER_OVERALL_LEN*sizeof(t_d2ladder_info));
	        d2ladder->len=D2LADDER_OVERALL_LEN;
	    }
	    break;
        default:
	    if (d2ladder->len>D2LADDER_CLASS_LEN) {
	    d2ladder->info=realloc(d2ladder->info,D2LADDER_CLASS_LEN*sizeof(t_d2ladder_info));
		    d2ladder->len=D2LADDER_CLASS_LEN;
	    }
	    break;
    }
    return 0;
}
    

extern void d2ladder_unload_data(void)
{
    unsigned int i;
    t_d2ladder * d2ladder;
    for (i=0;i<sizeof(d2ladder_type);i++) {
	d2ladder=d2ladderlist_find_type(d2ladder_type[i]);
	free(d2ladder->info);
	d2ladder->info=NULL;
	d2ladder->len=0;
    }
    return;
}

extern void d2ladder_unload(void)
{
    t_elem *	elem;

    t_d2ladder * d2ladder;
    d2ladder_unload_data();

    LIST_TRAVERSE_DATA(d2ladderlist,elem,d2ladder)
    {
	free(d2ladder);
	list_remove_elem(d2ladderlist,elem);
    }
    list_destroy(d2ladderlist);
    return;
}

extern int d2ladder_sort(unsigned int type)
{
    t_d2ladder	    * d2ladder;

    d2ladder=d2ladderlist_find_type(type);
    if (!d2ladder) {
	eventlog(eventlog_level_debug,"d2ladder_sort","got NULL d2ladder");
	return -1;
    }
    switch (d2ladder->type) {
	default:
	    qsort(d2ladder->info,d2ladder->len,sizeof(t_d2ladder_info),d2ladder_compare_exp);
    }
    return 0;
}



extern int d2ladder_insert_item(char const * charname,t_d2char_info * info,unsigned int type)
{
    t_d2ladder_info * d2ladder_info;
    t_d2ladder_info * newinfo;
    t_d2ladder	    * d2ladder;
    if (!d2ladderlist) {
	eventlog(eventlog_level_error,"d2ladder_insert_item","got NULL d2ladderlist");
	return -1;
    }
    if (!charname) {
	eventlog(eventlog_level_error,"d2ladder_insert_item","got NULL charname");
	return -1;
    }
    if (!info) {
	eventlog(eventlog_level_error,"d2ladder_insert_item","got NULL info");
	return -1;
    }
   
    d2ladder=d2ladderlist_find_type(type);
    if (!d2ladder) {
	eventlog(eventlog_level_error,"d2ladder_insert_item","got NULL d2ladder");
	return -1;
    }
    d2ladder_info=realloc(d2ladder->info,(d2ladder->len+1)*sizeof(t_d2ladder_info));
    d2ladder->info=d2ladder_info;
    newinfo=&(d2ladder_info[d2ladder->len]);
    d2ladder->len++;
    strncpy(newinfo->charname,charname,CHAR_NAME_LEN);
    newinfo->exp=bn_int_get(info->exp);
    newinfo->level=bn_byte_get(info->level);
    newinfo->status=bn_byte_get(info->status);
    newinfo->title=bn_byte_get(info->title);
    newinfo->class=bn_byte_get(info->class);
    return 0;
}

extern t_d2ladder * d2ladderlist_find_type(unsigned int type)
{
    t_d2ladder *   d2ladder;
    t_elem const * elem;

    if (!d2ladderlist) {
	eventlog(eventlog_level_error,"d2ladderlist_find_type","got NULL d2ladderlist");
	return NULL;
    }
    LIST_TRAVERSE_DATA_CONST(d2ladderlist,elem,d2ladder)
    {
	if (d2ladder->type==type) return d2ladder;
    }
    eventlog(eventlog_level_error,"d2ladderlist_find_type","could not find type %d in d2ladderlist",type);
    return NULL;
}


static int d2ladder_compare_exp(void const * info1, void const * info2)
{
    unsigned int exp1,exp2;
    
    exp1=((t_d2ladder_info const *)info1)->exp;
    exp2=((t_d2ladder_info const *)info2)->exp;
    if (exp1<exp2) return 1;
    else if (exp1==exp2) return 0;
    else return -1;
}

/*
int main(void)
{
    unsigned int i,j;
    t_d2ladder_info * d2ladderinfo;
    t_d2ladder * d2ladder;
    
    prefs_load("bnetd.conf");
    eventlog_set(stderr);
    d2ladder_init();
    for (i=0;i<10;i++) {
      d2ladder_create();
      d2ladder_unload_data();
    }
    d2ladder_create();
    for (i=0;i<sizeof(d2ladder_type);i++) {
	d2ladder=d2ladderlist_find_type(d2ladder_type[i]);
	for (j=0;j<d2ladder->len;j++)
	{
	    d2ladderinfo=&(d2ladder->info[j]);
	    printf ("%3d: Name:%s Type:%d Exp:%d Level:%d\n",j+1,d2ladderinfo->charname,d2ladder_type[i],d2ladderinfo->exp,d2ladderinfo->level);
	}
    }
    d2ladder_unload();
    prefs_unload();
    return 0;
}
*/

extern int d2ladder_loadinfo(void)
{
    PSOCK_DIR	    dir;
    char	    filename[PSOCK_MAX_PATH];
    t_d2char_info   * info;
    unsigned int    class;
    unsigned int    hardcore;

    dir=psock_findfirst(prefs_get_d2savedir(),filename,PSOCK_MAX_PATH);
    if (dir==PSOCK_DIR_ERROR) {
	eventlog(eventlog_level_error,"d2ladder_init","error open save directory(psock_findfirst:%s",strerror(errno));
	return -1;
    }
   
   do {
	if (filename[0]=='.') continue;
	/* check for directory and skip */
	info=d2char_getcharinfo(filename);
	if (!info) continue;
	class=bn_byte_get(info->class);
	hardcore=((bn_byte_get(info->status)&0xf)/4)%2;
	switch (hardcore) {
	    case 0:
		d2ladder_insert_item(filename,info,D2LADDERINFO_STD_OVERALL);
		d2ladder_insert_item(filename,info,D2LADDERINFO_STD_OVERALL+class);
		break;
	    
	    case 1:
		d2ladder_insert_item(filename,info,D2LADDERINFO_HC_OVERALL);
		d2ladder_insert_item(filename,info,D2LADDERINFO_HC_OVERALL+class);
		break;

	    default:
		break;
	}
	free(info);
    } while (psock_findnext(dir,filename,PSOCK_MAX_PATH)==0);
    psock_findclose(dir);
    return 0;
}
