Project: 		Diablo2 Realm Emulator
Version: 		1.0pre1
Staff:	 		Onlyer (onlyer@263.net)
Current Build:		Dec 2, 2000

Introduction:
	This project is aims to emulate blizzard`s diablo2 realm server
it comes from the bnetd project ( www.bnetd.org ).

Copyright:
	This program is a free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. 

You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. 


Some details:
	This project is to emulate diablo2(a great game comes from blizzard)closed battle.net.
It is just under testing by now.
	This program do not really run a game engineer,which is hard to emulate i think.(fsgs
is working on this),it just act as common battle.net server,let players to chat,create or join
games on it,the game engineer is just inherit the game from blizzard.the battle.net server makes
a pipe to it and parse some data.for more details,please look into the source code.
	the realm server will be unstable until now,that`s true.for the game engineer is done
by blizzard,which we don`t know exactly how it works and which do not purpose working as server.
it is hard to let blizzard open their server program to public,so this is just we can do by now.
(of cuz,there will need some patch on the origin game)

Support and Requirement:
	It support most unix like system and windows.I only tested it on Sun solaris, 
linux ,win9x,nt & 2k.
	if you just want to run binary, you only need the binary package and data package.
	if you want to compiler it, for unix users,you will need gcc and make utils, for windows users, you will need a win32 c compiler,e.g lcc,borland c or visual c, i personally use lcc ;)


Features and how to use it:
	this program mainly comes from bnetd-0.4.21 and bnetd-0.4.23pre9,so it inherit most features from bnetd--which support starcraft,broodwar,diablo and warcraftII BNE.most new 
features are for diablo2 closed battle.net. the documents in the program is just from bnetd
by now,and also,i have not enough time to comment the newly added source code.sorry about that,
and later if i got time,i will added them in.
	to use it,just do as origin bnetd,make proper configuration in the config file(of cuz,
there will be some new entry in it for realm,which is easy to understand),the document of bnetd
have details information on how to use it.
	additionally,if you want to make the server support realm game,you should download the
game server and runs it,then add an entry to the diablo2 game server chain.(use /add command)
	

Development:
	I am not familiar about bnetd and battle.net at the beginning ( which i just got to
known when diablo2 comes out),and until now,there only i oneself works on it, code,crack,test
and etc... so i really want someone else to join it.if you are interested in it,contact me ;)


TODO:
	lots,but not collected by now.
	
Thanks:
I would like to thank all peoples that help and support me to develop and test this program,especially thanks to:
	zixia (zixia@zixia.net)
	wubb (wubb@263.net)
	damo (yanglizai@263.net)
		
	
Contact:
If you have any great ideas or suggestions, don't hesitate to tell me! If you made some improvement for this program  you also can give me , and I can add them to the next release version. 
My Email address is: onlyer@263.net


Legal notes:
	Blizzard Entertainment is a trademark of Davidson & Associates, Inc.
	Starcraft is a trademark of Davidson & Associates, Inc.
	Warcraft is a trademark of Davidson & Associates, Inc.
	Diablo is a trademark of Davidson & Associates, Inc.
	Battle.net is a trademark of Davidson & Associates, Inc.
	Windows is a registered trademark of Microsoft Corporation
	MacOS is a registered trademark of Apple Computer, Inc.

	This project is in no way affiliated with Blizzard Entertainment

